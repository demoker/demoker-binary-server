/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKDynamicSoftbody3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKSoftAnchorData.h"
#import "LAKVec3.h"
#import "LAKkSoftbodyAeroMode.h"
#import "LAKkSoftbodyCollisionMode.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKDynamicSoftbody3DComponent : LAKComponent

@property(nonatomic, assign) float total_mass_;

@property(nonatomic, assign) NSInteger cfg_blend_constraint_strength_;

@property(nonatomic, assign) float cfg_material_linear_stiffness_;

@property(nonatomic, assign) float cfg_linear_damping_;

@property(nonatomic, assign) float cfg_dynamic_friction_;

@property(nonatomic, assign) float cfg_pressure_;

@property(nonatomic, assign) NSInteger velocity_solver_iterations_;

@property(nonatomic, assign) NSInteger position_solver_iterations_;

@property(nonatomic, assign) BOOL aero_mode_enabled_;

@property(nonatomic, assign) LAKkSoftbodyAeroMode aero_mode_;

@property(nonatomic, strong) LAKVec3 *wind_velocity_;

@property(nonatomic, assign) float cfg_drag_coefficient_;

@property(nonatomic, assign) float cfg_lift_coefficient_;

/**
 * Comments extracted from cpp files:
 *
 * 开启软体与刚体的绑定功能
 */
@property(nonatomic, assign) BOOL anchor_enabled_;

@property(nonatomic, strong) NSArray<LAKSoftAnchorData *> *anchor_lists_;

/**
 * Comments extracted from cpp files:
 *
 * 开启碰撞屏蔽列表
 */
@property(nonatomic, assign) BOOL collision_filter_enabled_;

@property(nonatomic, assign) LAKkSoftbodyCollisionMode collision_mode_;

/**
 * Comments extracted from cpp files:
 *
 * 碰撞边距
 */
@property(nonatomic, assign) float collision_margin_;

/**
 * Comments extracted from cpp files:
 *
 * disable collision entities ids
 */
@property(nonatomic, strong) NSArray<NSNumber *> *no_collision_objects_ids_;

/**
 * Comments extracted from cpp files:
 *
 * 缝合位置重合的点
 */
@property(nonatomic, assign) BOOL enable_point_fuse_;

@property(nonatomic, assign) NSInteger collision_filter_group_;

@property(nonatomic, assign) NSInteger collision_filter_mask_;

@property(nonatomic, assign) BOOL emit_collision_event_;

@end

NS_ASSUME_NONNULL_END

