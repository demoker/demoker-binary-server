﻿//
//  gyai_data_converter.h
//  图片生成Metal纹理（为了跨平台结构统一，改为统一void*结构）。
//
//  Created by gennyxu on 2019/9/18.
//  Copyright © 2019 Tencent. All rights reserved.
//

#pragma once

#ifdef __APPLE__

#include <light_ai_base/mac/gyai_texture_convert.h>
#include <string>

GYAILIB_NAMESPACE_START

/* @brief : 将path上image转为texture并存入指定结构。
 * @path : 输入的图片地址
 * @return : 返回texture， nil标示失败。
 * */
id<MTLTexture> GetMetalTextureFromPath(const std::string &path);

/* @brief : 将path上image转为texture并存入指定结构。
 * @imageData :
 * 此处仅记忆texture的地址，没有强引用对象，请尽快使用，防止被ARC回收掉（为了跨平台结构统一）。
 * @path : 输入的图片地址
 * @return : 0=success， other=failed。
 * 备注：如MTLTexture，必须立刻使用，该返回不会retain；可能会被回收池回收。
 * */
GYAIStatus CreateImageDataFromPath(GYImageData &imageData, const std::string &path);  // NOLINT

/* @brief : 创建指定大小的纹理，并存入指定的结构。
 * @params imageData [out] 输出结果
 * @params w/h/depth [in]: 输入的纹理期望的大小
 * @return : 0=success， other=failed。
 * 备注：如MTLTexture，必须立刻使用，该返回不会retain；可能会被回收池回收。
 * */
GYAIStatus CreateImageDataFromTextureWithSize(GYImageData *imageData, int w, int h, int depth);

#pragma mark - data from metal texture

/* @brief : GYImageData填充返回结果使用。
 * @params imageData [out] 数据希望存入的地址
 * @params texture [in] 输入的纹理
 * @params fmt [in] 对于texture无意义，内部根据texture格式来
 * 备注：如MTLTexture，必须立刻使用，该返回不会retain；可能会被回收池回收。
 * */
static inline void GYImageDataFillWithMTLTexture(GYImageData *image, id<MTLTexture> texture,
                                                 DataFormat fmt = DataFormatRGBA_8UC4) {
  image->data = (__bridge void *)(texture);
  image->width = static_cast<int>(texture.width);
  image->height = static_cast<int>(texture.height);
  image->format = fmt;  // 对于texture无意义
}

/* @brief : GYImageData创建metal texture
 * @params imageBytes [in] 数据希望cpu存入的地址
 * @params w / h / bytesPreRow [in] 输入数据的宽高等信息
 * @params fmt [in] 对于texture无意义，内部根据texture格式来
 * 备注：如MTLTexture，必须立刻使用，该返回不会retain；可能会被回收池回收。
 * */
id<MTLTexture> CreateMTLTexture2DFromBytes(const void *imageBytes, size_t w, size_t h,
                                           size_t bytesPreRow = 0,
                                           MTLPixelFormat format = MTLPixelFormatRGBA8Unorm,
                                           id<MTLDevice> device = nil);

/* @brief : GYImageData创建metal texture
 * @params image [in] 数据用来转换的数据
 *              .dataType只支持 GYDataTypeImage / GYDataTypeCPUData，表示直接转换 / CPU生成.
 *              .format 支持 MTLPixelFormatRGBA/BGRA8Unorm，参考 GetMTLPixelFormatFromDataFormat
 * 备注：如果么有数据或者失败，返回nil。
 * */
id<MTLTexture> GYImageDataCreateTexture2D(const GYImageData *image, id<MTLDevice> device);

#pragma mark - defalut metallib ext

// @brief 获取各个系统版本metallib默认后缀，方便素材配置，再调用该方法补全。
static inline std::string GetDefaultMetallibFileExtension() {
// 各个版本需传入各个版本的metallib
#if TARGET_OS_OSX
  return "mac.metallib";
#elif TARGET_OS_IPHONE
  return "ios.metallib";
#elif TARGET_OS_SIMULATOR
  return "simulator.metallib";
#else
  return "error.metallib";
#endif
}

GYAILIB_NAMESPACE_END

#endif  // end of #ifdef __APPLE__
