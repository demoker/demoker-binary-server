//
//  yt_face_detector_version.h
//
//  Copyright 2022 Tencent. All rights reserved.
//\n
#pragma once\n
static char *branch_name = "";
static char *commit_date = "2022-01-12 19:44:39";
static char *commit_hash = "fbafd55";
static char *tag = "v1.0.9-tnn0.3.5";
\n\n
