﻿//  gyai_interface_t.hpp
//  接口层配置和设置的参数
//
//  Created by gennyxu on 2020/10/30.
//  Copyright © 2020 Tencent. All rights reserved.
//

#pragma once

// clang-format off
#include <light_ai_base/data/gyai_data_t.hpp>
#include <stdio.h>
#include <map>
#include <memory>
#include <string>
// clang-format on

GYAILIB_NAMESPACE_START

/* @brief 通常指向模型所在文件夹（特殊模块会加上"模型自身名称(不包含后缀)"，因其服务于多个模型）
 * 1、指向模型所在文件夹：如手势-iOS为下载bundle全路径（包括bundle自身, 有多个模型会被使用）
 * 2、分割、GAN等：文件夹地址+名称（不带".rapidproto/model.wmc"后缀，内部自动拼接）
 * */
static const std::string &kModelRootDirKey = "root-path";
static const std::string &kModelConfigFileNameKey = "config.ini-filename";

using AIResourcePathMap = std::map<std::string, std::string>;  // 根据key存储模型路径

// 模块初始化参数：会根据传入数据，预生成部分数据（如GPU、Metal会根据需要生成library等）。
class GYAI_PUBLIC SDKDeviceConfig final {
 public:
  std::string device;       // 网络类型："ARM" "METAL" "OPENCL" "NAIVE" (默认为"CPU"/"GPU")
  AIResourcePathMap infos;  // 如"metal"/"tnn"=metallib路径，"opencl"=kernel路径等。
  // 下面这些参数暂时没有使用，去掉。后续如果需要，请改成int，不要用bool
//  bool smooth_enable = false;  // 是否期望执行平滑点之类操作 （尤其是GPU，需提前初始化参数）
//  int cpu_level = 0;  // 高端机，终端机，低端机 （备用：留作后续扩展使用）
};

// 模型路径、类型参数：（根据初始化时设置的网络类型，生成网络实例）。
class SDKModelConfig {
 public:
  /* @params [in] model_paths [GYAISpace::kModelRootDirKey]="model_dir_full_path"
   *   如手势、猫-iOS：传入模型所在bundle全地址即可
   *   如分割、深度：需传入bundle+high/low后的全地址（文件夹下需存在high/low，也可自定义路径）
   * 备注 ：GAN暂不支持，因为和素材相关，模型名称随意变换（上述功能文件夹会换，但模型名称不会变）。
   * */
  AIResourcePathMap model_paths;  // 不同类型模型的全路径（需参考各使用模块要求的种类和数量）

  /* 由于此配置属性供iOS和Mac下发metallib使用，安卓opencl实现并无下发能力，故此属性实际开发中不要配置，仅供iOS和Mac调试用
   * 根据key取前后处理函数名 前处理key:preprocess 后处理key:postprocess
   * e.g. pre_post_names = {{"preprocess", "xxxxxx"}, {"postprocess", "xxxxx"}}
   * 如果不配置此参数，则默认取的前后处理函数名为 gy_preprocess gy_postprocess
   */
  int prefer_points = 0;  // 期望的点数量(同模块、不同模型点数量会不同；会检查数量的正确性）
  int model_type = 0;     // 模型类型（0=RapidModel, 1=TNNModel）
  int preferWidth = 0, preferHeight = 0;  // 期望的模型输入大小，用于默认的单输入reshape使用

  // 配置 kModelRootDirKey 路径（各模块可获取 root_dir 拼接模型名称作为模型路径）
  void SetRootPath(const std::string &root_dir) { model_paths[kModelRootDirKey] = root_dir; }

  // @brief 设置默认 config.ini的name（参考：GetConfigIniPath）。
  void SetConfigIniName(const std::string &name) { model_paths[kModelConfigFileNameKey] = name; }

  /* @brief 获取 kModelRootDirKey 配置的路径（参考model_paths，默认为模型存放的文件夹地址）
   * @params check_add_suffix_file_sep 存放的路径是否末尾有文件分隔符，没有则添加
   * @return 存放的结果（路径开启check_add_suffix_file_sep，不存在文件分隔符会自动添加 */
  const std::string GetRootPath(bool check_add_suffix_file_sep = true) const;

  /* @brief 根据 kModelRootDirKey + kModelConfigFileNameKey 获取config路径，并返回
   *        如果没有配置 kModelRootDirKey [in] 会返回空字符串
   *        如果没有配置 kModelConfigFileNameKey [in] 会添加默认"config.ini"文件后缀
   * @params default_config_name 默认config.ini名称
   * @return 存放的结果结果，会默认拼接默认[default_config_name]文件后缀 */
  const std::string GetConfigIniPath(const std::string &default_config_name = "config.ini") const;

  // 根据key的值，从model_paths中获取路径(如果未找到，返回空字符串)。
  const std::string GetModelPathForKey(const std::string &key) const;

  // 根据key获取存储的路径 (如未找到，则返回 placeholder)
  // 备注：如果存储的为空字符串，也会返回空字符串，不会返回placeholder。
  const std::string GetPathForKey(const std::string &key, const std::string &placeholder) const;

  // 根据key获取存储的路径 (如未找到，返回 placeholder_dir+placeholder_name)
  // @params [in]placeholder_dir 如为空，则整个 placeholder 为空，不会拼接路径返回。
  // @params [in]placeholder_name 如为空，则整个 placeholder 为空，不会拼接路径返回。
  // 备注：如果存储的为空字符串，也会返回空字符串，不会返回placeholder。
  const std::string GetPathForKey(const std::string &key, const std::string &placeholder_dir,
                                  const std::string &placeholder_name) const;

  // 根据key获取存储的路径 (如未找到，返回 placeholder_dir+placeholder_name)
  // @params [in] placeholder_map 优先查找key替代placeholder_name，找不到使用默认dir+placeholder
  // @params [in] placeholder_name 该值会优先被placeholder_map[key]覆盖（如果存在）
  const std::string GetPathForKey(const std::string &key, const std::string &placeholder_dir,
                                  const AIResourcePathMap &placeholder_map,
                                  const std::string &placeholder_name) const;
};

#pragma mark - 常用的接口函数

/* @brief 用于方便的获取从map中传入的路径(如果未找到，返回空字符串)。
 * @params map 输入用于查找的map，根据key值查找。
 * @return 如果未找到，返回空字符串; 找到返回对应结果。
 */
const std::string SafeGetStringValueFromMap(const AIResourcePathMap &map, const std::string &key);

#pragma mark - config ini 文件解析

/* @brief 解析config文件的参数，并返回存入map
 * @params config_path [in] 输入config文件的全路径 (文件严格存入key=val)
 * @params dst [out] 结果存放的位置，目前只能存放 string (value取到行结束，包含中间空格)
 * 备注：key、value不超过100字符串 (保证最终全路径不超过1024等系统允许的最大长度)
 * 备注：key、value尽量不要配置空格，防止影响读取（key通常读取到=都会停止）
 * */
GYAI_PUBLIC GYAIStatus ParseConfigFileToMap(const std::string &config_path, AIResourcePathMap *dst);
GYAI_PUBLIC AIResourcePathMap ParseConfigFileToMap(const std::string &config_path);

static inline std::string GetConfigValueForKey(const AIResourcePathMap &map, const std::string &key,
                                               const std::string &placeholder) {
  const auto &val = map.find(key);
  return val != map.end() ? val->second : placeholder;
}

GYAILIB_NAMESPACE_END
