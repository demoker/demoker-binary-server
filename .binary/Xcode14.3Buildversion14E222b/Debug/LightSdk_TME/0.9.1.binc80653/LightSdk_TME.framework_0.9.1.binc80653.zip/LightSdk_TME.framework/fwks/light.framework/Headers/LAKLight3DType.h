/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKLight3DType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKLight3DType) {
    LAKLight3DTypekPoint = 0,
    LAKLight3DTypekDirectional = 1,
    LAKLight3DTypekSpot = 4,
    LAKLight3DTypekEnvironmental = 5
};

NS_ASSUME_NONNULL_END

