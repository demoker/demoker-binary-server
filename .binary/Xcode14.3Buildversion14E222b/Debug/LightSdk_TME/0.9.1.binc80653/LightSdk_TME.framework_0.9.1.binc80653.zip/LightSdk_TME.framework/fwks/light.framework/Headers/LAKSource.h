/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKSource.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKSource : LAKSerializable

@property(nonatomic, strong) NSString *path;

@property(nonatomic, assign) NSInteger weight;

@end

NS_ASSUME_NONNULL_END

