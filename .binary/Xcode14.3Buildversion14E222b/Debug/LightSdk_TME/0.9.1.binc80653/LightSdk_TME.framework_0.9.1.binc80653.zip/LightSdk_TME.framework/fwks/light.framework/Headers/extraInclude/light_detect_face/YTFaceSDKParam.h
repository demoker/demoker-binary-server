﻿//
//  YTFaceSDKParam.h
//  人脸检测
//
// Created by zijunzhang on 2020/7/31.
// Copyright © 2020 tencent. All rights reserved.
//

#pragma once

#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

#pragma mark - detector max image size

// 太大将大幅增加内存、耗时；部分前向层、模型代码会申请内存失败，可能带来SIGSEGV、SIGBUS等问题
// 建议上层缩放好图片后传入检测：1、多模块都需要缩放后的图；2、cv::Mat缩放无硬件加速。
// 建议图片检测在 720P 左右；视频可根据机型性能决定（中台走默认逻辑即可）。
#define GYAI_FACE_INPUT_IMAGE_MAX_EDGE_SIZE 2048  // 输入图支持最大边长
#define GYAI_FACE_ENABLE_YT_FACE_DETECTOR 0

#pragma mark - face mode

/// @brief 用于设置当前检测器人脸配准点位模式：由算法定义。
/// 1: 标准模式； 2: Avatar模式；3: 扩充130点到256点模式，YT_FACE_ALIGNMENT_MODE_SPARSE使用。
typedef enum {
  FaceAlignmentMergeModeUndefined = 0,  // 未定义 —— 用作未初始化时初值使用，请勿设置
  FaceAlignmentMergeModeCommon = 1,     // 标准模式
  FaceAlignmentMergeModeAvatar = 2,     // avatar模式
  FaceAlignmentMergeModeSparseExt = 3,  // 扩充130到256点 for YT_FACE_ALIGNMENT_MODE_SPARSE
  FaceAlignmentMergeModeDefault = FaceAlignmentMergeModeCommon,
} FaceAlignmentMergeMode;

#pragma mark - detector setting params

// 人脸检测器常用的参数设置，检测前或者间隔可以修改（需保证安全）
typedef struct YTFaceSDKParam {
  bool enable_still_image_mode = false;  // 开启后适用于静态图像检测，默认关闭

  bool enable_tracker_track_frequency_control = true;  // 是否开启频控，控制人脸检测的频率
  int tracker_track_frequency = 15;  // 检测人脸的帧频率，默认为15（大于0，是合法值）
  int skip_track_failed_count = 0;  // 视频：追踪失败，没超过该值，仍为成功；内部不清理缓存，默认为0

  bool enable_3d_perspective = true;  // 计算3D点（优图头部1000点，默认开启），请根据素材设置。
  float fov = 60.0f;  // 相机的Fov，默认60度；计算3D点使用。

  // @brief 点位模式, 参考FaceAlignmentMergeMode：a2d场景下的Avatar模式；通常为Common；@atilazhang。
  bool enable_merge_mode_avatar = false;  // true=avatar配准模式，false: 通常情况下的配准模式

  bool first_frame_need_sync_detect = false;  // 首帧需要同步检测，默认关闭
  bool need_sync_detect = false;              // 需要同步检测，默认关闭

  // 是否坐标矫正(默认未开启)：开启矫正，坐标结果即为 (pointXAndY + 0.5)
  // 未矫正的坐标归一化到0~1：(point + 0.5)/W_H ；因上层缩放都没加0.5，为减少改动，给一个底层接口。
  bool position_correct = false;

  // 配准时, 是否生成人脸3d头模、欧拉角（即调用Track3D() - 2D点匹配得出3D头模点、欧拉角）
  int face3d_mode = 1;  // 1=开启；0=关闭(有点耗时，可关闭 优化性能; 但不可再用3D点、欧拉角)
  int face3d_expr_level = 1;  // 表情基求解级别，默认级别GYFace3DExpressionLv_low
  int face3d_need_mesh = 1;   // 3dmm是否返回mesh点位信息，默认需要返回
  bool enable_ai_face3d = false;  // 是否开启AI模式的3dmm求解

  // 专注于face追踪：大于0开启。没有人脸会进行检测；有人脸后则永不检测（此时无法新增人脸）。
  int host_on_track_face = 0;  // 专注于追踪face（没有人脸才开启检测，否则不检测）
} YTFaceSDKParam;

#pragma mark - the default setting

/* @brief 默认为视频使用（为了方便上层查看默认值，并做适当修改）。
 * 备注：静态图需要设置enable_still_image_mode，并检测时候，每一帧结束清除缓存。
 * */
static inline void GYAIFaceSDKParamsReset(YTFaceSDKParam *params) {
  params->enable_still_image_mode = false;

  params->enable_tracker_track_frequency_control = true;
  params->tracker_track_frequency = 15;
  params->skip_track_failed_count = 0;  // 微视使用的默认值，其他平台可能需修改。

  params->enable_3d_perspective = true;
  params->fov = 60.0f;

  params->enable_merge_mode_avatar = false;

  params->first_frame_need_sync_detect = false;
  params->need_sync_detect = false;

  params->position_correct = false;  // 是否坐标矫正(默认未开启)

  params->face3d_expr_level = 1;  // GYFace3DExpressionLv_low;
  params->face3d_need_mesh = 1;
  params->enable_ai_face3d = false;
}

#pragma mark - detect image setting

// 设置人脸SDK为静态图图片检测设置
static inline void GYAIFaceSDKParamsApplyStillImageSetting(YTFaceSDKParam *sdkParam) {
  sdkParam->enable_still_image_mode = true;  // 默认开启图片检测，为了测试集而增加
  sdkParam->need_sync_detect = true;
  sdkParam->enable_3d_perspective = true;
  sdkParam->enable_merge_mode_avatar = false;
  sdkParam->enable_tracker_track_frequency_control = false;
  sdkParam->first_frame_need_sync_detect = true;
  sdkParam->tracker_track_frequency = 1;
  sdkParam->face3d_expr_level = 1;  // GYFace3DExpressionLv_low;
  sdkParam->face3d_need_mesh = 1;
  sdkParam->enable_ai_face3d = false;
}

#ifdef __cplusplus
}  // end of extern "C"
#endif
