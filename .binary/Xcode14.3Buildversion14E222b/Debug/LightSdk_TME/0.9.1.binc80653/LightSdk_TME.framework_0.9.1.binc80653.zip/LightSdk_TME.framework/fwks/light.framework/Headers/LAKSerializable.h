/**
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKSerializable.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: rickshe
 */

#import <Foundation/Foundation.h>

@interface LAKSerializable : NSObject <NSCopying, NSCoding>

// return 成功与否
- (BOOL)copyFrom:(LAKSerializable *)instance;

@end
