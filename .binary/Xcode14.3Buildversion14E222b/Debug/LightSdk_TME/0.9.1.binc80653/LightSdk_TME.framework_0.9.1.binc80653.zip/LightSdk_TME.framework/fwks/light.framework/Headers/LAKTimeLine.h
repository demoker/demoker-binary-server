/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKTimeLine.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"
#import "LAKTimeRange.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKTimeLine : LAKSerializable

@property(nonatomic, strong) NSString *type;

/**
 * Comments extracted from cpp files:
 *
 * 从Name Component中取的id
 */
@property(nonatomic, assign) NSInteger entityID;

@property(nonatomic, strong) LAKTimeRange *range;

@property(nonatomic, assign) NSInteger time;

@property(nonatomic, strong) NSString *event;

@end

NS_ASSUME_NONNULL_END

