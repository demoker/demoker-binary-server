/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKCamera3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKCamera3DFovType.h"
#import "LAKCamera3DProjectionType.h"
#import "LAKCamera3DTargetBufferFlags.h"
#import "LAKComponent.h"
#import "LAKRect.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKCamera3DComponent : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * basic properties
 */
@property(nonatomic, assign) NSInteger layers;

@property(nonatomic, assign) LAKCamera3DProjectionType projectionType;

/**
 * Comments extracted from cpp files:
 *
 * perspective camera
 */
@property(nonatomic, assign) LAKCamera3DFovType fovType;

@property(nonatomic, assign) float fov;

/**
 * Comments extracted from cpp files:
 *
 * orthographic camera
 * The width of the viewing box of the Orthographic Camera
 */
@property(nonatomic, assign) float size;

@property(nonatomic, assign) float near;

@property(nonatomic, assign) float far;

@property(nonatomic, strong) LAKRect *viewportRect;

/**
 * Comments extracted from cpp files:
 *
 * clearing related properties
 */
@property(nonatomic, assign) BOOL copyInput;

@property(nonatomic, assign) LAKCamera3DTargetBufferFlags targetBufferFlags;

@property(nonatomic, strong) NSString *clearColor;

@property(nonatomic, assign) float clearDepth;

@property(nonatomic, assign) NSInteger clearStencil;

@property(nonatomic, assign) BOOL frustumCulling;

/**
 * Comments extracted from cpp files:
 *
 * render target the camera uses
 */
@property(nonatomic, strong) NSString *renderTargetKey;

/**
 * Comments extracted from cpp files:
 *
 * ztd logic: 输出纯3D结果到output_3d_rendertarget_对应的render target上
 */
@property(nonatomic, assign) BOOL is_use_3d_rt_;

@property(nonatomic, strong) NSString *output_3d_rendertarget_;

@end

NS_ASSUME_NONNULL_END

