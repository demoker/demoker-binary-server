/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKLipsDetailType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKLipsDetailType) {
    LAKLipsDetailTypeDefault = 0,
    LAKLipsDetailTypeGloss = 1,
    LAKLipsDetailTypeShimmer = 2,
    LAKLipsDetailTypeCombine_Gloss_Shimmer = 3
};

@interface LAKLipsDetailTypeStringConverter : NSObject
+ (NSString *)toString:(LAKLipsDetailType)lipsDetailType;
+ (LAKLipsDetailType)fromString:(NSString *)string;
@end

NS_ASSUME_NONNULL_END

