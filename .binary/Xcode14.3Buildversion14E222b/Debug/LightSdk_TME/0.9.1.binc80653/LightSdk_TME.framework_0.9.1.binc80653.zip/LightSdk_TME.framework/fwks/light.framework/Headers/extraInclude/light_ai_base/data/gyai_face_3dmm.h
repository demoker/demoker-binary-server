//
//  gyai_face_3dmm.h
//  light_ai_base
//
//  Created by gennyxu on 2021/8/12.
//  Copyright © 2021 Tencent. All rights reserved.
//  两边用到的设置参数先汇总在一起，算法内部实际没有处理的参数就无视

#pragma once

#include <light_ai_base/GYAIBase.h>
#include <memory>
#include <string>
#include <vector>

LIGHT_NAMESPACE_START
typedef struct light_face_config_3d {
  int head_model_style;  // 微视 0:全头, 1:前脸 暂时去掉
  int expression_level;  // 光影 表情基求解等级，0:无，1:基础表情，2:全量表情，3:深度表情
  int mesh_level;  // 光影 是否计算mesh  0:不计算mesh, 1:计算全脸mesh, 2:只计算表情mesh
  float smooth_strength;  // 光影 pose平滑强度，默认为0
  float fov;
} light_face_config_3d;

class GYAI_PUBLIC LightFaceShape3D {
 public:
  int face_id;                                                    // 上层透传的人脸标识
  std::shared_ptr<std::vector<float>> vertex3d_points = nullptr;  // 3d模型顶点数据, world坐标系
  std::shared_ptr<std::vector<float>> uv = nullptr;               // uv坐标数据
  std::shared_ptr<std::vector<int>> triangle_indexes = nullptr;  // 三角面索引

  // 头模姿态角，主要用于2D贴纸和美妆/美型的计算矫正
  float pitch;            // >0表示低头 <0表示抬头 手机正方向
  float yaw;              // >0表示往左侧摇头 <0表示往右侧摇头
  float roll;             // >0表示往右侧歪头 <0表示往左侧歪头
  float pitch_fixed;      // >0表示低头 <0表示抬头 头正方向
  float yaw_fixed;        // >0表示往左侧摇头 <0表示往右侧摇头
  float roll_fixed;       // >0表示往右侧歪头 <0表示往左侧歪头
  float transform[4][4];  // pose矩阵，对应MVP中的MV矩阵，P矩阵由渲染引擎构建

  std::shared_ptr<std::vector<float>> expression_weights =
      nullptr;  // 表情基，对齐苹果，按字母顺序排序
  std::shared_ptr<std::vector<std::string>> blendshape_name = nullptr;  //  表情系数的名字
};

class GYAI_PUBLIC LightFaceShape3DPack {
 public:
  std::vector<LightFaceShape3D> face_shape_3d_vec_;
};

LIGHT_NAMESPACE_END
