﻿//
//  gy_file_extension.h
//  用于扩展文件相关操作
//
// Created by gennyxu on 2021-12-09.
// Copyright © 2021 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/GYAIBase.h>
#include <algorithm>
#include <cstdio>
#include <string>

GYAILIB_NAMESPACE_START

// @brief 检测文件是否存在 @path[in] (非空，不支持文件夹)
bool FileExist(const char* path);

// @brief 将input所有的中src[in 非空] 替换为 dst[in]
std::string ReplaceAllStringWithString(const std::string& str, const std::string& from,
                                       const std::string& to);

// @brief 适配windows的文件分隔符（所有标准分隔符，在windows下替换为该系统分隔符）
#ifdef WIN32
#define GYAIFitWinFileSep(path) path = ReplaceAllStringWithString(path, "/", GYAISpace::kFileSep)
#else
#define GYAIFitWinFileSep(path) do {} while (0)
#endif

#pragma mark - fix tnn metallib

#ifdef __APPLE__
// @brief 检测输入的路径，是否满足Metal-metallib后缀; 如果是bundle，自动拼接metallib.
std::string GYGetFullMetallibPath(const std::string& inputPath, const std::string& metallibPrefix);
std::string GYGetFullMetallibPath(const AIResourcePathMap& map, const std::string& key,
                                  const std::string& metallibPrefix);
#endif  // #ifdef __APPLE__

GYAILIB_NAMESPACE_END
