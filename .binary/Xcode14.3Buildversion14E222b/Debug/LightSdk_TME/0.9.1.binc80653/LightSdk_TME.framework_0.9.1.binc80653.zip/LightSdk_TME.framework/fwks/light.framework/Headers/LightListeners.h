// Copyright 2020 Tencent Inc. All Rights Reserved.
//  LightTipsStatusListeners.h
//  Pods-LightSDKDemo
//
//  Created by 吕所军 on 2020/8/12.
//

#ifndef PLATFORM_IOS_PRIVATE_LIGHTLISTENERS_H_
#define PLATFORM_IOS_PRIVATE_LIGHTLISTENERS_H_

#import <Foundation/Foundation.h>
#import "LightFaceData.h"

typedef NS_ENUM(NSInteger, TipsType) {
    TipsType_PNG = 0,
    TipsType_PAG = 1
};

@protocol LightTipsStatusListener <NSObject>

// type为0时为默认tips文字，tips_icon为png图片地址
// type为1时为默认tips为""，tips_icon为pag文件地址
- (void)tipsNeedShow:(NSString *)tips tipsIcon:(NSString *)tipsIcon type:(TipsType)type duration:(NSInteger)duraion;
- (void)tipsNeedHide:(NSString *)tips tipsIcon:(NSString *)tipsIcon type:(TipsType)type;

@end

@protocol LightScriptOutputListener <NSObject>
- (void)onScriptOutput:(NSString *)output;
@end

@protocol LightAIDataListener <NSObject>

- (void)onFaceDataUpdated:(LightFaceData *)faceData;
- (void)onHandDataUpdated:(NSArray<NSArray<NSNumber *>*>*)handData;
- (void)onBodyDataUpdated:(NSArray<NSArray<NSNumber *>*>*)bodyData;

@end

@protocol LightClickWatermarkListener <NSObject>

- (void)onClickWatermark;

@end

@protocol LightWatermarkDataListener <NSObject>

- (NSString *)getData:(NSString *)key;

@end

@protocol LightLoadAssetListener <NSObject>

- (void)onLoadAssetError:(int)errorCode;
- (void)onAssetProcessing:(NSDictionary *)infos;

@end

#endif
