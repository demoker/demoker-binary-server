/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKSticker3D.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKCameraTransform.h"
#import "LAKCameraViewConfig.h"
#import "LAKComponent.h"
#import "LAKPosition.h"
#import "LAKSticker3DMaterialType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKSticker3D : LAKComponent

@property(nonatomic, assign) LAKSticker3DMaterialType materialType;

@property(nonatomic, assign) NSInteger fov;

@property(nonatomic, assign) BOOL use3DMMTransform;

@property(nonatomic, assign) BOOL fit3DMM;

@property(nonatomic, assign) BOOL isKapuMaterial;

@property(nonatomic, assign) BOOL needFaceMeshFacekit;

@property(nonatomic, assign) BOOL enableTessellation;

@property(nonatomic, assign) NSInteger faceMeshModelType;

@property(nonatomic, assign) NSInteger modelType;

@property(nonatomic, assign) float projectionFar;

@property(nonatomic, assign) NSInteger kapuMaterialType;

@property(nonatomic, assign) BOOL useMetal;

/**
 * Comments extracted from cpp files:
 *
 * 设定的初始位置
 */
@property(nonatomic, strong) LAKPosition *LAKinitPosition;  // OC变量名不能以init开头，这里加个前缀

/**
 * Comments extracted from cpp files:
 *
 * 设定的初始角度
 */
@property(nonatomic, strong) LAKPosition *LAKinitRotation;  // OC变量名不能以init开头，这里加个前缀

/**
 * Comments extracted from cpp files:
 *
 * 设定的角度变化系数, 用来缩放角度变化
 */
@property(nonatomic, strong) LAKPosition *rotationFactor;

@property(nonatomic, strong) LAKCameraTransform *initialCameraTransform;

@property(nonatomic, strong) NSArray<LAKCameraViewConfig *> *cameraViewConfig;

@property(nonatomic, strong) NSString *resourcePath;

@property(nonatomic, strong) NSString *materialPath;

@property(nonatomic, strong) NSArray<NSString *> *externalInputKey;

@property(nonatomic, strong) NSArray<NSString *> *inputRenderTarget;

@property(nonatomic, strong) NSString *triggerJson;

/**
 * Comments extracted from cpp files:
 *
 * 使用真实物理世界中的头模尺寸，约20cm的头模大小
 */
@property(nonatomic, assign) BOOL useRealSizeHead;

@end

NS_ASSUME_NONNULL_END

