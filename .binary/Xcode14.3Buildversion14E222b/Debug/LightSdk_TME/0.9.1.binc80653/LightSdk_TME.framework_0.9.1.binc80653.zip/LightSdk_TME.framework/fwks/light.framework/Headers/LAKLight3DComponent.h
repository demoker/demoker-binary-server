/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKLight3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKLight3DType.h"
#import "LAKShadowConfig.h"
#import "LAKSkyBoxConfig.h"
#import "LAKVec3.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKLight3DComponent : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 光源类型
 */
@property(nonatomic, assign) LAKLight3DType lightType;

/**
 * Comments extracted from cpp files:
 *
 * 光照强度[all type] [0-100.0]
 */
@property(nonatomic, assign) float intensity;

/**
 * Comments extracted from cpp files:
 *
 * 光照颜色[kDirectional, kPoint, kSpot]
 */
@property(nonatomic, strong) NSString *lightColor;

/**
 * Comments extracted from cpp files:
 *
 * 衰减半径[kPoint, kSpot], 暂时 js 不暴露
 */
@property(nonatomic, assign) float radius;

/**
 * Comments extracted from cpp files:
 *
 * 光源位置[kPoint, kSpot]
 */
@property(nonatomic, strong) LAKVec3 *position;

/**
 * Comments extracted from cpp files:
 *
 * 内锥角[kSpot][0-90°]
 */
@property(nonatomic, assign) float innerAngle;

/**
 * Comments extracted from cpp files:
 *
 * 外锥角[kSpot][0-180°]
 */
@property(nonatomic, assign) float outerAngle;

/**
 * Comments extracted from cpp files:
 *
 * reflection path cubmap [kEnvironmental]
 */
@property(nonatomic, strong) NSString *iblPath;

/**
 * Comments extracted from cpp files:
 *
 * 漫反射贴图 cubMap [kEnvironmental]
 */
@property(nonatomic, strong) NSString *irradiancePath;

/**
 * Comments extracted from cpp files:
 *
 * 默认 Y 轴， 环境光旋转角度[kEnvironmental][-360-360]
 */
@property(nonatomic, assign) float envRotation;

/**
 * Comments extracted from cpp files:
 *
 * 天空盒参数
 */
@property(nonatomic, strong) LAKSkyBoxConfig *skyBoxConfig;

/**
 * Comments extracted from cpp files:
 *
 * 阴影参数
 */
@property(nonatomic, strong) LAKShadowConfig *shadowConfig;

@end

NS_ASSUME_NONNULL_END

