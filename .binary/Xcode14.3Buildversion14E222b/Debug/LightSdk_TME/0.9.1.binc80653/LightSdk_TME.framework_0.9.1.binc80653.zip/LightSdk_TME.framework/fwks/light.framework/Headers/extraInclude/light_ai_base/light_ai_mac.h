﻿//
//  light_ai_mac.h
//  light_ai_base
//
//  Created by gennyxu on 2021/8/12.
//  Copyright © 2021 Tencent. All rights reserved.
//

#pragma once

// @brief 因为并非所有工程都开启了混编，所以c++编译环境未必认识 objc；Apple代码单独放置，单独引用。
#include <light_ai_base/GYAIBase.h>
#include <light_ai_base/mac/GYAIMetalExtension.h>
#include <light_ai_base/mac/gyai_data_converter.h>
#include <light_ai_base/mac/gyai_texture_convert.h>
