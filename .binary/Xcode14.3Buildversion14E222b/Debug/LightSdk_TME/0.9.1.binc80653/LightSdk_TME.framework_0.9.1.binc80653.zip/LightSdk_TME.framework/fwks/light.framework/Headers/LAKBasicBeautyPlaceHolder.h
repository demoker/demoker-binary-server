/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBasicBeautyPlaceHolder.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKBasicBeautyPlaceHolder : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 磨皮开关状态
 */
@property(nonatomic, assign) NSInteger smoothStatus;

/**
 * Comments extracted from cpp files:
 *
 * 普通美颜开关状态
 */
@property(nonatomic, assign) NSInteger beautyStatus;

/**
 * Comments extracted from cpp files:
 *
 * 美妆开关状态
 */
@property(nonatomic, assign) NSInteger makeupStatus;

@end

NS_ASSUME_NONNULL_END

