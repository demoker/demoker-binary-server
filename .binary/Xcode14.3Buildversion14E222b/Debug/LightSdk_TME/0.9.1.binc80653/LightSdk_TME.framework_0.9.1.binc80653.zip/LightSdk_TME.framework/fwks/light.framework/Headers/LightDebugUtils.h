//
//  LightDebugUtils.h
//  light
//
//  Created by sheng on 2021/7/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LightDebugUtils : NSObject

+ (void)SetImageDebugInfo:(BOOL)enableDebug resultDir:(NSString *)resultDir fileNameIncludeTimestamp:(BOOL)fileNameIncludeTimestamp debugAllImage:(BOOL)debugAllImage debugParam:(BOOL)debugParam debugTree:(BOOL)debugTree;

@end

NS_ASSUME_NONNULL_END
