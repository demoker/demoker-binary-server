/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKHairEffectType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKHairEffectType) {
    LAKHairEffectTypeImage = 0,
    LAKHairEffectTypeLut = 1,
    LAKHairEffectTypeBleach = 2
};

@interface LAKHairEffectTypeStringConverter : NSObject
+ (NSString *)toString:(LAKHairEffectType)hairEffectType;
+ (LAKHairEffectType)fromString:(NSString *)string;
@end

NS_ASSUME_NONNULL_END

