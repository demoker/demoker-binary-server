/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMeshRenderer3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKPrimitiveConfig.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMeshRenderer3DComponent : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * [serialization]
 */
@property(nonatomic, strong) NSString *meshName;

@property(nonatomic, assign) NSInteger meshIndex;

@property(nonatomic, assign) BOOL skinned;

@property(nonatomic, strong) NSArray<LAKPrimitiveConfig *> *primitiveConfigs;

@end

NS_ASSUME_NONNULL_END

