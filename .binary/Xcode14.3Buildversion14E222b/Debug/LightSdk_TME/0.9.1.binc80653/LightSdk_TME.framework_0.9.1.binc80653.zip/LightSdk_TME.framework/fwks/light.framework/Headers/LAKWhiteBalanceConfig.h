/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKWhiteBalanceConfig.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKWhiteBalanceConfig : LAKSerializable

/**
 * Comments extracted from cpp files:
 *
 * -1~1
 */
@property(nonatomic, assign) float temperature;

/**
 * Comments extracted from cpp files:
 *
 * -1~1
 */
@property(nonatomic, assign) float tint;

@end

NS_ASSUME_NONNULL_END

