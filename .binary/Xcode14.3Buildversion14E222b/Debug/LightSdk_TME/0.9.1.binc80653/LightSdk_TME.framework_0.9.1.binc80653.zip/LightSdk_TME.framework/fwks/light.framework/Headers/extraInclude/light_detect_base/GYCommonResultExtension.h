﻿//
//  GYCommonResultExtension.h
//  用于扩展 DetectItemBaseFrame 和 GYDetectCommonResultStruct
//
//  Created by gennyxu on 2022/1/5.
//  Copyright © 2022 Tencent. All rights reserved.
//

#pragma once

#include <light_detect_base/GYDetectBaseProtocol.h>
#include <light_detect_base/utils.h>
#include <algorithm>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <utility>
#include <vector>

GYAILIB_NAMESPACE_START

#pragma mark - frame to result

// @brief 将 frames转为 DetectCommonResult
static inline void ConvertBaseFramesToResult(const std::vector<DetectItemBaseFrame> &frame_list,
                                             GYDetectCommonResultStruct *output,
                                             bool reverse = false) {
  output->items.resize(frame_list.size());

  if (!reverse) {
    for (auto i = 0; i < frame_list.size(); ++i) {
      output->items[i].frame = frame_list[i];
    }
  } else {
    for (auto i = static_cast<int>(frame_list.size()) - 1; i >= 0; --i) {
      output->items[i].frame = frame_list[i];
    }
  }
}

GYAILIB_NAMESPACE_END
