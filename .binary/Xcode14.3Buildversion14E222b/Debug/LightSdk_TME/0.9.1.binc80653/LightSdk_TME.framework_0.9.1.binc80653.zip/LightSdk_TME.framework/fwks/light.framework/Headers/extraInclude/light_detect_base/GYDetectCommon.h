﻿//
//  GYDetectCommon.h
//  GYDetectCommon
//
//  Created by gennyxu on 2020/2/26.
//  Copyright © 2020 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/base/gyai_error_report.h>
#include <light_ai_base/GYAIBase.h>
#include <light_detect_base/GYCommonResultExtension.h>
#include <light_detect_base/GYDetectCommonHandler.h>
#include <light_detect_base/GYDetectCommonPublic.h>
#include <light_detect_base/GYImageDataMatExtension.h>
#include <light_detect_base/gyai_memory_util.h>
#include <light_detect_base/gyai_thread_queue.h>
#include <light_detect_base/gy_file_extension.h>
#include <light_detect_base/utils.h>
