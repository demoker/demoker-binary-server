/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKTransition.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKPAGScaleMode.h"
#import "LAKTransitionType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKTransition : LAKComponent

@property(nonatomic, assign) NSInteger firstIndex;

@property(nonatomic, assign) NSInteger lastIndex;

@property(nonatomic, assign) NSInteger duration;

@property(nonatomic, assign) LAKPAGScaleMode scaleMode;

@property(nonatomic, assign) LAKTransitionType renderType;

/**
 * Comments extracted from cpp files:
 *
 * 统一是用src去LoadResourceFromKey加载
 */
@property(nonatomic, strong) NSString *src;

@end

NS_ASSUME_NONNULL_END

