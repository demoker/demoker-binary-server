// Copyright 2020 Tencent Inc. All Rights Reserved.
//  LightCameraConfig.h
//  light
//
//  Created by zongyang on 2020/8/30.
//

#ifndef PLATFORM_IOS_LIGHTCAMERACONFIG_H_
#define PLATFORM_IOS_LIGHTCAMERACONFIG_H_

#import "Definitions.h"
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import "LightListeners.h"
#import "LightConfig.h"

@interface LightCameraConfig : LightConfig


///输入相机纹理
- (void)setCameraTexture:(int)cameraTexture width:(int)width height:(int)height;

///输入相机纹理
- (void)setCameraTexture:(int)cameraTexture width:(int)width height:(int)height orientation:(kLightDeviceCameraOrientation)orientation;

/// 异常帧检测频率
- (void)setAbnormalFrameDetectFrequency:(int)frequency;

/**
 * 设置相机纹理
 *
 * @param cameraTexture 相机纹理
 * @param width 宽度
 * @param height 高度
 * @param orientation 相机纹理被旋转的角度（逆时针）
 * @param origin 相机纹理坐标(0,0)点位置 BottomLeft / TopLeft
 */
- (void)setCameraTexture:(int)cameraTexture width:(int)width height:(int)height orientation:(kLightDeviceCameraOrientation)orientation origin:(kLightImageOrigin)origin;

/// 设置旋转回调
/// @param deviceOrientation 设备方向
- (void)sensorOrientationChanged:(kLightDeviceCameraOrientation)deviceOrientation;

/// 设置旋转回调角度 通过这个接口设置进来会有手机处于45°角度的横竖屏优化
/// @param orientationAngle 设备旋转回调的角度
- (void)sensorOrientationAngleChanged:(double)orientationAngle;

/// 相机方向
/// @param capturePosition 摄像头方向
- (void)cameraSwitched:(AVCaptureDevicePosition)capturePosition;

/// 标志当前lightsdk的滤镜链是在什么环境下跑
/// @param status 预览、录像或拍照
- (void)setLightSDKEnvironment:(LightEnvironmentConfigKey)status;


@end
#endif
