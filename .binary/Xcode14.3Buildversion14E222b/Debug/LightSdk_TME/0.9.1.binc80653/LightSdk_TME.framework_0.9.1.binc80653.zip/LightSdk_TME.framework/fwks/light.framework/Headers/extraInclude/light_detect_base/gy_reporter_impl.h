//
//  gy_reporter_impl.h
//  用于LightCV的数据上报
//
//  Created by atilazhang on 2021/12/29.
//  Copyright © 2021 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/GYAIBase.h>
#include <unordered_map>
#include <string>

#ifdef __ANDROID__
#include <jni.h>  // NOLINT
#endif

GYAILIB_NAMESPACE_START

#ifdef __ANDROID__
void GYJNIOnUnload(JavaVM*, void*);
jint GYJNIOnLoad(JavaVM* vm, void*);
#endif

class GYReporterImpl {
 public:
  static void ReportInternal(const std::string& event,
                             const std::unordered_map<std::string, std::string>& report_items);
};

GYAILIB_NAMESPACE_END
