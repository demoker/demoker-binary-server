﻿//  gyai_time_log.h
//  耗时计算使用
//
//  Created by gennyxu on 2020/6/6.
//  Copyright © 2020 Tencent. All rights reserved.
//

#pragma once
#ifdef WIN32
#include <Winsock2.h>
#endif
#include <light_ai_base/gyai_macro_t.h>
#ifdef WIN32
#include <stdint.h>
#include <ctime>
#else
#include <sys/time.h>
#endif
#ifdef _MSC_VER
typedef unsigned __int32 uint32_t;
typedef unsigned __int64 uint64_t;
#else
#include <stdint.h>
#endif
GYAILIB_NAMESPACE_START

/**
 * 有些计时代码频繁调用耗时会增加较大（不过总体而言，函数影响算是比较小的）。
#define NUMBER_TIME_TEST_LOOP  100000000
// 论优先级，耗时计算代码性能：100000000次 (Mac2013 macOS10.15)
// CACurrentMediaTime()  2.5ms (iOS/macOS only)
// struct timeval begin, end; gettimeofday(&begin, NULL);  2.86ms
// struct timeval end; gettimeofday(&end, &zone);  3.94ms
// struct timespec start, end; clock_gettime(CLOCK_UPTIME_RAW, &start);  4.5ms
// struct timespec start, end; clock_gettime(CLOCK_REALTIME, &start);  4.17ms
// struct timespec start, end; clock_gettime(CLOCK_MONOTONIC, &start);  7.09ms
// auto start = std::chrono::steady_clock::now();  7.32ms
// time_t start, end;  time (&start);  16ms
// clock_t begin = clock();  44.xms+

// 论优先级，耗时计算代码性能：100000000次 (iPhone11 iOS13)
// CACurrentMediaTime()  2.9ms (iOS/macOS only)
// struct timeval begin, end; gettimeofday(&begin, NULL);  3.3ms
// time_t start, end;  time (&start);  4.3ms
// struct timeval end; gettimeofday(&end, &zone);  4.5ms
// struct timespec start, end; clock_gettime(CLOCK_REALTIME, &start);  4.0ms
// struct timespec start, end; clock_gettime(CLOCK_UPTIME_RAW, &start);  4.4ms
// struct timespec start, end; clock_gettime(CLOCK_MONOTONIC, &start);  5.4ms
// auto start = std::chrono::steady_clock::now();  6.79ms
// clock_t begin = clock();  19.xms+
*/
#ifdef WIN32
// 计算耗时使用，内部方法和测试代码使用，为了方便，提取到公共位置。
// MSVC defines this in winsock2.h!?
static int gettimeofday(struct timeval* tp, struct timezone* tzp) {
  // Note: some broken versions only have 8 trailing zero's, the correct epoch has 9 trailing zero's
  // This magic number is the number of 100 nanosecond intervals since January 1, 1601 (UTC)
  // until 00:00:00 January 1, 1970
  static const uint64_t EPOCH = ((uint64_t)116444736000000000ULL);

  SYSTEMTIME system_time;
  FILETIME file_time;
  uint64_t time;

  GetSystemTime(&system_time);
  SystemTimeToFileTime(&system_time, &file_time);
  time = ((uint64_t)file_time.dwLowDateTime);
  time += ((uint64_t)file_time.dwHighDateTime) << 32;

  tp->tv_sec = (int32_t)((time - EPOCH) / 10000000L);
  tp->tv_usec = (int32_t)(system_time.wMilliseconds * 1000);
  return 0;
}
#endif

class GYAI_PUBLIC Timer {
 public:
  Timer() { Start(); }
  void Start() { gettimeofday(&start_, NULL); }


  // 返回耗时单位为ms，并更新start的时间
  float Tick(bool update_time = true) {
    struct timeval end;
    gettimeofday(&end, NULL);

    float delta = (end.tv_sec - start_.tv_sec) * 1000.0 + (end.tv_usec - start_.tv_usec) / 1000.0;
    if (update_time) {
      start_ = end;
    }
    return delta;
  }

  // 返回耗时单位为秒，并更新start的时间
  float TickSecond(bool update_time = true) {
    struct timeval end;
    gettimeofday(&end, NULL);
    double delta = (end.tv_sec - start_.tv_sec) + (end.tv_usec - start_.tv_usec) * 1e-6;
    if (update_time) {
      start_ = end;
    }
    return delta;
  }

 private:
  struct timeval start_;
};

GYAILIB_NAMESPACE_END
