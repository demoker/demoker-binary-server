/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKPinchFace.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKPointItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKPinchFace : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * tme kwok wai
 * 最新编辑的点位
 */
@property(nonatomic, strong) NSArray<LAKPointItem *> *points;

/**
 * Comments extracted from cpp files:
 *
 * 上一次编辑的点位
 */
@property(nonatomic, strong) NSArray<LAKPointItem *> *lastPoints;

/**
 * Comments extracted from cpp files:
 *
 * 强度
 */
@property(nonatomic, assign) float strength;

/**
 * Comments extracted from cpp files:
 *
 * 是否对称编辑
 */
@property(nonatomic, assign) BOOL symmetry;

/**
 * Comments extracted from cpp files:
 *
 * 是否锁定关键点
 */
@property(nonatomic, assign) BOOL fixPoints;

@property(nonatomic, assign) BOOL editMode;

/**
 * Comments extracted from cpp files:
 *
 * 捏脸点位画布的宽
 */
@property(nonatomic, assign) NSInteger width;

/**
 * Comments extracted from cpp files:
 *
 * 捏脸点位画布的高
 */
@property(nonatomic, assign) NSInteger height;

@end

NS_ASSUME_NONNULL_END

