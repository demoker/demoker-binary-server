//  GYCVReporter.h
//  用于LightCV的数据上报
//
//  Created by atilazhang on 2021/12/29.
//  Copyright © 2021 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

/// 灯塔上报管理单例
@interface GYCVReporter : NSObject

+ (GYCVReporter *)shareInstance;
- (void)reportData:(NSString*)event params:(NSDictionary*)params;

@end
