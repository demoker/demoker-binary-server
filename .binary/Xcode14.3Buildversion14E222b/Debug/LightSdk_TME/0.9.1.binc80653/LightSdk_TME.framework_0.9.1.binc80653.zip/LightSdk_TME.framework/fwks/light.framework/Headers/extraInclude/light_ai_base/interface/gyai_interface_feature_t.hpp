﻿//  gyai_interface_feature_t.hpp
//  修改参数设定
//
//  Created by gennyxu on 2021/1/28.
//  Copyright © 2021 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/base/gyai_transform_t.h>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>
#include <light_ai_base/interface/gyai_interface_keys_t.hpp>

GYAILIB_NAMESPACE_START

#pragma mark - Base feature接口协议的定义

/* @brief 该接口协议主要为了方便部分AI能力需要输入特定参数而增加——主要为框、点、检测图大小。
 * 所有模块的输入feature 都由该协议完成（包括人脸、手等） */
class GYAI_PUBLIC DetectFeatureProtocol : public BaseData {
 public:
  DetectFeatureProtocol() { cls_type_ = BaseDataClassTypeFeature; }

 public:
  // @brief 获取当前features的数量，输入的协议必须实现该字段（返回0通常该功能不执行）
  virtual size_t GetFeaturesCount() = 0;  // 获取目标数量（如多人，多手；需遍历单独处理）
  // 获取当前对象traceID（比如人脸检测ID）
  virtual int GetTraceID(int idx) { return -1; }
  virtual DetectFeatureProtocol *GetFeatureAtIndex(int idx) = 0;  // 获取对应位置的feature
  virtual GYAISize2f GetFeatureImageSize(int idx) = 0;  // 获取参考坐标系大小
  virtual GYAIRect4f GetFeatureFrame(int idx) = 0;  // 获取目标所在坐标系下的位置

  // @brief 获取feature4f/2f点数量 (坐标为ImageSize下坐标系，根据功能可能会用于需缩放点)
  virtual size_t GetFeaturePointCount(int idx) = 0;
  virtual GYPoint4fPtr GetFeaturePoint4f(int idx) = 0;  // 返回float[4]地址指针
  virtual GYPoint2fPtr GetFeaturePoint2f(int idx) = 0;  // 返回float[2]地址指针

  // @brief 默认feature所属的方向 (如人脸坐标系和图片不同，需自行旋转；需要确认底层是否实现)
  virtual DeviceOrientation GetFeatureOrientation(int idx) { return DeviceOrientationUp; }
};

#pragma mark - 基础feature的定义

class DetectBaseParams : public DetectFeatureProtocol {
 public:
  // 接口扩展：如获取默认 DetectFeatureProtocol-feature
  size_t GetFeaturesCount() override { return 1; }
  DetectFeatureProtocol *GetFeatureAtIndex(int idx) override { return this; }
  int GetTraceID(int idx) override { return trace_id; }
  size_t GetFeaturePointCount(int idx) override { return point.size(); }
  GYPoint4fPtr GetFeaturePoint4f(int idx) override { return (GYPoint4fPtr)(point.data()); }
  GYPoint2fPtr GetFeaturePoint2f(int idx) override { return nullptr; }
  GYAIRect4f GetFeatureFrame(int idx) override { return frame.rect4f; }
  GYAISize2f GetFeatureImageSize(int idx) override {
    return GYAISize2fMake(image_width, image_height);
  }

 public:
  int trace_id = 0;  // 多元素时，用于区分某一个元素（id相同则为同一个人：需网络支持）
  // image_width/height为feature 对应的坐标系，方便部分模块需要切换。
  float image_width = 0, image_height = 0;  // detect image's imageSize

  // frame和bounds 为了兼容不同语法层的调用 （人脸bounds\猫frame通用结构）。
  DetectItemBaseFrame frame = {
      { {0, 0, 0, 0}, }, /*.confidence =*/ 0,
  };  // item rect in image size

  float confidence = 0;  // 点总体置信度（部分模块只有总体置信度，没有单独点）
  // xyz的坐标，可存3D点 (z在2d点时不可用，为随机值；w为置信度或vis状态，根据功能支持而定）
  std::vector<GYAIPoint4f> point;

  float euler[4] = {0};  // xyz三维的欧拉角w （计算矩阵、扩展用）
  int age = -1;          // 年龄扩展：>0=正常, other=unknown
  int gender = -1;       // 性别扩展：0=female, 1=male; other=unknown
};

#pragma mark - Forward input protocol

// @brief 用于Forward的输入数据——图片、feature（人脸、手；各模块要求不同）等数据
// 备注：建议上层实现该协议轻量类，智能指针指向ImageData\Feature（可防止执行期间Agent等被释放）
class DetectInputProvider {
 public:
  // @brief 获取输入数据数量（如多人，多手；需遍历单独处理；目前模块基本只有单输入，扩展用)
  // (因大部分模块只有单输入，idx=0，所以该方法可暂时返回1)
  virtual size_t GetDetectInputDataCount() = 0;

  // @brief 获取输入位置@idx的图片或feature（类型由key值、配置决定）
  // @params key 区分输入数据，以及类型或所属的blob (支持key值通常固定，或由模型、config决定)
  // 备注：如 "kForwardInputKeyImage/Face" 通常用于输入 "Image/人脸"数据。
  virtual BaseData *GetDetectObject(int idx, const std::string &key) = 0;

  // @brief 获取输入位置@idx的图片数据 （大部分只有单输入，idx、key无意义）
  // @params key 区分输入数据类型、所属的blob等 (支持key值通常固定，或由模型、config决定)
  virtual GYImageData *GetDetectImageData(int idx, const std::string &key) = 0;

  // @brief 获取对应输入位置@idx的feature (通常人脸相关模块需要传入人脸feature)
  // @params key 区分需要的参数类型，如"face"\"hand"等（目前主要人脸居多）
  virtual DetectFeatureProtocol *GetDetectFeatureInput(int idx, const std::string &key) = 0;
};

#pragma mark - 常用的feature方向和点缩放

// @brief 将 @oldSize坐标系下点 @points 适配新的 ImageData 的orientation，同时缩放到其坐标系大小。
void RotatePointsToNewImageDataCoords(GYPoint2fPtr points, size_t pointsNum, GYAISize2f oldSize,
                                      GYImageData *dstCoordData);
// @brief 将 @oldSize坐标系下点 @rect 适配新的 ImageData 的orientation，同时缩放到其坐标系大小。
void RotateRectToNewImageDataCoords(GYAIRect4f *pf, GYAISize2f oldSize, GYImageData *dstCoordData);

#pragma mark - 判断网络Dims是否合法

// @brief 判断网络要求的输入、输出大小 @dims [in]（nchw） 是否合法。
// @params dims [in] 网络要求的输入、输出大小（nchw），初始化成功会赋值
static inline bool BlobDimsIsValid(const std::vector<int> &dims) {
  return dims.size() >= 4 && dims[0] > 0 && dims[1] > 0 && dims[2] > 0 && dims[3] > 0;
}

GYAILIB_NAMESPACE_END
