/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKCamera3DProjectionType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKCamera3DProjectionType) {
    LAKCamera3DProjectionTypePERSPECTIVE = 0,
    LAKCamera3DProjectionTypeORTHOGRAPHIC = 1
};

@interface LAKCamera3DProjectionTypeStringConverter : NSObject
+ (NSString *)toString:(LAKCamera3DProjectionType)camera3DProjectionType;
+ (LAKCamera3DProjectionType)fromString:(NSString *)string;
@end

NS_ASSUME_NONNULL_END

