/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKFaceBindingComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKBindTrackingType.h"
#import "LAKComponent.h"
#import "LAKVec3.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKFaceBindingComponent : LAKComponent

@property(nonatomic, assign) LAKBindTrackingType trackingType;

@property(nonatomic, strong) LAKVec3 *posOffset;

@end

NS_ASSUME_NONNULL_END

