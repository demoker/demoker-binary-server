/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKFaceTracking.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKTrackingComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKFaceTracking : LAKTrackingComponent

@property(nonatomic, assign) BOOL isWaitFirstFrameDetect;

@property(nonatomic, assign) BOOL isAllFrameDetect;

/**
 * Comments extracted from cpp files:
 *
 * 320：re-fine：默认开启时使用高等级模型。关闭时会给低端机适配低等级模型，效果换性能
 */
@property(nonatomic, assign) BOOL isRefine;

/**
 * Comments extracted from cpp files:
 *
 * 素材需要在人脸上Z轴的偏移量，+代表往前，-代表往后
 */
@property(nonatomic, assign) float zOffset;

/**
 * Comments extracted from cpp files:
 *
 * 默认都有效
 */
@property(nonatomic, strong) NSArray<NSNumber *> *faceIndex;

/**
 * Comments extracted from cpp files:
 *
 * "male"/"female"/"", 与 Face2DInfo 里的gender_的值保持一致
 */
@property(nonatomic, strong) NSString *genderBinding;

@property(nonatomic, assign) NSInteger maxTrackingNum;

@end

NS_ASSUME_NONNULL_END

