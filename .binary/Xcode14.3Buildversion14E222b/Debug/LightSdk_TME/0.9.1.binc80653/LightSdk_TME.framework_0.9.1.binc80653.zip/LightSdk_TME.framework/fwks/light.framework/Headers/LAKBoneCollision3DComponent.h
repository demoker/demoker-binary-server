/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBoneCollision3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKBoneCollisionObj.h"
#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKBoneCollision3DComponent : LAKComponent

@property(nonatomic, strong) NSArray<LAKBoneCollisionObj *> *collision_objs;

@property(nonatomic, strong) NSArray<NSArray<NSString *> *> *bone_constraints;

@end

NS_ASSUME_NONNULL_END

