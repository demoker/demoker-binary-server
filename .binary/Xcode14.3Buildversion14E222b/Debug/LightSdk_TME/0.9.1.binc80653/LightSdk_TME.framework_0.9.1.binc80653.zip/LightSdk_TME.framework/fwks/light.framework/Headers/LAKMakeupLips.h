/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMakeupLips.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKLipsType.h"
#import "LAKMakeupVisMethod.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMakeupLips : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 嘴唇mask图片
 */
@property(nonatomic, strong) NSString *lipsMask;

/**
 * Comments extracted from cpp files:
 *
 * 唇彩颜色设置方式
 */
@property(nonatomic, assign) LAKLipsType lipsType;

/**
 * Comments extracted from cpp files:
 *
 * 通过lut设置颜色
 */
@property(nonatomic, strong) NSString *lipsLut;

/**
 * Comments extracted from cpp files:
 *
 * 通过#RRGGBBAA直接配置color
 */
@property(nonatomic, strong) NSString *lipsColor;

/**
 * Comments extracted from cpp files:
 *
 * 通过图片配置唇彩颜色
 */
@property(nonatomic, strong) NSString *lipsImage;

/**
 * Comments extracted from cpp files:
 *
 * 0：拍摄器， 1：直播， 2：禁用可见性
 */
@property(nonatomic, assign) LAKMakeupVisMethod visMethod;

/**
 * Comments extracted from cpp files:
 *
 * 遮挡出框最低的妆容透明度，支持素材配置
 */
@property(nonatomic, assign) float minVisibility;

@end

NS_ASSUME_NONNULL_END

