/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKUE4ComponentV2.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKAnimojiMode.h"
#import "LAKBodyMode.h"
#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKUE4ComponentV2 : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * UE4场景相关
 */
@property(nonatomic, strong) NSString *pakPath;

@property(nonatomic, strong) NSString *openMapName;

@property(nonatomic, assign) BOOL checkVersion;

/**
 * Comments extracted from cpp files:
 *
 * [serialization]
 */
@property(nonatomic, assign) float horizontalFOV;

/**
 * Comments extracted from cpp files:
 *
 * 首帧延迟渲染帧数，避免UE层初始化未成功时显示错误的问题
 */
@property(nonatomic, assign) NSInteger delayRenderFrames;

@property(nonatomic, assign) BOOL isAbilitySlamARNeeded;

@property(nonatomic, assign) BOOL isAbilityFaceTrackNeeded;

@property(nonatomic, assign) BOOL isAbilityExpressionNeeded;

@property(nonatomic, assign) BOOL isAbilityBodyDriveNeeded;

@property(nonatomic, assign) BOOL isAbilityHandDriveNeeded;

/**
 * Comments extracted from cpp files:
 *
 * 目前只用在 kLightSDK mode 下使用
 */
@property(nonatomic, assign) LAKAnimojiMode animojiType;

/**
 * Comments extracted from cpp files:
 *
 * or HalfBodyMode
 */
@property(nonatomic, assign) LAKBodyMode bodyDriveMode;

/**
 * Comments extracted from cpp files:
 *
 * Login time limit, in seconds. If set 0, won't wait for login callback
 */
@property(nonatomic, assign) NSInteger loginTimeOut;

@end

NS_ASSUME_NONNULL_END

