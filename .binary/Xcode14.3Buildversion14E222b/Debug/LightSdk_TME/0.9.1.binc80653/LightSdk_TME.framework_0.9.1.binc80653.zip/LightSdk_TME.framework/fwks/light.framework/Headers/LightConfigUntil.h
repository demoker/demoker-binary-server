//
// Copyright 2020 Tencent Inc. All Rights Reserved.
// Created by chenmo on 2020/11/23.
//

#import <Foundation/Foundation.h>
#include "LightListeners.h"
#include "Definitions.h"

@interface LightConfigUntil : NSObject

@property (nonatomic, strong) NSMapTable<NSString *, id<LightWatermarkDataListener>> *watermarkerListeners;

+ (instancetype)sharedInstance;

@end
