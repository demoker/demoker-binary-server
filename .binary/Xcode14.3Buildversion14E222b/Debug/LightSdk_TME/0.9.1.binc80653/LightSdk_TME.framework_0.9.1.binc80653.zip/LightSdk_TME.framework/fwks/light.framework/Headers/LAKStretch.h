/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKStretch.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKStretch : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 基础大眼瘦脸
 */
@property(nonatomic, assign) float basicFace;

/**
 * Comments extracted from cpp files:
 *
 * v脸
 */
@property(nonatomic, assign) float vFace;

/**
 * Comments extracted from cpp files:
 *
 * 下巴
 */
@property(nonatomic, assign) float chin;

/**
 * Comments extracted from cpp files:
 *
 * 瘦脸
 */
@property(nonatomic, assign) float thinFace;

/**
 * Comments extracted from cpp files:
 *
 * 短脸
 */
@property(nonatomic, assign) float shortFace;

/**
 * Comments extracted from cpp files:
 *
 * 瘦颧骨
 */
@property(nonatomic, assign) float cheekboneThin;

/**
 * Comments extracted from cpp files:
 *
 * 大眼
 */
@property(nonatomic, assign) float enlargeEye;

/**
 * Comments extracted from cpp files:
 *
 * 鼻子大小
 */
@property(nonatomic, assign) float noseSize;

/**
 * Comments extracted from cpp files:
 *
 * 额头
 */
@property(nonatomic, assign) float foreHead;

/**
 * Comments extracted from cpp files:
 *
 * 眼距
 */
@property(nonatomic, assign) float eyeDistance;

/**
 * Comments extracted from cpp files:
 *
 * 眼角
 */
@property(nonatomic, assign) float eyeAngle;

/**
 * Comments extracted from cpp files:
 *
 * 鼻翼
 */
@property(nonatomic, assign) float noseWing;

/**
 * Comments extracted from cpp files:
 *
 * 鼻子位置
 */
@property(nonatomic, assign) float noseHeight;

/**
 * Comments extracted from cpp files:
 *
 * 嘴巴大小
 */
@property(nonatomic, assign) float mouthSize;

/**
 * Comments extracted from cpp files:
 *
 * 嘴唇宽度
 */
@property(nonatomic, assign) float mouthWidth;

/**
 * Comments extracted from cpp files:
 *
 * 嘴唇厚度
 */
@property(nonatomic, assign) float mouthHeight;

/**
 * Comments extracted from cpp files:
 *
 * 嘴唇位置
 */
@property(nonatomic, assign) float mouthPosition;

@end

NS_ASSUME_NONNULL_END

