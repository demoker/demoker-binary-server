/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKDebug3dMeshHighlightComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKDebug3dMeshHighlightComponent : LAKSerializable

@property(nonatomic, assign) BOOL highlight;

@end

NS_ASSUME_NONNULL_END

