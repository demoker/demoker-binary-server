/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKManipulateComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKManipulateComponent : LAKComponent

@property(nonatomic, assign) BOOL enableScale;

@property(nonatomic, assign) BOOL enableRotation;

@property(nonatomic, assign) BOOL enableDrag;

@property(nonatomic, assign) float minDistance;

@property(nonatomic, assign) float maxDistance;

@property(nonatomic, assign) float minScale;

@property(nonatomic, assign) float maxScale;

@end

NS_ASSUME_NONNULL_END

