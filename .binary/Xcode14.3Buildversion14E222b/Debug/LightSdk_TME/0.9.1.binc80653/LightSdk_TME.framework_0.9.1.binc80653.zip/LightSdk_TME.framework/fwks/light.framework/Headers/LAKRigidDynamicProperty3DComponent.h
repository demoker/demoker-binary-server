/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKRigidDynamicProperty3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKVec3.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKRigidDynamicProperty3DComponent : LAKComponent

@property(nonatomic, assign) BOOL independent_gravity_enabled_;

/**
 * Comments extracted from cpp files:
 *
 * 本刚体的独立重力加速度
 */
@property(nonatomic, strong) LAKVec3 *independent_gravity_;

@property(nonatomic, strong) LAKVec3 *force_;

@property(nonatomic, strong) LAKVec3 *torque_;

@property(nonatomic, strong) LAKVec3 *linear_impulse_;

@property(nonatomic, strong) LAKVec3 *angular_impulse_;

@end

NS_ASSUME_NONNULL_END

