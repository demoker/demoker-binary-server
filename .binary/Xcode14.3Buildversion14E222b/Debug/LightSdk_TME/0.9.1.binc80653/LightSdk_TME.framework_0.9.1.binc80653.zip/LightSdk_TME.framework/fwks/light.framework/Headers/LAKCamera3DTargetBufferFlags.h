/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKCamera3DTargetBufferFlags.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKCamera3DTargetBufferFlags) {
    LAKCamera3DTargetBufferFlagsNONE = 0,
    LAKCamera3DTargetBufferFlagsCOLOR = 1,
    LAKCamera3DTargetBufferFlagsDEPTH = 2,
    LAKCamera3DTargetBufferFlagsSTENCIL = 4,
    LAKCamera3DTargetBufferFlagsALL = 7
};

@interface LAKCamera3DTargetBufferFlagsStringConverter : NSObject
+ (NSString *)toString:(LAKCamera3DTargetBufferFlags)camera3DTargetBufferFlags;
+ (LAKCamera3DTargetBufferFlags)fromString:(NSString *)string;
@end

NS_ASSUME_NONNULL_END

