/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKFaceInset.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKRect.h"
#import "LAKVec2.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKFaceInset : LAKComponent

@property(nonatomic, strong) LAKRect *cutRange;

@property(nonatomic, strong) NSString *maskResource;

@property(nonatomic, assign) float Flip;

@property(nonatomic, strong) LAKVec2 *scale;

@property(nonatomic, strong) NSString *stretchResource;

@property(nonatomic, strong) NSString *renderTarget;

@property(nonatomic, strong) NSString *modelVersion;

@end

NS_ASSUME_NONNULL_END

