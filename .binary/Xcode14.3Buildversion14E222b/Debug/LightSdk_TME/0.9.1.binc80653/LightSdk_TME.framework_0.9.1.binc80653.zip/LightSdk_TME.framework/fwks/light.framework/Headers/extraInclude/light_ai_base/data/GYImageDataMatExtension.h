﻿//
//  GYImageDataMatExtension.h
//  GYImage和CVMat的扩展
//
//  Created by gennyxu on 2020/11/10.
//  Copyright © 2020 Tencent. All rights reserved.
//
#pragma once

#include <light_ai_base/GYAIBase.h>
#include <algorithm>
#include <string>
#include <vector>
#include <opencv2/opencv.hpp>

GYAILIB_NAMESPACE_START

// 所有方法内部不会校验：dataType是否为image。
// 将输入的图片转为内部使用的Gray（8UC1），输出指针非空。
GYAI_PUBLIC GYAIStatus GYAIImageDataToGrayMat(const GYImageData &inputMat, cv::Mat *gray);

// 将输入的图片转为内部使用的RGBA/BGRA（8UC4），输出指针非空。
GYAI_PUBLIC GYAIStatus GYAIImageDataToBGRAMat(const GYImageData &inputMat, cv::Mat *bgra);
GYAI_PUBLIC GYAIStatus GYAIImageDataToRGBAMat(const GYImageData &inputMat, cv::Mat *rgba);

// 将输入的图片转为内部使用的RGB/BGR（8UC3），输出指针非空。
GYAI_PUBLIC GYAIStatus GYAIImageDataToBGRMat(const GYImageData &inputMat, cv::Mat *bgr);
GYAI_PUBLIC GYAIStatus GYAIImageDataToRGBMat(const GYImageData &inputMat, cv::Mat *rgb);



// 内部并不会判断矩阵是否为标准矩阵：会强行执行操作，通常CPU旋转大图都比较忙。
void CVMatApplyTransform(const cv::Mat &mat, cv::Mat *output, const GYAffineTransform &t);
void CVMatApplyOrientation(const cv::Mat &mat, cv::Mat *output, DeviceOrientation ori);

void GYAIRotateMatToPreferOrientation(const cv::Mat &oriMat, DeviceOrientation oriMatOri,
                                      cv::Mat *output, DeviceOrientation preferOri);

#pragma mark - Create from Mat

/* @brief 根据Mat和其格式创建默认的输入数据
 * @params mat 用于创建的mat，使用期宽高和data
 * @params format即mat的数据格式
 * */
GYAI_PUBLIC GYImageData GYImageDataCreateFromMat(const cv::Mat &mat, DataFormat format);

// 用于快速赋值操作方法，主要赋值宽高、data、和bytesPreRow (内部会assert，请保证指针和mat合法)
GYAI_PUBLIC void GYImageDataCreateFromMat(GYImageData *data, const cv::Mat &mat, DataFormat format);

/* @brief 主要用于context指向需要释放的地址。
 *   auto mat = new cv::Mat(...);
 *   ....
 *   auto imageData = new GYImageData();
 *   GYImageDataCreateFromMat(imageData, *mat, ...);  // 赋值mat.data给image
 *   imageData->context = mat;  // 赋值真正需要释放的对象mat
 *   imageData->deallocCallBack = &GYImageDataCallBackDeleteCVMat;
 * */
static inline void GYImageDataCallBackDeleteCVMat(GYImageData *image) {
  if (image && image->context) {
    auto *mat = static_cast<cv::Mat *>(image->context);
    image->context = nullptr;
    image->data = nullptr;
    delete mat;
  }
}

#pragma mark - aspect scale mat

/* @brief 检测Mat是否长边越界了，将其缩放到满足条件的边界下。
 * 备注：上层调用也可以使用 TestCheckAspectResizeMat 测试方法
 * */
static inline void MatScaleAspectWithMaxEdge(const cv::Mat &mat, cv::Mat *result, int max_edge,
                                             int interpolation = cv::INTER_LINEAR) {
  if ((std::max)(mat.cols, mat.rows) > max_edge) {
    float rows = static_cast<float>(mat.rows * 1.0 / (std::max)(mat.cols, mat.rows) * max_edge);
    float cols = static_cast<float>(mat.cols * 1.0 / (std::max)(mat.cols, mat.rows) * max_edge);
    cv::resize(mat, *result, cv::Size(cols, rows), 0, 0, interpolation);
  } else if (&mat != result) {
    *result = mat;
  }
}

GYAILIB_NAMESPACE_END
