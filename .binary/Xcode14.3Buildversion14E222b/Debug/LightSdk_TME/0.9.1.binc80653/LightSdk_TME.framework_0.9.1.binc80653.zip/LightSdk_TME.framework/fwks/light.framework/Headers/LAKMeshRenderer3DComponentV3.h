/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMeshRenderer3DComponentV3.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKSubMeshConfig.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMeshRenderer3DComponentV3 : LAKComponent

@property(nonatomic, assign) BOOL receiveShadow;

@property(nonatomic, assign) BOOL castShadow;

@property(nonatomic, assign) NSInteger priority;

@property(nonatomic, assign) BOOL frustumCulling;

@property(nonatomic, strong) NSString *meshResourceKey;

@property(nonatomic, strong) NSArray<LAKSubMeshConfig *> *subMeshConfigs;

@property(nonatomic, strong) NSString *skinInfoResourceKey;

@end

NS_ASSUME_NONNULL_END

