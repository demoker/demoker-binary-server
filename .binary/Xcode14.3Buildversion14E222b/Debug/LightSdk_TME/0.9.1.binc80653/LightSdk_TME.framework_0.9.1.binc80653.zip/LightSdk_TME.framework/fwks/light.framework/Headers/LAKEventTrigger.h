/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKEventTrigger.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKTimeOffsetType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKEventTrigger : LAKComponent

@property(nonatomic, strong) NSString *event;

@property(nonatomic, assign) NSInteger startOffset;

@property(nonatomic, assign) LAKTimeOffsetType timeOffsetType;

@end

NS_ASSUME_NONNULL_END

