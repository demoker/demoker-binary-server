/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMeshRenderer3DComponentV2.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKPrimitiveConfigV2.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMeshRenderer3DComponentV2 : LAKComponent

@property(nonatomic, assign) BOOL receiveShadow;

@property(nonatomic, assign) BOOL castShadow;

@property(nonatomic, assign) NSInteger priority;

@property(nonatomic, assign) BOOL frustumCulling;

@property(nonatomic, strong) NSString *meshName;

@property(nonatomic, assign) NSInteger meshIndex;

@property(nonatomic, assign) BOOL skinned;

@property(nonatomic, strong) NSArray<LAKPrimitiveConfigV2 *> *primitiveConfigs;

@end

NS_ASSUME_NONNULL_END

