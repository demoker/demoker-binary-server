/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKRayCast3dComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKRayCast3dComponent : LAKSerializable

@end

NS_ASSUME_NONNULL_END

