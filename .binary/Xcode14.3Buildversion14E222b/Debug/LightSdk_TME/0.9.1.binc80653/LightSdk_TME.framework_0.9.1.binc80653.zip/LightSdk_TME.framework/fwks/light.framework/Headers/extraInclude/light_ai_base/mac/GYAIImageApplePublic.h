﻿//
//  GYAIImageApplePublic.h
//  该类定义为Apple-NSImage/UIImage一些常用定义。
//
//  Created by gennyxu on 2020/10/30.
//  Copyright © 2020 tencent. All rights reserved.
//

#pragma once

#ifdef __APPLE__

// clang-format off
#include <Metal/Metal.h>
#if TARGET_OS_OSX
# include <AppKit/AppKit.h>
# define GYAIImputImageClass NSImage  // NOLINT
#else
# include <UIKit/UIKit.h>
# define GYAIImputImageClass UIImage  // NOLINT
#endif
// clang-format on

#if defined(__has_attribute) && __has_attribute(objc_subclassing_restricted)
# define GYAI_OBJC_CLASS_FINAL __attribute__((objc_subclassing_restricted))
#else
# define GYAI_OBJC_CLASS_FINAL
#endif

#endif  // #ifdef __APPLE__
