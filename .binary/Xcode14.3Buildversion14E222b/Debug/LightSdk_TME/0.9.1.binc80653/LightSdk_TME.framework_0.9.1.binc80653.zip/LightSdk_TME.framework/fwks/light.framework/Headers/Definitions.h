//
//  Definitions.h
//  light-sdk
//
//  Created by zongyang on 2020/8/15.
//

#ifndef DEFINITIONS_H
#define DEFINITIONS_H
#import <CoreMedia/CoreMedia.h>
#import <SceneKit/SceneKit.h>

typedef NS_ENUM(NSInteger, LightSourceType) {
    LightSourceTypeVideo = 0,
    LightSourceTypePhoto,
    LightSourceTypeMultiMedia
};

typedef NS_ENUM(NSInteger, LightScaleMode) {
    LightScaleModeDefault = -1,
    LightScaleModeNone = 0,
    LightScaleModeStretch,
    LightScaleModeLetterBox,
    LightScaleModeZoom
};

typedef NS_ENUM(NSInteger, LightClipAssetType) {
    LightClipAssetTypeVideoClip = 0,
    LightClipAssetTypePhotoClip,
    LightClipAssetTypeTemplateClip
};

typedef NS_ENUM(NSInteger, LightCmShowAnimojiExpressionType) {
    LightCmShowAnimojiExpressionTypeNONE = 0,   // 无表情
    LightCmShowAnimojiExpressionTypeBasic = 1,   // 基础表情只包含高优先级表情(8个）
    LightCmShowAnimojiExpressionTypeMiddle = 2,  // 高中优先级表情(8+5)
    LightCmShowAnimojiExpressionTypeALL = 3     // 全表情
};

typedef NS_ENUM(NSInteger, LightCmShowMaterialDisplayType) {
    // 全部隐藏
    LightCmShowMaterialDisplayTypeNone,
    // 全部显示
    LightCmShowMaterialDisplayTypeAll,
    // 只显示头部
    LightCmShowMaterialDisplayTypeHead
};

typedef NS_ENUM(NSInteger, LightCmShowCameraViewType) {
    // 全身视角
    LightCmShowCameraViewTypeBody = 0,
    // 脸部视角
    LightCmShowCameraViewTypeHead = 1
};

typedef NS_ENUM(NSInteger, kLightImageOrigin) {
    kLightImageOriginTopLeft  = 0,
    kLightImageOriginBottomLeft = 1,
};

typedef NS_ENUM(NSInteger, kLightDeviceCameraOrientation) {
    kLightCameraRotation0  = 0,
    kLightCameraRotation90 = 1,
    kLightCameraRotation180 = 2,
    kLightCameraRotation270 = 3,
};

typedef NS_ENUM(NSUInteger, LightTouchEventType) {
  LightTouchEventBegan,
  LightTouchEventMoved,
  LightTouchEventEnded,
  LightTouchEventCancelled
};

typedef NS_ENUM(NSUInteger, LightInterpolationType) {
    LightInterpolationTypeNone = 0,
    LightInterpolationTypeLine = 1,
    LightInterpolationTypeHold = 2,
};

typedef void(^CmShowCallbackBlock)(void);
typedef void(^HitfilaCallback)(int64_t[]);
typedef void(^FilaPosCallback)(float[]);

@interface LightMaterialConfig : NSObject  // 对应内部MaterialConfig
@property(nonatomic) NSString * key; //关联key
@property(nonatomic) LightSourceType type; // 用户素材类型
@property(nonatomic) int clipAssetCount; //用户上传素材个数.固定值
@property(nonatomic) CMTime minVideoDuration;// 用户上传单段素材最短时长
@property(nonatomic) int minImageHeight;
@property(nonatomic) int minImageWidth;
@property(nonatomic) NSDictionary<NSString*, NSString*>* aiFilterList;
@property(nonatomic) NSString * desc; //描述信息
@end

@interface LightTouchEvent: NSObject
@property (nonatomic, assign) LightTouchEventType type;
@property (nonatomic, strong) NSSet<NSValue *> * currentTouchPoints; // 当前触发事件的触摸点在画布上的坐标
@property (nonatomic, strong) NSSet<NSValue *> * allTouchPoints; // 当前所有触摸点在画布上的坐标
@property (nonatomic, assign) CGSize surfaceSize; // 画布的大小
@property (nonatomic, assign) NSTimeInterval timestamp;
@end

@interface LightMovieConfig : NSObject // 对应内部的TemplateConfig
@property(nonatomic) LightSourceType type; // 用户素材类型
@property(nonatomic) CMTime minImageDuration; // 图片播放最小时长
@property(nonatomic) CMTime maxImageDuration;// 图片播放最大时长
@property(nonatomic) int minClipAssetCount;//用户上传素材最少个数
@property(nonatomic) int maxClipAssetCount; // 用户上传素材最多个数
@property(nonatomic) CMTime minVideoDuration;// 用户上传单段素材最短时长
@property(nonatomic) CMTime preferredCoverTime;
@property(nonatomic) CGFloat originVolume; // 原生视频音量
@end

@interface LightVideoOutputConfig : NSObject
@property(nonatomic) float frameRate;
@property(nonatomic) int seekTolerance; //The accuracy of video seek, 0 means seeking to the exact frame.

@end

@interface LightAudioOutputConfig : NSObject
@property(nonatomic) int sampleRate;
@property(nonatomic) int sampleCount;
@property(nonatomic) int channels;

@end

@interface LightRendererConfig : NSObject
@property(nonatomic) NSString *bundlePath;
@property(nonatomic) NSString *lightCacheRootPath;
@property(nonatomic) BOOL enablePerfReport;  // 性能报告开关
@property(nonatomic) BOOL enablePerfVramTrace; // 性能报告下的显存开关
@property(nonatomic) BOOL englishPerfKey;
@property(nonatomic) int perfRunMode;
@property(nonatomic) BOOL enableAsyncDecoder; // 是否开启硬件异步解码
+ (NSString*)getDefaultFileCacheRootPath;
@end

/**
 * Audio output data
 */
@interface LightAudioFrame : NSObject
@property(nonatomic) CMTime pts;
@property(nonatomic) CMTime duration;
@property(nonatomic, strong) NSData* data;
@end

/**
 * Base class of Template padding input information
 */
@interface LightClipAsset : NSObject
@property(nonatomic) CMTime duration;
@property(nonatomic, copy) NSString* path;
@property(nonatomic) CGAffineTransform matrix;
@property(nonatomic) LightClipAssetType type;
@property(nonatomic) CGRect clipRect;
@end

/**
 * Video fade information
 */
@interface LightVolumeEffect : NSObject
@property(nonatomic) CMTime startOffset;
@property(nonatomic) CMTime endOffset;
@property(nonatomic) CMTime duration;
@property(nonatomic) float startVolume;
@property(nonatomic) float endVolume;
@property(nonatomic) LightInterpolationType interpolationType;
@end

/**
 * Video fill input information
 */
@interface LightVideoClip : LightClipAsset
@property(nonatomic) CMTime startOffset;
@property(nonatomic) float speed;
@property(nonatomic) float volume;
@property(nonatomic, strong) NSArray<LightVolumeEffect*>* volumeEffects;
@end

/**
 * Image fill input information
 */
@interface LightPhotoClip : LightClipAsset
@property(nonatomic, copy) NSString* photoEffectPath;
@property(nonatomic) NSData* imageData;
@end

/**
 * Template padding placeholder information
 */
@interface LightClipPlaceHolder : NSObject
@property(nonatomic) CMTime contentDuration;
@property(nonatomic) LightScaleMode fillMode;
@property(nonatomic) int width;
@property(nonatomic) int height;
@property(nonatomic) CGFloat volume;
@end

/**
 * LUT placeholder information
 */
@interface LightLUTPlaceHolder : NSObject
@property(nonatomic, copy) NSString* key;
@property(nonatomic, copy) NSString* path;
@property(nonatomic) float intensity;
@end

/**
 * LUT fill input information
 */
@interface LightLUTAsset : NSObject
@property(nonatomic, copy) NSString* path;
@property(nonatomic) float intensity;
@end

/**
 * Audio placeholder information
 */
@interface LightAudioPlaceHolder : NSObject
@property(nonatomic, copy) NSString* key;
@property(nonatomic, copy) NSString* musicID;
@property(nonatomic) CMTime fadeInDuration;
@property(nonatomic) CMTime fadeOutDuration;
@property(nonatomic) float volume;
@property(nonatomic, copy) NSString* path;
@property(nonatomic) CMTime startOffset;
@property(nonatomic) CMTime duration;
// 重复次数，loopCount>=0时，表示一共播放loopCount+1次(0播放1次，1播放2次)， -1 表示无限循环
@property(nonatomic) NSInteger loopCount;
@end

/**
 * Audio fill input information
 */
@interface LightAudioAsset : NSObject
@property(nonatomic, copy) NSString* musicID;
@property(nonatomic) CMTime fadeInDuration;
@property(nonatomic) CMTime fadeOutDuration;
@property(nonatomic) float volume;
@property(nonatomic, copy) NSString* path;
@property(nonatomic) CMTime startOffset;
@property(nonatomic) CMTime duration;
@property(nonatomic) NSDictionary<NSString*, NSArray<NSNumber*>*>* events;
// 重复次数，loopCount>=0时，表示一共播放loopCount+1次(0播放1次，1播放2次)， -1 表示无限循环
@property(nonatomic) NSInteger loopCount;
@end

/**
 * Font related information
 */
@interface LightFontAsset : NSObject
@property(nonatomic, copy) NSString* fontFamily;
@property(nonatomic, copy) NSString* fontStyle;
@end

/**
 * Text placeholder information
 */
@interface LightTextPlaceHolder : NSObject
@property(nonatomic, copy) NSString* key;
@property(nonatomic, copy) NSString* text;
@property(nonatomic) UIColor* fillColor;
@property(nonatomic) int maxLength;
@property(nonatomic) float layerWidth;
@property(nonatomic) float layerHeight;
@property(nonatomic) int replaceIndex;
@property(nonatomic) int entityId;
@end

/**
 * Text fill input information
 */
@interface LightTextAsset : NSObject
@property(nonatomic, copy) NSString* text;
@property(nonatomic) UIColor* fillColor;
@end

@interface LightTimeLine:NSObject
@property(nonatomic, copy) NSString* type;
@property(nonatomic, copy) NSString* event;
@property(nonatomic) int entityId;
@property(nonatomic) CMTimeRange timeRange;
@property(nonatomic) CMTime time;
@end

@interface LightAudioDefaultInfo : NSObject
@property(nonatomic, strong) NSArray<NSString*>* pagInternalMusicIDs;
@property(nonatomic) int64_t startTime;
@property(nonatomic) int64_t duration;
@property(nonatomic) float defaultVolume;
@property(nonatomic) float defaultSpeed;
@property(nonatomic, strong) NSString* defaultMusicID;
@end

@interface LightClipInfo : NSObject
@property(nonatomic) CMTimeRange sourceTimeRange;
@property(nonatomic) CMTimeRange targetTimeRange;
@property(nonatomic, copy) NSString* path;
@end

@interface LightARPlane : NSObject

@property (nonatomic, assign) SCNVector3 arbitraryPoint;
@property (nonatomic, assign) SCNVector3 normal;

@end

@interface LightARFrameInfo : NSObject

@property (nonatomic, assign) SCNMatrix4 cameraModelMatrix;
@property (nonatomic, assign) SCNMatrix4 projectionMatrix;

@property (nonatomic, strong) NSArray <LightARPlane *> *planeList;

@end

@interface LightPerformanceData : NSObject
@property (nonatomic, assign) float frameTime;
@property (nonatomic, assign) float aiSystemTime;
@property (nonatomic, assign) float scriptSystemTime;
@property (nonatomic, assign) float stickerRendererTime;
@property (nonatomic, assign) float aePagRendererTime;
@property (nonatomic, assign) float aeBasicBeautySystemTime;
@property (nonatomic, assign) float aeLiquifyRenderChainTime;
@property (nonatomic, assign) float aeLutRendererTime;
@property (nonatomic, assign) float aePostEffectRendererTime;
@property (nonatomic, assign) float aeScene3dRendererTime;
@property (nonatomic, assign) float ganRendererTime;
//@property (nonatomic, assign) int64_t renderingTime;
//@property (nonatomic, assign) int64_t imageDecodingTime;
//@property (nonatomic, assign) int64_t presentingTime;
//@property (nonatomic, assign) int64_t graphicsMemory;
//@property (nonatomic, assign) int64_t threeDRenderingTime;
//@property (nonatomic, assign) int64_t aiConsumingTime;
//@property (nonatomic, assign) int64_t ganConsumingTime;
//@property (nonatomic, assign) int64_t scriptConsumingTime;
//@property (nonatomic, assign) int64_t physicsEngineConsumingTime;

@end

@class LightAsset;
@interface LightTemplateClip : LightClipAsset
@property(nonatomic) NSArray<LightClipAsset*>* clipAssets;
@property(nonatomic) LightAsset* lightAsset;
@end

// 外挂变声器处理程方法，第一个参数是变声器选择器，第二个参数是要处理的音频帧
@protocol ExternalAudioProcessor <NSObject>

@required
-(void)process:(NSString*)preset frame:(LightAudioFrame*)frame;

@end

// 人脸识别结果Class
typedef NS_ENUM(NSInteger, LightFaceDirection) {
    LightFaceDirectionPosition = 1, ///< 正脸
    LightFaceDirectionSide = 2, ///< 侧脸
};

typedef NS_ENUM(NSInteger, LightFaceResultType) {
    LightFaceDetectQualified = 0,            // 模板没有针对人脸识别的要求 或者 符合要求
    LightFaceDetectFailed = 1,            // 检测过程发生错误
    LightFaceDetectNoFace = 2,            // 没检测到人脸
    LightFaceDetectSensitivePersonError,   // 检测到至少1个敏感人物(当开启敏感人物检测选项时生效)
    LightFaceDetectPositionError,  // 至少有1个人脸人脸朝向不匹配
    LightFaceDetectDirectionError, // 至少有1个人脸人脸位置不对
    LightFaceDetectMinFaceSizeError,  // 至少有1个人脸最小尺寸不匹配
    LightFaceDetectMinFaceCountError,  // 图片中包含的人脸个数不满足最少要求
    LightFaceDetectMaxFaceCountError,  // 图片中包含的人脸个数超过了最大限制
};

@interface LightSingleFaceInfo : NSObject
/// 每个人脸处于图片宽度中的位置 0~1范围
@property (nonatomic) CGRect faceBounds;
/// 人脸方向
@property (nonatomic, assign) LightFaceDirection faceDirection;
@end

// 单张图片的识别结果
@interface LightImageFaceDetectResult : NSObject
@property (nonatomic) NSArray<LightSingleFaceInfo*>* faceInfoArray;
@property (nonatomic) LightFaceResultType type;
@property (nonatomic) NSString* msg;
@end

// AgentBundle信息，对应内部的AgentBundleInfo
@interface LightAgentBundleInfo : NSObject
@property (nonatomic, copy) NSString *agentType;
@property (nonatomic, copy) NSString *level;
@property(nonatomic, strong) NSDictionary<NSString *, NSString *> *subAgentFolderConfigs;
@property(nonatomic, strong) NSDictionary<NSString *, NSString *> *subAgentLevels;
@end

#endif
