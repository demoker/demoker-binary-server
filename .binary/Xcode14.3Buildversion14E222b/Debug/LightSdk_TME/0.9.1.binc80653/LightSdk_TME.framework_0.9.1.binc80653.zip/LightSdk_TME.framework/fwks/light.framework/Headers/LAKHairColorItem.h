/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKHairColorItem.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKBlendModeType.h"
#import "LAKHairEffectType.h"
#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKHairColorItem : LAKSerializable

/**
 * Comments extracted from cpp files:
 *
 * 0 -> Image, 1 -> Lut, 2 -> Bleach（漂色）
 */
@property(nonatomic, assign) LAKHairEffectType effectType;

@property(nonatomic, strong) NSString *imagePath;

@property(nonatomic, strong) NSString *lutPath;

/**
 * Comments extracted from cpp files:
 *
 * 填充模式，只对Image有效
 * 0：拉伸（用于需要将素材完整展示在头发区域时，如渐变素材）
 * 1：裁剪（用于素材图需要保持原先比例时，如头发上散落星星）
 */
@property(nonatomic, assign) NSInteger imageFillMode;

@property(nonatomic, assign) LAKBlendModeType imageBlendMode;

/**
 * Comments extracted from cpp files:
 *
 * 0：全头头发染发, 默认
 * 1：给定染发区域hairmask.png里面的黑色部分
 * 2：给定染发区域hairmask.png里面的白色部分
 */
@property(nonatomic, assign) NSInteger maskType;

@end

NS_ASSUME_NONNULL_END

