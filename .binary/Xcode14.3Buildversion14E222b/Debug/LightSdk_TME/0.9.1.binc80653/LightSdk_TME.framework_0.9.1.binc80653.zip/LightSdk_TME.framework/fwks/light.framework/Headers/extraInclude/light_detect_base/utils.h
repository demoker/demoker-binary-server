﻿//
//  utils.h
//  用于检测的基类——基于算法侧代码调整
//
//  Created by tiankai on 2019-11-04.
//  Copyright © 2019 Tencent. All rights reserved.
//
#pragma once

#include <light_ai_base/GYAIBase.h>
// clang-format off
#include <algorithm>
#include <cstdio>
#include <string>
#include <vector>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
// clang-format on

GYAILIB_NAMESPACE_START

struct GYAI_PUBLIC YtHandBox {
 public:
  float x;
  float y;
  float width;
  float height;
  float confidence;
  float zaxis;

  void reset() {
    x = 0.0f;
    y = 0.0f;
    width = 0.0f;
    height = 0.0f;
    confidence = 0.0f;
    zaxis = 0.0f;
  }

  YtHandBox() : x(0.0f), y(0.0f), width(0.0f), height(0.0f), confidence(0.0f), zaxis(0.0f) {}

  YtHandBox(float _x, float _y, float _width, float _height)
      : x(_x), y(_y), width(_width), height(_height), confidence(0.0f), zaxis(0.0f) {}

  YtHandBox(float _x, float _y, float _width, float _height, float _confidence)
      : x(_x), y(_y), width(_width), height(_height), confidence(_confidence), zaxis(0.0f) {}

  YtHandBox(float _x, float _y, float _width, float _height, float _confidence, float _zaxis)
      : x(_x), y(_y), width(_width), height(_height), confidence(_confidence), zaxis(_zaxis) {}
};

struct BodyTimeLog {
  double time_bacbone_cost = 0;
  double time_hand_cost = 0;
  int time_backbone_count = 0;
  int time_hand_count = 0;
};

#ifdef __cplusplus
extern "C" {
#endif
float sigmoid(float x);
#ifdef __cplusplus
}
#endif

#ifdef __ANDROID__
namespace nt {
typedef enum { NO_IMPLEMENTATION = 0x02, TNN = 0x01, HYPER_GAN = 0x00, ERROR = 0x100 } NetType;
}

namespace hp {
typedef enum { SUCCESS = 0x00, VERSION_EXCEED = 0x01, FAILED = 0x02 } HyperGanStatus;

struct HyperGanResult {
  nt::NetType netType = nt::NetType::HYPER_GAN;
};
}  // namespace hp

hp::HyperGanStatus GetNetTypeFromJsonByDeviceName(int version, const std::string &device_name,
                                                  hp::HyperGanResult *result,
                                                  std::string blacklist);

hp::HyperGanStatus GetNetTypeFromJsonByCPU(int version, std::string cpu, hp::HyperGanResult* result,
                                           std::string blacklist);
#endif

static inline float GYSimpleClampValue(float value, float min, float max) {
#ifndef _MSC_VER
  value = std::max(value, min);
  value = std::min(value, max);
#else
  value = value > min ? value : min;
  value = value < max ? value : max;
#endif
  return value;
}

static inline std::vector<std::string> SplitString(const std::string &str, char delim) {
  std::vector<std::string> strings;
  size_t start;
  size_t end = 0;
  while ((start = str.find_first_not_of(delim, end)) != std::string::npos) {
    end = str.find(delim, start);
    strings.push_back(str.substr(start, end - start));
  }
  return strings;
}
/**
 * string version compare, string like 1.1.5
 * @param ver1 version string 1
 * @param ver2 version string 2
 * @param delim delimit
 * @return -1 (error), 0 (ver1 < ver2), 1 (ver1 >= ver2)
 */
static inline int VersionStrCompare(const std::string ver1, const std::string &ver2, char delim) {
  std::vector<std::string> verss1 = SplitString(ver1, delim);
  std::vector<std::string> verss2 = SplitString(ver2, delim);
  if (verss1.size() != verss2.size()) {
    return -1;
  }
  for (int i = 0; i < verss1.size(); ++i) {
    if ((verss1[i].length() != verss2[i].length()) || verss1[i].length() != 1) {
      return -1;
    }
    if (*(verss1[i].c_str()) > *(verss2[i].c_str())) {
      return 1;
    } else if (*(verss1[i].c_str()) == *(verss2[i].c_str())) {
      continue;
    } else {
      return 0;
    }
  }
  return 1;
}

inline void *aligned_malloc(size_t alignment,
                            size_t size) {
  if (alignment & (alignment - 1)) {
    return nullptr;
  } else {
    void *praw = malloc(sizeof(void *) + size + alignment * 2);
    if (praw) {
      void *pbuf = reinterpret_cast<void *>(reinterpret_cast<size_t>(praw) + sizeof(void *));
      void *palignedbuf =
          reinterpret_cast<void *>((reinterpret_cast<size_t>(pbuf) | (alignment - 1)) + 1);
      (static_cast<void **>(palignedbuf))[-1] = praw;
      return palignedbuf;
    } else {
      return nullptr;
    }
  }
}

inline void aligned_free(void *palignedmem) {
  if (palignedmem) free(reinterpret_cast<void *>((static_cast<void **>(palignedmem))[-1]));
}

GYAILIB_NAMESPACE_END
