/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKPAGScaleMode.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKPAGScaleMode) {
    LAKPAGScaleModeNone = 0,
    LAKPAGScaleModeStretch = 1,
    LAKPAGScaleModeLetterBox = 2,
    LAKPAGScaleModeZoom = 3
};

NS_ASSUME_NONNULL_END

