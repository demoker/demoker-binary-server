﻿//
//  GYDetectCommonPublic.h
//  GYDetectCommon
//
//  Created by gennyxu on 2020/1/16.
//  Copyright © 2020 TTPic. All rights reserved.
//
#pragma once

#include <light_ai_base/gyai_macro_t.h>

/*说明：是否开启基础的BaseManager，因为分阶段合入：
 1、公共代码已经抽离；（此时手检测没改造完毕，但是公共代码需要提交，且不能影响安装包大小。）
 2、改造完手检测后，再次提交，会放开该宏定义。
 */

GYAILIB_NAMESPACE_START
// 局部禁用clang的排版——防止将此处格式转换
// clang-format off
/**
 GYDetectCommonForwardOption
 可以通过该枚举在forward操作时候关闭部分不用的功能，防止不必要的性能浪费。
 备注：很多检测器可关闭配准、分类，但检测和追踪无法关闭，因为检测、追踪是必选项，必须进行此两步才可以进行其他操作。
 备注：如果非视频，建议每一次输入都会执行检测全操作；如果是视频，前一帧没有缓存，则执行检测操作，否则执行仅追踪（如需关闭，通过option控制）
 （此外功能开启要确认默认已传入，并且当前SDK支持对应的功能。）
 */
typedef enum {
  // 下方为快捷使用的定义(默认使用该定义好的option)
  GYDetectCommonForwardOptionDefault          = 0x00,    // 默认全开启 Equal to All
  GYDetectCommonForwardOptionAll              = 0x0f,    // 全开启(图片使用；视频除首帧外，无需显式开启) // NOLINT
  GYDetectCommonForwardOptionDetectTrackOnly  = 0x02,    // 只追踪 (视频有缓存会追踪；没有执行检测)
  GYDetectCommonForwardOptionTrackPoint       = 0x06,    // 追踪、配准 (视频有缓存会追踪；没有执行检测) // NOLINT
  GYDetectCommonForwardOptionTrackClassify    = 0x0A,    // 追踪、分类 (视频有缓存会追踪；没有执行检测) // NOLINT
  GYDetectCommonForwardOptionTrackAll         = 0x0E,    // 追踪、配准、分类 (视频有缓存会追踪；没有则检测) // NOLINT
  GYDetectCommonForwardOptionKeypointDefault  = 0x07,    // 开启点配准，通常需要检测和追踪的
  GYDetectCommonForwardOptionClassifyDefault  = 0x0B,    // 开启分类检测，通常要检测\追踪的，如手势

  // 下方为使用的Option详细比特位拆解（用作动作拆解，根据需要选择开启部分功能）
  GYDetectCommonForwardOptionOpenStepDetect   = 1 << 0,  // 检测开启（图片检测每一次都需要开启）
  GYDetectCommonForwardOptionOpenStepTrack    = 1 << 1,  // 追踪开启（视频会开启追踪）
  GYDetectCommonForwardOptionOpenStepKeypoint = 1 << 2,  // 配准开启，通常出检测图的关键点
  GYDetectCommonForwardOptionOpenStepClassify = 1 << 3,  // 分类开启，通常出目标的分类，如手势、表情等。 // NOLINT
} GYDetectCommonForwardOption;

// clang-format on
GYAILIB_NAMESPACE_END
