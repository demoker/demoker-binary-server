/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKGAN.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKGAN : LAKComponent

@property(nonatomic, strong) NSString *resourcePath;

@property(nonatomic, strong) NSArray<NSString *> *inputResources;

@property(nonatomic, strong) NSDictionary<NSString *, NSString *> *inputMap;

@property(nonatomic, assign) float factor;

@property(nonatomic, assign) BOOL need_validator;

/**
 * Comments extracted from cpp files:
 *
 * GAN多人脸重叠部分剔除开关
 */
@property(nonatomic, assign) BOOL multiFacesOverlapCulling;

@end

NS_ASSUME_NONNULL_END

