/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKPAGAsset.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKLayerScaleMode.h"
#import "LAKPAGScaleMode.h"
#import "LAKReplaceItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKPAGAsset : LAKComponent

@property(nonatomic, strong) NSArray<LAKReplaceItem *> *replacement;

@property(nonatomic, strong) NSArray<LAKLayerScaleMode *> *layerScaleModes;

@property(nonatomic, assign) LAKPAGScaleMode scaleMode;

@property(nonatomic, strong) NSString *musicID;

/**
 * Comments extracted from cpp files:
 *
 * 统一是用src去LoadResourceFromKey加载
 */
@property(nonatomic, strong) NSString *src;

@end

NS_ASSUME_NONNULL_END

