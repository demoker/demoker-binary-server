/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMakeupEyeV6.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKMakeupComponent.h"
#import "LAKMakeupEyeMeshOptType.h"
#import "LAKRect.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMakeupEyeV6 : LAKMakeupComponent

/**
 * Comments extracted from cpp files:
 *
 * 眼妆图片
 */
@property(nonatomic, strong) NSString *eyeImageName;

/**
 * Comments extracted from cpp files:
 *
 * 最终使用的裁切素材
 */
@property(nonatomic, strong) NSString *eyeCropImageName;

/**
 * Comments extracted from cpp files:
 *
 * 眼妆裁剪区域（基于标准人脸点位图）
 */
@property(nonatomic, strong) LAKRect *cropRect;

/**
 * Comments extracted from cpp files:
 *
 * 眼妆类型： 0 普通眼妆 默认； 1 睫毛
 */
@property(nonatomic, assign) LAKMakeupEyeMeshOptType eyeMeshOptType;

@end

NS_ASSUME_NONNULL_END

