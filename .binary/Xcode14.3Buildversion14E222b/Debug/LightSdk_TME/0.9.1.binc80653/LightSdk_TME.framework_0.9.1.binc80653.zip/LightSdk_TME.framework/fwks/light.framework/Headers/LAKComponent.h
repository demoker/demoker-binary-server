/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponentBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKComponent : LAKComponentBase

@property(nonatomic, assign) BOOL enabled;

/**
 * Comments extracted from cpp files:
 *
 * 如果没配置，第一帧默认reload
 */
@property(nonatomic, assign) BOOL needReload;

@property(nonatomic, assign) BOOL paused;

@property(nonatomic, assign) NSInteger componentID;

@property(nonatomic, assign) NSInteger entityId;

@end

NS_ASSUME_NONNULL_END

