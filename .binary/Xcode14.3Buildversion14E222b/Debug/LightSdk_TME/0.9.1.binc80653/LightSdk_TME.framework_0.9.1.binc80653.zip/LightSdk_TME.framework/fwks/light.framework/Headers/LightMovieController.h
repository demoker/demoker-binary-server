//
//  LightMovieController.h
//  light-sdk
//
//  Created by zongyang on 2020/5/25.
//

#import "LightController.h"

@interface LightMovieController : LightController

/**
 * Get the LUT filter in the template
 */
- (NSArray<LightLUTPlaceHolder*>*)getLUTPlaceHolders;

/**
 * Get the preset information of all video fill bits in the template
 */
- (NSArray<LightClipPlaceHolder*>*)getClipPlaceHolders;

/**
 * Set the video fill data and background effects in the template
 */
- (void)setClipAssets:(NSArray<LightClipAsset*>*)clipAssets backgroundEffectPath:(NSString*)backgroundEffectPath modifyClipsDuration:(BOOL)apply;

/**
 * Get the TimeRanges of the video padding bits
 * @return
 */
- (NSArray<NSArray<LightClipInfo*>*>*)getClipInfos;

/**
 * Get the TimeRanges of the Texts
 * @return CMTimeRange array
 */
- (NSArray<NSValue*>*)getTextTimeRanges;

/**
 * Get the TimeRanges of BoundsTrack
 * @return CMTimeRange array
 */
- (NSArray<NSValue*>*)getBoundsTrackTimeRanges;

/**
 * Set the LUT filter in the template
 */
- (void)replaceLUTAsset:(LightLUTAsset*)lutAsset forKey:(NSString*)key;

/**
 * Get the total duration of the template
 */
- (CMTime)duration;

/**
 * Set total duration calculation method status
 * @param mediasTotalDurationLimitationStatus ture：total duration based on medias time
 */
- (void) setupMediasTotalDurationLimitationStatus:(BOOL) mediasTotalDurationLimitationStatus;

/**
 * Get total duration calculation method status
 */
- (BOOL) getMediasTotalDurationLimitationStatus;

/**
 * Set MediaContentProvider Render Size
 */
- (void)setRenderMediaSize:(int)width height:(int)height;

@end
