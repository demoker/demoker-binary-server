/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBlendModeType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKBlendModeType) {
    LAKBlendModeTypeDefault = 0,
    LAKBlendModeTypeNormal = 1,
    LAKBlendModeTypeMultiply = 2,
    LAKBlendModeTypeScreen = 3,
    LAKBlendModeTypeOverlay = 4,
    LAKBlendModeTypeHardlight = 5,
    LAKBlendModeTypeSoftlight = 6,
    LAKBlendModeTypeDivide = 7,
    LAKBlendModeTypeAdd = 8,
    LAKBlendModeTypeSubstract = 9,
    LAKBlendModeTypeDiff = 10,
    LAKBlendModeTypeDarken = 11,
    LAKBlendModeTypeLighten = 12,
    LAKBlendModeTypeV7_0 = 13,
    LAKBlendModeTypeV7_1021 = 14,
    LAKBlendModeTypeV7_1017 = 15
};

@interface LAKBlendModeTypeStringConverter : NSObject
+ (NSString *)toString:(LAKBlendModeType)blendModeType;
+ (LAKBlendModeType)fromString:(NSString *)string;
@end

NS_ASSUME_NONNULL_END

