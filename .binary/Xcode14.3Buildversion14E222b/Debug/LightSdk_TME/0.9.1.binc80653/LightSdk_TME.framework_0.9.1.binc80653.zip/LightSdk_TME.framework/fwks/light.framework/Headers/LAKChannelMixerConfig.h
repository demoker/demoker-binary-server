/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKChannelMixerConfig.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"
#import "LAKVec3.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKChannelMixerConfig : LAKSerializable

/**
 * Comments extracted from cpp files:
 *
 * -2 ~ 2
 */
@property(nonatomic, strong) LAKVec3 *outRed;

/**
 * Comments extracted from cpp files:
 *
 * -2 ~ 2
 */
@property(nonatomic, strong) LAKVec3 *outGreen;

/**
 * Comments extracted from cpp files:
 *
 * -2 ~ 2
 */
@property(nonatomic, strong) LAKVec3 *outBlue;

@end

NS_ASSUME_NONNULL_END

