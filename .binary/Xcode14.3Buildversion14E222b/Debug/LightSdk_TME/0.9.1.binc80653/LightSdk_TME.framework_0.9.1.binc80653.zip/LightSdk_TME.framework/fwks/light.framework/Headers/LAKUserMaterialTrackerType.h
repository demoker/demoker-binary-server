/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKUserMaterialTrackerType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKUserMaterialTrackerType) {
    LAKUserMaterialTrackerTypeNONE = 0,
    LAKUserMaterialTrackerTypeHEADINSET = 1,
    LAKUserMaterialTrackerTypeFACEINSET = 2,
    LAKUserMaterialTrackerTypeFACE_3DMM = 3
};

NS_ASSUME_NONNULL_END

