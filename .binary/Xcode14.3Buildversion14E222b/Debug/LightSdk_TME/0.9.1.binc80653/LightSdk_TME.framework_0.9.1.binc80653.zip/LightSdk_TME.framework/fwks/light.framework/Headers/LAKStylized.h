/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKStylized.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKStylized : LAKComponent

@property(nonatomic, strong) NSString *stylizedType;

/**
 * Comments extracted from cpp files:
 *
 * 是否开启降噪
 */
@property(nonatomic, assign) BOOL isDenoise;

/**
 * Comments extracted from cpp files:
 *
 * 所需lut资源文件，有顺序，从"lut1"开始
 * {"lut1":"xxxx"}
 */
@property(nonatomic, strong) NSDictionary<NSString *, NSString *> *lutPaths;

@property(nonatomic, strong) NSDictionary<NSString *, NSString *> *materialPaths;

@end

NS_ASSUME_NONNULL_END

