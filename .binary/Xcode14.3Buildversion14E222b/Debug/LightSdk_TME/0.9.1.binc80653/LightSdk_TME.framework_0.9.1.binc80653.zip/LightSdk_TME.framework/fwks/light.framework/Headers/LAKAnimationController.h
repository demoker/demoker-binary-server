/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKAnimationController.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKAnimationClip.h"
#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKAnimationController : LAKComponent

@property(nonatomic, strong) NSArray<LAKAnimationClip *> *clips;

@end

NS_ASSUME_NONNULL_END

