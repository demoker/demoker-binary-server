/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKAlembicMeshDataComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKAtrributeBufferView.h"
#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKAlembicMeshDataComponent : LAKComponent

@property(nonatomic, strong) NSString *URI;

@property(nonatomic, assign) NSInteger UUID;

@property(nonatomic, assign) BOOL topologyConst;

@property(nonatomic, assign) NSInteger totalFrameCount;

@property(nonatomic, assign) BOOL enableStreamLoad;

@property(nonatomic, strong) NSArray<LAKAtrributeBufferView *> *attributeBufferView;

@end

NS_ASSUME_NONNULL_END

