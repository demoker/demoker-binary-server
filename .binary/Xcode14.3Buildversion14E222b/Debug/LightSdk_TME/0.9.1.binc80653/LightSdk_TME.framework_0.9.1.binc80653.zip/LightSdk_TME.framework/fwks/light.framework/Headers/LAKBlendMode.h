/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBlendMode.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKBlendModeType.h"
#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKBlendMode : LAKComponent

@property(nonatomic, assign) LAKBlendModeType mode;

@property(nonatomic, assign) float alpha;

@end

NS_ASSUME_NONNULL_END

