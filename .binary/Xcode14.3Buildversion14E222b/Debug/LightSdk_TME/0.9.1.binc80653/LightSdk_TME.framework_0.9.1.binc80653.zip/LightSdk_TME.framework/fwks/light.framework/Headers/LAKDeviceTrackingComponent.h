/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKDeviceTrackingComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKTrackingMode.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKDeviceTrackingComponent : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 算法model
 */
@property(nonatomic, assign) LAKTrackingMode trackingMode;

/**
 * Comments extracted from cpp files:
 *
 * ->如果autoPlace true，则第一次调用process后，updateTrackPoint，开启算法tracking，
 * 算法会输出有效结果用于更新模型渲染位置
 * ->如果autoPlace false，则由外部脚本决定调用updateTrackPoint
 */
@property(nonatomic, assign) BOOL autoPlace;

@end

NS_ASSUME_NONNULL_END

