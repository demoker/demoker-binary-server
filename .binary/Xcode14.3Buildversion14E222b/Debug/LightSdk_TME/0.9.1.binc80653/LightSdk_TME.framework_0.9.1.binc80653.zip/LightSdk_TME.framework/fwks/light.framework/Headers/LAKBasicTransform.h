/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBasicTransform.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKQuat.h"
#import "LAKVec3.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKBasicTransform : LAKComponent

@property(nonatomic, strong) LAKVec3 *position;

@property(nonatomic, strong) LAKQuat *rotation;

@property(nonatomic, strong) LAKVec3 *scale;

@property(nonatomic, assign) BOOL objectEnabled;

/**
 * Comments extracted from cpp files:
 *
 * 用于时间控制timeOffset
 */
@property(nonatomic, assign) BOOL visible;

@property(nonatomic, assign) BOOL skipUpdate;

@end

NS_ASSUME_NONNULL_END

