/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKColorGradingConfig.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKChannelMixerConfig.h"
#import "LAKCurvesConfig.h"
#import "LAKSerializable.h"
#import "LAKShadowsMidtonesHighlightsConfig.h"
#import "LAKSlopeOffsetPowerConfing.h"
#import "LAKToneMapping.h"
#import "LAKWhiteBalanceConfig.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKColorGradingConfig : LAKSerializable

/**
 * Comments extracted from cpp files:
 *
 * 真正的color grading开关
 */
@property(nonatomic, assign) BOOL colorGradingEnabled;

/**
 * Comments extracted from cpp files:
 *
 * 自定义color grading属性，并不是开关（历史原因）
 */
@property(nonatomic, assign) BOOL enable;

@property(nonatomic, strong) LAKWhiteBalanceConfig *whiteBalance;

@property(nonatomic, strong) LAKChannelMixerConfig *channelMixer;

@property(nonatomic, strong) LAKShadowsMidtonesHighlightsConfig *shadowMidHighlights;

/**
 * Comments extracted from cpp files:
 *
 * CDL
 */
@property(nonatomic, strong) LAKSlopeOffsetPowerConfing *cdl;

/**
 * Comments extracted from cpp files:
 *
 * 0 ~ 2.0
 */
@property(nonatomic, assign) float contrast;

/**
 * Comments extracted from cpp files:
 *
 * 0 ~ 2.0
 */
@property(nonatomic, assign) float vibrance;

/**
 * Comments extracted from cpp files:
 *
 * 0 ~ 2.0
 */
@property(nonatomic, assign) float saturation;

/**
 * Comments extracted from cpp files:
 *
 * 暂不开放编辑
 */
@property(nonatomic, strong) LAKCurvesConfig *curves;

@property(nonatomic, assign) LAKToneMapping toneMapping;

@end

NS_ASSUME_NONNULL_END

