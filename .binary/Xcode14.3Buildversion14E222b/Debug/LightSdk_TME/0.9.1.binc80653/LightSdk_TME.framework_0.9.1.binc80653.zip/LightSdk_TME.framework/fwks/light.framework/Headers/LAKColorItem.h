/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKColorItem.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKColorItem : LAKSerializable

@property(nonatomic, assign) float r;

@property(nonatomic, assign) float g;

@property(nonatomic, assign) float b;

@property(nonatomic, assign) float l;

@property(nonatomic, assign) float h;

@property(nonatomic, assign) float area;

@end

NS_ASSUME_NONNULL_END

