/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKCameraViewConfig.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKCameraViewConfig : LAKSerializable

@property(nonatomic, assign) NSInteger cameraViewType;

@property(nonatomic, strong) NSArray<NSNumber *> *cameraPosition;

@property(nonatomic, strong) NSArray<NSNumber *> *cameraRotation;

@property(nonatomic, assign) float animationTime;

@property(nonatomic, assign) NSInteger animationType;

@end

NS_ASSUME_NONNULL_END

