/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKFace3DMeshComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKFace3DMeshType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKFace3DMeshComponent : LAKComponent

@property(nonatomic, assign) NSInteger faceIndex;

@property(nonatomic, assign) BOOL updateNormal;

@property(nonatomic, assign) LAKFace3DMeshType faceType;

@property(nonatomic, strong) NSString *indexPath;

@end

NS_ASSUME_NONNULL_END

