/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKSubAssetComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKSubAssetApplyType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKSubAssetComponent : LAKComponent

@property(nonatomic, strong) NSArray<NSNumber *> *indexes;

@property(nonatomic, assign) LAKSubAssetApplyType subAssetApplyType;

@property(nonatomic, assign) BOOL renderAfterTransform;

@property(nonatomic, assign) BOOL isUsingPropertiesSize;

/**
 * Comments extracted from cpp files:
 *
 * 是否对图片进行子嵌套预处理缓存
 */
@property(nonatomic, assign) BOOL cacheRenderResult;

@end

NS_ASSUME_NONNULL_END

