/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKFace3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKFace3DComponent : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 是否使用3DMM头模
 */
@property(nonatomic, assign) NSInteger use3DMMHead;

/**
 * Comments extracted from cpp files:
 *
 * 是否需要3D人头遮挡
 */
@property(nonatomic, assign) BOOL showUserHead;

/**
 * Comments extracted from cpp files:
 *
 * 人头索引
 */
@property(nonatomic, strong) NSArray<NSNumber *> *faceIndex;

@property(nonatomic, assign) BOOL useCustom3DHead;

@property(nonatomic, strong) NSString *custom3DHead;

@property(nonatomic, assign) NSInteger motionFaceIndex_;

@property(nonatomic, assign) BOOL stopVertexUpdate;

@property(nonatomic, assign) BOOL stopNormalUpdate;

@end

NS_ASSUME_NONNULL_END

