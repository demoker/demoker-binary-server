/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKUE4Component.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKAnimojiType.h"
#import "LAKComponent.h"
#import "LAKHeadRotationType.h"
#import "LAKWorkMode.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKUE4Component : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * [serialization]
 */
@property(nonatomic, assign) float horizontalFOV;

@property(nonatomic, assign) LAKWorkMode workMode;

/**
 * Comments extracted from cpp files:
 *
 * visiableWithoutFace = true代表没有检测到人脸的时候画面中保留UE素材
 */
@property(nonatomic, assign) BOOL visiableWithoutFace;

/**
 * Comments extracted from cpp files:
 *
 * 目前只用在 kLightSDK mode 下使用
 */
@property(nonatomic, assign) LAKAnimojiType animojiType;

/**
 * Comments extracted from cpp files:
 *
 * 身体驱动场景中驱动头部旋转方式
 */
@property(nonatomic, assign) LAKHeadRotationType headRotationType;

/**
 * Comments extracted from cpp files:
 *
 * 首帧延迟渲染帧数，避免UE层初始化未成功时显示错误的问题
 */
@property(nonatomic, assign) NSInteger delayRenderFrames;

/**
 * Comments extracted from cpp files:
 *
 * 强制渲染UE4结果，用于调试
 */
@property(nonatomic, assign) BOOL forceRender;

/**
 * Comments extracted from cpp files:
 *
 * Login time limit, in seconds. If set 0, won't wait for login callback
 */
@property(nonatomic, assign) NSInteger loginTimeOut;

@property(nonatomic, strong) NSString *configPath;

@property(nonatomic, strong) NSString *pakPath;

@property(nonatomic, strong) NSString *exitPakPath;

@property(nonatomic, assign) BOOL isAbilitySlamARNeeded;

@property(nonatomic, assign) BOOL isAbilityFaceTrackNeeded;

@property(nonatomic, assign) BOOL isAbilityExpressionNeeded;

@property(nonatomic, assign) BOOL isAbilityBodyDriveNeeded;

/**
 * Comments extracted from cpp files:
 *
 * or HalfBodyMode
 */
@property(nonatomic, strong) NSString *halfBodyMode;

@property(nonatomic, assign) BOOL enableHandMode;

@end

NS_ASSUME_NONNULL_END

