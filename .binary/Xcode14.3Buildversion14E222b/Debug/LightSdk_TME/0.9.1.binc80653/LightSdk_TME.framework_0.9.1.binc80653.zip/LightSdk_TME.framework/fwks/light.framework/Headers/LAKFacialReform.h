/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKFacialReform.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKPointItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKFacialReform : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 五官重塑开关
 */
@property(nonatomic, assign) BOOL stretchEnabled;

/**
 * Comments extracted from cpp files:
 *
 * 捏脸开关
 */
@property(nonatomic, assign) BOOL pinchFaceEnabled;

/**
 * Comments extracted from cpp files:
 *
 * 整体调整因子, 各种 strength 都 *= overAllFactor
 */
@property(nonatomic, assign) float overallFactor;

/**
 * Comments extracted from cpp files:
 *
 * 基础大眼瘦脸
 */
@property(nonatomic, assign) float basicFace;

/**
 * Comments extracted from cpp files:
 *
 * v脸
 */
@property(nonatomic, assign) float vFace;

/**
 * Comments extracted from cpp files:
 *
 * 下巴
 */
@property(nonatomic, assign) float chin;

/**
 * Comments extracted from cpp files:
 *
 * 瘦脸
 */
@property(nonatomic, assign) float thinFace;

/**
 * Comments extracted from cpp files:
 *
 * 瘦颧骨
 */
@property(nonatomic, assign) float cheekboneThin;

/**
 * Comments extracted from cpp files:
 *
 * 大眼
 */
@property(nonatomic, assign) float enlargeEye;

/**
 * Comments extracted from cpp files:
 *
 * 鼻子大小
 */
@property(nonatomic, assign) float noseSize;

/**
 * Comments extracted from cpp files:
 *
 * 额头
 */
@property(nonatomic, assign) float foreHead;

/**
 * Comments extracted from cpp files:
 *
 * 眼距
 */
@property(nonatomic, assign) float eyeDistance;

/**
 * Comments extracted from cpp files:
 *
 * 眼角
 */
@property(nonatomic, assign) float eyeAngle;

/**
 * Comments extracted from cpp files:
 *
 * 鼻翼
 */
@property(nonatomic, assign) float noseWing;

/**
 * Comments extracted from cpp files:
 *
 * 鼻子位置
 */
@property(nonatomic, assign) float noseHeight;

/**
 * Comments extracted from cpp files:
 *
 * 嘴巴大小
 */
@property(nonatomic, assign) float mouthSize;

/**
 * Comments extracted from cpp files:
 *
 * 嘴唇宽度
 */
@property(nonatomic, assign) float mouthWidth;

/**
 * Comments extracted from cpp files:
 *
 * 嘴唇厚度
 */
@property(nonatomic, assign) float mouthHeight;

/**
 * Comments extracted from cpp files:
 *
 * 嘴唇位置
 */
@property(nonatomic, assign) float mouthPosition;

/**
 * Comments extracted from cpp files:
 *
 * 收下颌
 */
@property(nonatomic, assign) float facejaw;

/**
 * Comments extracted from cpp files:
 *
 * 短脸
 */
@property(nonatomic, assign) float shortFace;

/**
 * Comments extracted from cpp files:
 *
 * 长鼻
 */
@property(nonatomic, assign) float longNose;

@property(nonatomic, assign) float tmeface;

/**
 * Comments extracted from cpp files:
 *
 * 美型大眼强度，这里studio不开放，美型套装配置后需开发自行填入
 */
@property(nonatomic, assign) float basicFaceEyelarge;

/**
 * Comments extracted from cpp files:
 *
 * 捏脸(pinchFace)部分
 * 最新编辑的点位
 */
@property(nonatomic, strong) NSArray<LAKPointItem *> *points;

/**
 * Comments extracted from cpp files:
 *
 * 上一次编辑的点位
 */
@property(nonatomic, strong) NSArray<LAKPointItem *> *lastPoints;

/**
 * Comments extracted from cpp files:
 *
 * 强度
 */
@property(nonatomic, assign) float strength;

/**
 * Comments extracted from cpp files:
 *
 * 是否对称编辑
 */
@property(nonatomic, assign) BOOL symmetry;

/**
 * Comments extracted from cpp files:
 *
 * 是否锁定关键点
 */
@property(nonatomic, assign) BOOL fixPoints;

@property(nonatomic, assign) BOOL editMode;

/**
 * Comments extracted from cpp files:
 *
 * 捏脸点位画布的宽
 */
@property(nonatomic, assign) NSInteger width;

/**
 * Comments extracted from cpp files:
 *
 * 捏脸点位画布的高
 */
@property(nonatomic, assign) NSInteger height;

/**
 * Comments extracted from cpp files:
 *
 * 脸型子类型
 */
@property(nonatomic, strong) NSString *reformSubType;

@end

NS_ASSUME_NONNULL_END

