/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKSlopeOffsetPowerConfing.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"
#import "LAKVec3.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKSlopeOffsetPowerConfing : LAKSerializable

@property(nonatomic, strong) LAKVec3 *slope;

@property(nonatomic, strong) LAKVec3 *offset;

@property(nonatomic, strong) LAKVec3 *power;

@end

NS_ASSUME_NONNULL_END

