//
//  LightWatermarkDefine.h
//  light
//
//  Created by honghewang on 2020/11/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const kWatermarkDataDefaultLocaltion;
extern NSString *const kWatermarkDataDefaultWeather;
extern NSString *const kWatermarkDataDefaultWeatherType;
extern NSString *const kWatermarkDataDefaultTemperature;
extern NSString *const kWatermarkDataDefaultNoNetwork;

extern NSString *const kWatermarkDate;
extern NSString *const kWatermarkDateyy;
extern NSString *const kWatermarkDateyyyy;
extern NSString *const kWatermarkDatey0;
extern NSString *const kWatermarkDatey1;
extern NSString *const kWatermarkDatey2;
extern NSString *const kWatermarkDatey3;
extern NSString *const kWatermarkDateYY;
extern NSString *const kWatermarkDateYYYY;
extern NSString *const kWatermarkDateY0;
extern NSString *const kWatermarkDateY1;
extern NSString *const kWatermarkDateY2;
extern NSString *const kWatermarkDateY3;
extern NSString *const kWatermarkDateM;
extern NSString *const kWatermarkDateMM;
extern NSString *const kWatermarkDateMMM;
extern NSString *const kWatermarkDateMMMM;
extern NSString *const kWatermarkDateM0;
extern NSString *const kWatermarkDateM1;
extern NSString *const kWatermarkDatew;
extern NSString *const kWatermarkDateW;
extern NSString *const kWatermarkDated;
extern NSString *const kWatermarkDatedd;
extern NSString *const kWatermarkDated0;
extern NSString *const kWatermarkDated1;
extern NSString *const kWatermarkDateD;
extern NSString *const kWatermarkDatee;
extern NSString *const kWatermarkDateEEE;
extern NSString *const kWatermarkDateEEEE;
extern NSString *const kWatermarkDatea;
extern NSString *const kWatermarkDateh;
extern NSString *const kWatermarkDatehh;
extern NSString *const kWatermarkDateh0;
extern NSString *const kWatermarkDateh1;
extern NSString *const kWatermarkDateH;
extern NSString *const kWatermarkDateHH;
extern NSString *const kWatermarkDateH0;
extern NSString *const kWatermarkDateH1;
extern NSString *const kWatermarkDatem;
extern NSString *const kWatermarkDatemm;
extern NSString *const kWatermarkDatem0;
extern NSString *const kWatermarkDatem1;
extern NSString *const kWatermarkDates;
extern NSString *const kWatermarkDatess;
extern NSString *const kWatermarkDates0;
extern NSString *const kWatermarkDates1;
extern NSString *const kWatermarkDB;
extern NSString *const kWatermarkCHECKIN;
extern NSString *const kWatermarkSPEED;
extern NSString *const kWatermarkAltitude;
extern NSString *const kWatermarkLocation;
extern NSString *const kWatermarkCity;
extern NSString *const kWatermarkCountry;
extern NSString *const kWatermarkWeather;
extern NSString *const kWatermarkWeatherType;
extern NSString *const kWatermarkTemperature;
extern NSString *const kWatermarkTemperature0;
extern NSString *const kWatermarkTemperature1;
extern NSString *const kWatermarkTemperatures;
extern NSString *const kWatermarkSpeechsAll;
extern NSString *const kWatermarkPicDatey0;
extern NSString *const kWatermarkPicDatey1;
extern NSString *const kWatermarkPicDatey2;
extern NSString *const kWatermarkPicDatey3;
extern NSString *const kWatermarkPicDateM0;
extern NSString *const kWatermarkPicDateM1;
extern NSString *const kWatermarkPicDated0;
extern NSString *const kWatermarkPicDated1;

extern NSString *const kWatermarkNumber;
extern NSString *const kWatermarkNumberd0;
extern NSString *const kWatermarkNumberd1;
extern NSString *const kWatermarkNumberd2;
extern NSString *const kWatermarkNumberd3;
extern NSString *const kWatermarkNumberd4;
extern NSString *const kWatermarkNumberd5;
extern NSString *const kWatermarkNumberd6;
extern NSString *const kWatermarkNumberd7;
extern NSString *const kWatermarkNumberd8;
extern NSString *const kWatermarkNumberd9;

//倒计时新增字段,c->countdown
//倒计时的时候，H都是24小时制
extern NSString *const kWatermarkcDays;
extern NSString *const kWatermarkcDays0;//0是个位
extern NSString *const kWatermarkcDays1;
extern NSString *const kWatermarkcDays2;//2是百位
extern NSString *const kWatermarkDatecH;
extern NSString *const kWatermarkDatecHH;
extern NSString *const kWatermarkDatecH0;
extern NSString *const kWatermarkDatecH1;
extern NSString *const kWatermarkDatecm;
extern NSString *const kWatermarkDatecmm;
extern NSString *const kWatermarkDatecm0;
extern NSString *const kWatermarkDatecm1;
extern NSString *const kWatermarkDatecs;
extern NSString *const kWatermarkDatecss;
extern NSString *const kWatermarkDatecs0;
extern NSString *const kWatermarkDatecs1;

//QQ在线人数水印字段
extern NSString *const kWatermarkQQOnlineNumber;

extern NSString *const kWatermarkText;

extern NSString *const kWatermarkKeyPrefixSpecficLocation;

@interface LightWatermarkDefine : NSObject

@end

NS_ASSUME_NONNULL_END
