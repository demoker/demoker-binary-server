﻿//
//  gyai_interface_keys_t.hpp
//  场景输入key定义：单独文件方便后续扩展
//
//  Created by gennyxu on 2021/3/15.
//  Copyright © 2021 Tencent. All rights reserved.
//

#pragma once

#ifdef __APPLE__
#include <TargetConditionals.h>
#endif
#include <light_ai_base/interface/gyai_interface_config_t.hpp>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>

GYAILIB_NAMESPACE_START

#define GYAI_PTR_CAST(type, value) (reinterpret_cast<type>(value))
// @brief 从@map中查找@key的value值，找不到返回holder/nullptr. (方便指针、字符串使用)
#define GYAIGetSafePtrFromMap(map, key) GYAIGetSafeValueFromMap(map, key, nullptr)
#ifndef WIN32
// @brief 为了简单类型增加的方法：方便str、int、指针这类map操作（减少不必要判断）
#define GYAIGetSafeValueFromMap(map, key, placeholder)                 \
  __extension__({                                                      \
    auto _iter = (map).find((key));                                    \
    auto __ret = _iter != (map).end() ? _iter->second : (placeholder); \
    __ret;                                                             \
  })
#else
// @brief 为了简单类型增加的方法：方便str、int、指针这类map操作 （适配windows）
#define GYAIGetSafeValueFromMap(map, key, placeholder) \
  ((map).find((key)) != (map).end() ? (map).find((key))->second : (placeholder))
#endif

#pragma mark - Setup & Forward Config

// @brief 配置当前 Setup 和 Forward 的输入输出、参数配置
typedef enum {
  AIInputParamsTypeInit = 0,
  AIInputParamsTypeInput = 1,
  AIInputParamsTypeOutput = 2,
  AIInputParamsTypePrivate = 100,  // 一些内部使用的数据，外部不需要
} AIInputParamsType;

using AIInitConfigKeyType = std::string;
using AIInitConfigType = std::map<AIInitConfigKeyType, void *>;
using AIBaseDataMapType = std::map<std::string, void *>;
using AIBaseInputType = const AIBaseDataMapType &;
using AIBaseOutputType = const AIBaseDataMapType &;

template <typename T>
static T *GetSafePtrForKey(const AIInitConfigType &map, const std::string &key) {
  return GYAI_PTR_CAST(T *, GYAIGetSafePtrFromMap(map, key));
}

static inline void *FindInitConfig(const AIInitConfigType &config, const AIInitConfigKeyType &key) {
  return GYAIGetSafePtrFromMap(config, key);
}
#define GYGetSafeTypePtrFromMap(map, key, Type) GYAI_PTR_CAST(Type, GYAIGetSafePtrFromMap(map, key))

#pragma mark - Init config keys

// 部分AI功能可能无需model；但是有device可选设置；反之亦然。
GYAI_PUBLIC_EXTERN const AIInitConfigKeyType kAIInitConfigKeyDevice;  // 参考 SDKDeviceConfig
GYAI_PUBLIC_EXTERN const AIInitConfigKeyType kAIInitConfigKeyModel;   // 参考 SDKModelConfig
GYAI_PUBLIC_EXTERN const AIInitConfigKeyType kAIInitConfigKeySmooth;  // 参考 分割smooth设置
GYAI_PUBLIC_EXTERN const AIInitConfigKeyType kAIInitConfigKeyGan;  // 参考 Gan前后处理函数设置

#pragma mark - Forward 输入/输出参数key类型

using AIForwardInputKeyType = std::string;  // 用于定义输入的key值（in/out公用）
using AIForwardValueType = std::string;     // 用于定义输出的value类型，方便外界查看

// 参考 AIForwardInputKeyType : AIForwardValueType
using AIInputParamsMap = std::map<AIForwardInputKeyType, AIForwardValueType>;
#define GYAIConfigMapPair(key, value) std::make_pair(key, value)  // std::pair<string, string>(...)

#pragma mark - Forward 输入/输出参数key类型 - AIForwardInputKeyType

GYAI_PUBLIC_EXTERN const AIForwardInputKeyType kForwardInputKeyImage;  // 通常用于输入图片
GYAI_PUBLIC_EXTERN const AIForwardInputKeyType kForwardInputKeyMask;   // 通常用于输入mask
GYAI_PUBLIC_EXTERN const AIForwardInputKeyType kForwardInputKeyFace;   // 输入人脸信息
GYAI_PUBLIC_EXTERN const AIForwardInputKeyType kForwardInputKeyFaceList;  // 输入人脸列表
GYAI_PUBLIC_EXTERN const AIForwardInputKeyType kForwardInputKey3DMM;      // 输入3dmm数据
GYAI_PUBLIC_EXTERN const AIForwardInputKeyType kForwardOutputKeyDefault;  // 默认输出的图片、点
GYAI_PUBLIC_EXTERN const AIForwardInputKeyType kForwardOutputKeyMask;  // 通常用于输出mask
GYAI_PUBLIC_EXTERN const AIForwardInputKeyType kForwardOutputKey3DMM;  // 输出3dmm数据
GYAI_PUBLIC_EXTERN const AIForwardInputKeyType kForwardOutputKeyBody3D;  // 输出Body3D数据

#pragma mark - Forward 输入/输出参数value类型 - AIForwardValueType

GYAI_PUBLIC_EXTERN const AIForwardValueType kForwardValueTypeMetal;    // Metal texture
GYAI_PUBLIC_EXTERN const AIForwardValueType kForwardValueTypeMat;      // GAN\Depth
GYAI_PUBLIC_EXTERN const AIForwardValueType kForwardValueTypeGrayMat;  // 分割

// 这些是需要传入人脸点（用于操作）
GYAI_PUBLIC_EXTERN const AIForwardValueType kForwardValueTypeFeature;   // 单人人脸信息
GYAI_PUBLIC_EXTERN const AIForwardValueType kForwardValueTypeFeatures;  // 多人人脸信息
// 这些是返回值
GYAI_PUBLIC_EXTERN const AIForwardValueType kForwardValueTypeFace;      // 人脸信息
GYAI_PUBLIC_EXTERN const AIForwardValueType kForwardValueTypeFaceList;  // 全人脸信息列表
GYAI_PUBLIC_EXTERN const AIForwardValueType kForwardValueTypeCommonItemParams;
GYAI_PUBLIC_EXTERN const AIForwardValueType kForwardValueTypeCommonResultStruct;
GYAI_PUBLIC_EXTERN const AIForwardValueType kForwardValueType3DMMIn;   // 3dmm输入信息(config)
GYAI_PUBLIC_EXTERN const AIForwardValueType kForwardValueType3DMMOut;  // 3dmm输出信息(3d shape)
GYAI_PUBLIC_EXTERN const AIForwardValueType kForwardValueTypeBody3DOut;  // body3D输出数据

GYAILIB_NAMESPACE_END
