﻿//
//  GYAIFaceDetector.h
//  该类定义为人脸OC封装。
//
//  Created by gennyxu on 2020/10/30.
//  Copyright © 2020 tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/GYAIBase.h>
#include <light_detect_base/GYAIBaseResultObject.h>
#include <light_detect_face/FaceDetectorFeature.h>
#include <light_detect_face/FaceDetectorFeaturePerspective.h>
#include <light_detect_face/YTFaceSDKParam.h>

#ifdef __APPLE__
@class GYAIFaceDetectResult;

// 该类定义为人脸OC封装：公开的方法和属性。
GYAI_OBJC_CLASS_FINAL
@interface GYAIFaceDetector : NSObject

/** @brief 初始化模型使用，传入模型的路径
 * @params params += {"detector", detector_bundle_full_path}, 检测模型(非空)
 *         params += {"alignment", alignment_bundle_full_path}, 配准模型(非空)
 *         备注：路径传入到模型所在文件夹全路径（包括bundle）。
 *         0.1.9.9版本开始，可以传入 params += {"root", bundle_full_path}, 其中路径是上述两个的上层目录
 *         这样从0.1.9.9版本开始，上层不需要传入"detector"和"alignment"了
 * @return 返回成功/错误码
 */
- (GYAIStatus)setupWithParams:(NSDictionary<NSString *, NSString *> *)params;

/** @brief 用于设置追踪、检测属性 (setup成功后调用)
 eg. (请咨询或根据自己需要开启，下方只是示例)
 sdkParam->enable_3d_perspective = true;
 sdkParam->enable_tracker_track_frequency_control = false;
 sdkParam->tracker_track_frequency = 1;
 sdkParam->need_sync_detect = true;  // 同步检测，受频率控制（默认频率是1，图片使用，即每一帧都检测；可修改）
 sdkParam->first_frame_need_sync_detect = true;
 */
- (YTFaceSDKParam *)getSDKSettingParams;

// 同步调用追踪结果
// @return 返回配准的点列表
- (NSArray<GYAIFaceDetectResult *> *)trackVideoImage:(GYAIImputImageClass *)image error:(NSError **)error;

// 清除缓存数据：即清除追踪的数据
- (void)cleanupCacheDetectResult;

@end

#pragma mark - OC对检测结果的封装

// 该类定义为结果的OC封装：检测的具体结果。
GYAI_OBJC_CLASS_FINAL
@interface GYAIFaceDetectResult : GYAIBaseDetectResult
// 人脸处于图片坐标系中的位置；检测目标的位置，基于image_width/height坐标系。需联动frame。（兼容旧版名称）
@property (nonatomic, assign, readonly) yt_rect bounds;      // 人脸处于图片宽度中的位置（兼容旧版名称）
@property (nonatomic, assign, readonly) yt_rect leBounds;    // 左眼处于图片坐标系中的位置（兼容旧版名称）
@property (nonatomic, assign, readonly) yt_rect reBounds;    // 右眼处于图片坐标系中的位置（兼容旧版名称）
@property (nonatomic, assign, readonly) yt_rect mouthBounds; // 嘴巴处于图片坐标系中的位置（兼容旧版名称）
@property (nonatomic, assign, readonly) BOOL hasOutline;     // 是否有Out line (算法才需要使用，兼容旧版名称)

// 指向点坐标(二维)的指针:
// 返回指针指向的是内部二维点数组，数值为image_width、height坐标系（结构释放后不可使用，使用前请判空）。
- (const GYPoint2fPtr)getFeatures:(BOOL)is_point_origin NS_RETURNS_INNER_POINTER;
- (const float *)getFeatureVisibility:(BOOL)is_point_origin NS_RETURNS_INNER_POINTER;
- (const size_t)getFeatureCount:(BOOL)is_point_origin;

// 返回256点信息：需判空
- (const GYPoint2fPtr)getFeature256 NS_RETURNS_INNER_POINTER;
- (const float *)getFeature256Visibility NS_RETURNS_INNER_POINTER;
- (const size_t)getFeature256Count;

// 请判空 & 判断点的数量合法，再使用。
- (const GYAIFaceFeaturePerspective *)getFace3DFeature NS_RETURNS_INNER_POINTER;
- (const GYAIFace3DResult *)getFace3DMMResult NS_RETURNS_INNER_POINTER;

@end
#endif  // #ifdef __APPLE__
