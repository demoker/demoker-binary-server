//
//  gyai_body3d_feature.h
//  light_ai_base
//
//  Created by dreamqian on 2021/10/20.
//  Copyright © 2021 Tencent. All rights reserved.
//  用于3d人体的公共数据结构，避免GY/GL不统一，以及解决之前数据结构太过于抽象不方便解读的问题

#pragma once

#include <light_ai_base/GYAIBase.h>
#include <memory>
#include <string>
#include <vector>

LIGHT_NAMESPACE_START
// 用于定义基础的3D人体数据结构
class GYAI_PUBLIC LightBody3DFeature: public DetectBaseParams {
 public:
  std::vector<float> body_root;         // 人体中心点
  std::vector<float> body_shape;        // 人体shape 参数
  std::vector<GYAIPoint2f> point_2d;    // 2d点位
  std::vector<GYAIPoint3f> point_3d;    // 3d点位
  std::vector<float> point_confidence;  // 点位置信度
  std::vector<float> point_visible;     // 点位可见性
  std::shared_ptr<std::vector<float>> body_mesh = nullptr;    // 人体mesh网格
  std::vector<float> body_ground;       // 接地数据
  std::vector<DetectItemBaseFrame> ext_frames;      // 额外框数据（比如：手的框）
  float transform[4][4];  // pose矩阵，对应MVP中的MV矩阵，P矩阵由渲染引擎构建

  // 下面是一些基类的信息，这里仅用于提示
//  int trace_id = 0;  // 多元素时，用于区分某一个元素（id相同则为同一个人：需网络支持）
//  // image_width/height为feature 对应的坐标系，方便部分模块需要切换。
//  float image_width = 0, image_height = 0;  // detect image's imageSize
//
//  // frame和bounds 为了兼容不同语法层的调用 （人脸bounds\猫frame通用结构）。
//  DetectItemBaseFrame frame = {
//      { {0, 0, 0, 0}, }, /*.confidence =*/ 0,
//  };  // item rect in image size
//
//  float confidence = 0;  // 点总体置信度（部分模块只有总体置信度，没有单独点）
//  // xyz的坐标，可存3D点 (z在2d点时不可用，为随机值；w为置信度或vis状态，根据功能支持而定）
//  std::vector<GYAIPoint4f> point;
};

LIGHT_NAMESPACE_END
