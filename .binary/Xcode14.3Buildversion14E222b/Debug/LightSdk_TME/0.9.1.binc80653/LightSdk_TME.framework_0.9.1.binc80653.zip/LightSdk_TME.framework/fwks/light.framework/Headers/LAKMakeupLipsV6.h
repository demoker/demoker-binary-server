/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMakeupLipsV6.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKLipsDetailType.h"
#import "LAKLipsTextureType.h"
#import "LAKLipsType.h"
#import "LAKMakeupVisMethod.h"
#import "LAKRect.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMakeupLipsV6 : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 嘴唇mask图片
 */
@property(nonatomic, strong) NSString *lipsMask;

/**
 * Comments extracted from cpp files:
 *
 * 唇彩颜色设置方式
 */
@property(nonatomic, assign) LAKLipsType lipsType;

/**
 * Comments extracted from cpp files:
 *
 * 唇彩细节
 */
@property(nonatomic, assign) LAKLipsDetailType lipsDetailType;

/**
 * Comments extracted from cpp files:
 *
 * 唇彩质感
 */
@property(nonatomic, assign) LAKLipsTextureType lipsTextureType;

/**
 * Comments extracted from cpp files:
 *
 * 通过RGB配置高光颜色
 */
@property(nonatomic, strong) NSString *shimmerColor;

/**
 * Comments extracted from cpp files:
 *
 * 通过RGB配置亮片颜色
 */
@property(nonatomic, strong) NSString *glossColor;

/**
 * Comments extracted from cpp files:
 *
 * 通过lut设置颜色
 */
@property(nonatomic, strong) NSString *lipsLut;

/**
 * Comments extracted from cpp files:
 *
 * 通过#RRGGBBAA直接配置color
 */
@property(nonatomic, strong) NSString *lipsColor;

/**
 * Comments extracted from cpp files:
 *
 * 通过图片配置唇彩颜色
 */
@property(nonatomic, strong) NSString *lipsImage;

/**
 * Comments extracted from cpp files:
 *
 * 最终使用的裁切素材
 */
@property(nonatomic, strong) NSString *lipsImageCrop;

/**
 * Comments extracted from cpp files:
 *
 * 最终使用的裁切mask
 */
@property(nonatomic, strong) NSString *lipsMaskCrop;

/**
 * Comments extracted from cpp files:
 *
 * 默认亮片纹理
 */
@property(nonatomic, strong) NSString *shimmerTextureDefault;

/**
 * Comments extracted from cpp files:
 *
 * 用户自定义纹理
 */
@property(nonatomic, strong) NSString *shimmerTextureUser;

/**
 * Comments extracted from cpp files:
 *
 * 裁剪区域（基于标准人脸点位图），指的是纹理图的裁剪区域
 */
@property(nonatomic, strong) LAKRect *lipsImageCropRect;

/**
 * Comments extracted from cpp files:
 *
 * 裁剪区域（基于标准人脸点位图），指的是mask图的裁剪区域
 */
@property(nonatomic, strong) LAKRect *lipsMaskCropRect;

/**
 * Comments extracted from cpp files:
 *
 * 高光强度
 */
@property(nonatomic, assign) float glossStrength;

/**
 * Comments extracted from cpp files:
 *
 * 亮片强度
 */
@property(nonatomic, assign) float shimmerStrength;

/**
 * Comments extracted from cpp files:
 *
 * 0：拍摄器， 1：直播， 2：禁用可见性
 */
@property(nonatomic, assign) LAKMakeupVisMethod visMethod;

/**
 * Comments extracted from cpp files:
 *
 * 遮挡出框最低的妆容透明度，支持素材配置
 */
@property(nonatomic, assign) float minVisibility;

@end

NS_ASSUME_NONNULL_END

