/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKCameraTransform.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKCameraTransform : LAKSerializable

@property(nonatomic, strong) NSArray<NSNumber *> *position;

@property(nonatomic, strong) NSArray<NSNumber *> *rotation;

@end

NS_ASSUME_NONNULL_END

