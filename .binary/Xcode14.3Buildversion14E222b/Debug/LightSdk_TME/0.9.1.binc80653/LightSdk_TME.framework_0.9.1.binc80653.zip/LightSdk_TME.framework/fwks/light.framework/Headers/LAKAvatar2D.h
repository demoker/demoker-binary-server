/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKAvatar2D.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKSize.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKAvatar2D : LAKComponent

@property(nonatomic, strong) NSString *renderTargetKey;

@property(nonatomic, strong) NSArray<NSString *> *animationList;

@property(nonatomic, strong) NSArray<NSNumber *> *animationQueue;

@property(nonatomic, strong) LAKSize *size;

/**
 * Comments extracted from cpp files:
 *
 * 设置 json string，格式如下，渲染时根据 key 进行解析
 * {"avatar_2d_animation_index": [int]}
 */
@property(nonatomic, strong) NSString *animationTriggerJSONString;

/**
 * Comments extracted from cpp files:
 *
 * 统一是用src去LoadResourceFromKey加载
 */
@property(nonatomic, strong) NSString *src;

@end

NS_ASSUME_NONNULL_END

