/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBoneCollisionObj.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"
#import "LAKVec3.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKBoneCollisionObj : LAKSerializable

@property(nonatomic, strong) NSString *bind_name;

@property(nonatomic, assign) NSInteger bind_id;

@property(nonatomic, assign) float radius;

@property(nonatomic, assign) float height;

/**
 * Comments extracted from cpp files:
 *
 * 0: X; 1: Y; 2: Z;
 */
@property(nonatomic, assign) NSInteger axis;

/**
 * Comments extracted from cpp files:
 *
 * Offset position of this collision object in bone's local space
 */
@property(nonatomic, strong) LAKVec3 *offset_position;

/**
 * Comments extracted from cpp files:
 *
 * index from 1 2 3 4...
 */
@property(nonatomic, assign) NSInteger group;

@property(nonatomic, assign) NSInteger collision_type;

@end

NS_ASSUME_NONNULL_END

