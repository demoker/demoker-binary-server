/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKLayerScaleMode.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKScaleMode.h"
#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKLayerScaleMode : LAKSerializable

@property(nonatomic, assign) NSInteger scaleLayerIndex;

@property(nonatomic, assign) LAKScaleMode scaleMode;

@end

NS_ASSUME_NONNULL_END

