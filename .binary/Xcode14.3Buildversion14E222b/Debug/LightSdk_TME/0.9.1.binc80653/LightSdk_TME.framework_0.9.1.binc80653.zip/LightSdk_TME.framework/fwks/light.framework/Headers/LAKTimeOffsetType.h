/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKTimeOffsetType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKTimeOffsetType) {
    LAKTimeOffsetTypeStart = 0,
    LAKTimeOffsetTypeMid = 1,
    LAKTimeOffsetTypeEnd = 2
};

NS_ASSUME_NONNULL_END

