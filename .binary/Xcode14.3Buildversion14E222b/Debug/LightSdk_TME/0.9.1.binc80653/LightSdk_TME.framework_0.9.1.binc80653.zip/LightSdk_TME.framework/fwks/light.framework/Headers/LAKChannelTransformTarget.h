/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKChannelTransformTarget.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKChannelTransformTarget) {
    LAKChannelTransformTargetkUnknown = 0,
    LAKChannelTransformTargetkNodeLocalTransform = 1,
    LAKChannelTransformTargetkMorphTarget = 2
};

NS_ASSUME_NONNULL_END

