/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKEyeSetting.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKEyeType.h"
#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKEyeSetting : LAKSerializable

@property(nonatomic, assign) LAKEyeType eyeType;

@property(nonatomic, assign) float leftLimit;

@property(nonatomic, assign) float rightLimit;

@property(nonatomic, assign) float lowerLimit;

@property(nonatomic, assign) float upperLimit;

@property(nonatomic, assign) float xSensitivity;

@property(nonatomic, assign) float ySensitivity;

@property(nonatomic, assign) float yOffset;

@property(nonatomic, assign) float lookingDownBoost;

@property(nonatomic, assign) float innerCanthusTilt;

@property(nonatomic, assign) float outerCanthusTilt;

/**
 * Comments extracted from cpp files:
 *
 * / given axis for each euler angle
 * / 1 for x-axis; 2 for y-axis; 3 for z-axis
 * / -1 for minus x-axis etc.
 */
@property(nonatomic, strong) NSArray<NSNumber *> *pitchYawRollAxis;

@end

NS_ASSUME_NONNULL_END

