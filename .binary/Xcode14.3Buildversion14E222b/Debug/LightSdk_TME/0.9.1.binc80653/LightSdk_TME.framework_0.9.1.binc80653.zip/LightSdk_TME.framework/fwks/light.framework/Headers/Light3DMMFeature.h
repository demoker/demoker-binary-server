//
//  Light3DMMFeature.h
//  light
//
//  Created by zebiaohuang on 2021/4/6.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import "LightAIBaseFeature.h"
#import <SceneKit/SceneKit.h>

NS_ASSUME_NONNULL_BEGIN

/// 对应 Face3DMMInfo 和 GYAIFace3DResult
/// 支持 Face3DMMInfo 和 GYAIFace3DResult 的转换
@interface Light3DMMFeature : LightAIBaseFeature

#pragma mark - Common part
@property (nonatomic, assign) int trace_id;
@property (nonatomic, assign) BOOL is_kissing;
@property (nonatomic, assign) SCNMatrix4 trans_matrix;
@property (nonatomic, assign) SCNMatrix4 transform;
@property (nonatomic, assign) SCNVector3 euler;
@property (nonatomic, assign) CGPoint translate;
@property (nonatomic, assign) float scale;
@property (nonatomic, assign) float point_scale;

#pragma mark - Face3DMMInfo
// float，表情基数据
@property (nonatomic, strong) NSArray<NSNumber*> *exp;
@property (nonatomic, assign) int face_kit_vertex_num;

// float (暂不支持)
@property (nonatomic, strong) NSArray<NSNumber*> *face_kit_vertices;

// float (暂不支持)
@property (nonatomic, strong) NSArray<NSNumber*> *proj_face_vertices;

#pragma mark - GYAIFace3DResult(暂不支持)
@property (nonatomic, assign) size_t expNum;
@property (nonatomic, assign) size_t rawExpNum;
@property (nonatomic, assign) size_t facekitVertexNum;

/// float, KGYAI_FACE_3DMM_EXP_MAX_NUM
@property (nonatomic, strong) NSArray<NSNumber*> *exp_AIFace;

/// float, KGYAI_FACE_3DMM_RAW_EXP_MAX_NUM
@property (nonatomic, strong) NSArray<NSNumber*> *raw_exp;

/// float, KGYAI_FACE_3DMM_POINT_MAX_NUM * 3
@property (nonatomic, strong) NSArray<NSNumber*> *facekitVertices;

- (instancetype)initWithFace3DMMInfo:(void *)info;
- (instancetype)initWithGYAIFace3DResult:(void *)info;

- (void *)convertToFace3DMMInfo;
- (void *)convertToGYAIFace3DResult;

@end

NS_ASSUME_NONNULL_END
