/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMeshMorphComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKBlendShapeItem.h"
#import "LAKComponent.h"
#import "LAKMeshMorphModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMeshMorphComponent : LAKComponent

@property(nonatomic, strong) NSString *morphName;

@property(nonatomic, assign) LAKMeshMorphModel meshMorphModel;

@property(nonatomic, strong) NSArray<LAKBlendShapeItem *> *blendShapeGroup;

@end

NS_ASSUME_NONNULL_END

