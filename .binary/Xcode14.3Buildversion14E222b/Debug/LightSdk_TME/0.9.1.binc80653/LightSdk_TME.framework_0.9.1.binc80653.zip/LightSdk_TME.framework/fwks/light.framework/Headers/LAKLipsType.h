/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKLipsType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKLipsType) {
    LAKLipsTypeImage = 0,
    LAKLipsTypeColor = 1,
    LAKLipsTypeLut = 2
};

@interface LAKLipsTypeStringConverter : NSObject
+ (NSString *)toString:(LAKLipsType)lipsType;
+ (LAKLipsType)fromString:(NSString *)string;
@end

NS_ASSUME_NONNULL_END

