/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKLumenEstimate.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKLumenEstimate : LAKSerializable

/**
 * Comments extracted from cpp files:
 *
 * 光源类型 kPoint = 0, kDirectional = 1, kSpot = 4, kEnvironmental = 5
 */
@property(nonatomic, assign) NSInteger light_type;

/**
 * Comments extracted from cpp files:
 *
 * 光照强度[all type]
 */
@property(nonatomic, assign) float intensity;

/**
 * Comments extracted from cpp files:
 *
 * 衰减半径[kPoint, kSpot]
 */
@property(nonatomic, assign) float radius;

/**
 * Comments extracted from cpp files:
 *
 * 光源位置[kPoint, kSpot]
 */
@property(nonatomic, strong) NSArray<NSNumber *> *position;

/**
 * Comments extracted from cpp files:
 *
 * 光照颜色, range 0~1 [kDirectional, kPoint, kSpot]
 */
@property(nonatomic, strong) NSArray<NSNumber *> *color_rgb;

/**
 * Comments extracted from cpp files:
 *
 * 光照方向 [kDirectional, kSpot]
 */
@property(nonatomic, strong) NSArray<NSNumber *> *direction;

/**
 * Comments extracted from cpp files:
 *
 * 内锥角[kSpot]
 */
@property(nonatomic, assign) float inner_angle;

/**
 * Comments extracted from cpp files:
 *
 * 外锥角[kSpot]
 */
@property(nonatomic, assign) float outer_angle;

/**
 * Comments extracted from cpp files:
 *
 * reflection path cubmap [kEnvironmental]
 */
@property(nonatomic, strong) NSString *ibl_path;

/**
 * Comments extracted from cpp files:
 *
 * 漫反射贴图 cubMap [kEnvironmental]
 */
@property(nonatomic, strong) NSString *irradiance_path;

/**
 * Comments extracted from cpp files:
 *
 * 默认 Y 轴， 环境光旋转角度[kEnvironmental]
 */
@property(nonatomic, assign) float env_rotation;

/**
 * Comments extracted from cpp files:
 *
 * 阴影参数，是否投掷阴影
 */
@property(nonatomic, assign) BOOL cast_shadows;

/**
 * Comments extracted from cpp files:
 *
 * 阴影参数，gaussBlur, 幂 如 2^shadowMapSize
 */
@property(nonatomic, assign) NSInteger shadow_map_size;

@end

NS_ASSUME_NONNULL_END

