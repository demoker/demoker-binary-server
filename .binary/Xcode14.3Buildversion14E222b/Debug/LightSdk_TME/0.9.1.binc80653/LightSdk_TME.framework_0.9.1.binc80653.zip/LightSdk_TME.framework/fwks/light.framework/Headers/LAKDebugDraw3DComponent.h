/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKDebugDraw3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKDebugDraw3DComponent : LAKComponent

@end

NS_ASSUME_NONNULL_END

