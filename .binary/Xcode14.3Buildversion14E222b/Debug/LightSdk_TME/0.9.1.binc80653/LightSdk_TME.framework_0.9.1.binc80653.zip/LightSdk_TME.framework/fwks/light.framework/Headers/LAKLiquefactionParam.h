/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKLiquefactionParam.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKDirectionType.h"
#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKLiquefactionParam : LAKSerializable

@property(nonatomic, assign) float radiusX;

@property(nonatomic, assign) float radiusY;

@property(nonatomic, assign) float positionX;

@property(nonatomic, assign) float positionY;

@property(nonatomic, assign) float strength;

@property(nonatomic, assign) LAKDirectionType direction;

@property(nonatomic, assign) BOOL symmetry;

@property(nonatomic, assign) BOOL selected;

@property(nonatomic, assign) BOOL visible;

@end

NS_ASSUME_NONNULL_END

