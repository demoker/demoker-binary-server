﻿//
//  gy_gender_detector.h
//  性别检测
//
// Created by paynepan on 2020/6/9.
// Copyright © 2020 GYAILib. All rights reserved.
//

#pragma once

#include <light_ai_base/GYAIBase.h>
#include <light_detect_base/GYDetectCommon.h>
#include <light_detect_base/gy_reporter_protocol.h>
#include <map>
#include <memory>
#include <string>
#include <vector>

GYAILIB_NAMESPACE_START

#define FACE_CLASSIFY_PROTO_KEY  "classify_proto_file"
#define FACE_CLASSIFY_MODEL_KEY  "classify_model_file"
#define FACE_CLASSIFY_BASE_FEATURES_KEY "base_features"

#define FORWARD_IMAGE_KEY GYAISpace::kForwardInputKeyImage
#define FORWARD_FACE_FEATURE "face_feature"  // Android-jni使用：减少封装结构

class FaceClassifyMat;
class FaceRecognizeMat;
class GYAI_PUBLIC GYFaceClassify : public AIInterface, public GYReporterBase {
 public:
  // 分类的信息
  static const std::vector<std::string> &ClassifyNamesDefault() {
    static const std::vector<std::string> kClassifyNames = {
        "non_sensitive_person",
        "sensitive_person",
    };
    return kClassifyNames;
  }

 public:
  explicit GYFaceClassify(SDKDeviceConfig *config = nullptr);
  ~GYFaceClassify() override;

  /* @brief (第二步) 传入模型路径并初始化
   * @params [in] model.model_path [GYAISpace::kModelRootDirKey] = base_res_dir,
   * 1、对应目录下需存在合适模型 (classify.rapidproto/model.wmc ：参考config.ini)
   *   { GYAISpace::kModelRootDirKey, full_bundle_dir_path },
   * 2、也可以单独配置 proto\model:
   *   { FACE_CLASSIFY_PROTO_KEY, full_detect_proto_path },
   *   { FACE_CLASSIFY_MODEL_KEY, full_detect_model_path },
   * */
  GYAIStatus SetupWithModel(const SDKModelConfig &model) override;

  GYAIStatus CleanupModelData() override;

  // 第三步：网络执行（前向操作 —— 内部接口，为了统一封装实现）
  // @params input [in] [kForwardInputKeyImage] GYImageData* 输入图片，建议bgra格式。
  //         [in] 人脸输入方式1：input[kForwardInputKeyFace] DetectFeatureProtocol* (单人)
  //         [in] 人脸输入方式2：input[kForwardInputKeyFaceList] DetectFeatureProtocol* (多人)
  // @params output [out] 期望结果存放的结构的地址指针 （非空，单人、多人输入存放结构不一样）。
  //         [out] 单人输出结构为 GYDetectCommonItemParams （兼容其他模块、旧版功能）
  //         [out] 多人输出结构为 GYDetectCommonResultStruct （新增）
  // Option type is GYDetectCommonForwardOption, default is 0.
  GYAIStatus Forward(AIBaseInputType inputMap, AIBaseOutputType outputMap, int option) override;

  // 第三步：网络执行（前向操作 —— 外部接口，相对具体数据类型）
  // @brief [推荐使用] 图片 + 人脸点 => 敏感人物分类信息
  // @params image [in] 输入的图片 (如果方向不为Up会旋转输入的人脸点、框做适配；推荐BGRA格式)
  // @params feature [in] 人脸信息 (暂不支持多输入)，参考 kForwardInputKeyFace
  // @params result [in-out] feature为空则使用当前.frame（为了兼容旧版）
  GYAIStatus ProcessData(GYImageData *input, DetectFeatureProtocol *feature,
                         DetectClassifyResult *output, int option);
  GYAIStatus ProcessData(GYImageData *image, DetectFeatureProtocol *feature,
                         GYDetectCommonItemParams *result, int option);

  // @params results [out] 批量返回的结构
  GYAIStatus ProcessData(GYImageData *image, DetectFeatureProtocol *feature,
                         GYDetectCommonResultStruct *results, int option);

  // 快捷接口：输入固定格式的Mat (目前该模块默认BGRA)
  GYAIStatus ProcessData(const cv::Mat &bgra, DetectFeatureProtocol *feature,
                         DetectClassifyResult *output, int option) {
    GYAIReturnIfFalse(!bgra.empty() && bgra.channels() == 4, GYAIErrorCodeDataInvalid);

    auto data = GYImageDataCreateFromMat(bgra, DataFormatBGRA_8UC4);
    return ProcessData(&data, feature, output, option);
  }

  // 这个接口没判断尺寸是否合理，只要两者大小相同就运算
  static float GetDiffOfFeatures(std::vector<float> &v_a, std::vector<float> &v_b);
  // @brief 获取当前网络输出大小 (key=nchw)
  std::map<std::string, std::vector<int>> GetAllOutputDims();

 protected:
  // @brief 根据输入参数组织人脸点，并存入 @dst 地址中
  GYAIStatus AssembleFacePoints(GYImageData *image, DetectFeatureProtocol *feature,
                                GYPoint2fPtr dstFacePoint);
  GYAIStatus ProcessInternal(const cv::Mat &inputCVMat, GYImageData *inputImage,
                             DetectFeatureProtocol *feature, GYDetectCommonItemParams *result,
                             int option);
  GYAIStatus ProcessInternal(const cv::Mat &inputCVMat, const GYPoint2fPtr points256,
                             GYDetectCommonItemParams *result, int option);

  // @brief 旧版本接口——直接传入256点：Android jni在使用 (旧版83点，暂时废弃)
  GYAIStatus ProcessData(GYImageData *image, DetectFeatureProtocol *feature,
                         GYDetectCommonItemParams *result, const GYPoint2fPtr points, int option);

 private:
  std::shared_ptr<FaceRecognizeMat> classify_mat_;
  int feature_size = -1;
};

GYAISPACE_REGISTER_AIMODULE_CREATER_DECLARATION(FaceClassify, "FaceClassify", GYFaceClassify)

GYAILIB_NAMESPACE_END
