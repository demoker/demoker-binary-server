﻿//
//  gyai_texture_convert.h
//  图片生成Metal纹理。
//
//  Created by gennyxu on 2019/9/18.
//  Copyright © 2019 Tencent. All rights reserved.
//

#pragma once

#ifdef __APPLE__

#include <Metal/Metal.h>
#include <light_ai_base/mac/GYAIMetalExtension.h>
#include <light_ai_base/data/gyai_data_t.hpp>

GYAILIB_NAMESPACE_START

/* @brief 返回默认创建和支持的format
 * @params fmt : 默认支持 MTLPixelFormatBGRA8Unorm 和 MTLPixelFormatRGBA8Unorm
 * @return : 返回texture， nil标示失败。
 * */
static inline MTLPixelFormat GetMTLPixelFormatFromDataFormat(DataFormat fmt) {
  if (fmt == DataFormatRGBA_8UC4) {
    return MTLPixelFormatRGBA8Unorm;
  } else if (fmt == DataFormatBGRA_8UC4) {
    return MTLPixelFormatBGRA8Unorm;
  }
  return MTLPixelFormatInvalid;
}

/* @brief 将image转为texture并返回
 * @params image : 输入的图片; NSImage on mac, UIImage on iOS
 * @params preferSize : 期望裁剪到的大小 (0=原图大小)
 * @params device : 输入的device，如果为nil则创建默认的。
 * @params format : 默认支持MTLPixelFormatBGRA8Unorm和MTLPixelFormatRGBA8Unorm
 * @return : 返回texture， nil标示失败。
 * */
id<MTLTexture> GetMetalTextureFromImage(GYAIImputImageClass *image, MTLSize preferSize, id<MTLDevice> device,
                                        MTLPixelFormat format = MTLPixelFormatBGRA8Unorm);

/* @brief 将image转为texture并返回
 * @params path : 输入的图片地址
 * @params preferSize : 期望裁剪到的大小 (0=原图大小)
 * @params device : 输入的device，如果为nil则创建默认的。
 * @params format : 默认支持MTLPixelFormatBGRA8Unorm和MTLPixelFormatRGBA8Unorm
 * @return : 返回texture， nil标示失败。
 * */
id<MTLTexture> GetMetalTextureFromPath(NSString *path, MTLSize preferSize, id<MTLDevice> device,
                                       MTLPixelFormat format = MTLPixelFormatBGRA8Unorm);

/* @brief 创建指定大小\格式的纹理，主要为了作为结果图测试使用
 * @params preferSize : 期望的大小
 * @params format : 默认支持MTLPixelFormatBGRA8Unorm和MTLPixelFormatRGBA8Unorm
 * @params device : 输入的device，如果为nil则创建默认的。
 * @return : 返回texture， nil标示失败。
 * */
id<MTLTexture> CreateMetalTextureWithSize(MTLSize preferSize, MTLPixelFormat format = MTLPixelFormatBGRA8Unorm,
                                          id<MTLDevice> device = nil);

/* @brief 将texture转为image并返回
 * @params texture : 输入的texture, 支持MTLPixelFormatBGRA8Unorm和MTLPixelFormatRGBA8Unorm.
 * @return : 返回image， nil标示失败。
 * */
GYAIImputImageClass *CreateImageFromMTLTexture(id<MTLTexture> texture);

#pragma mark - texture with cpu-bytes-addr

/* @brief copy Texture to @resultAddr [out] (如cv::Mat-data / ios-mac-CGImage-Addr)
 * @params texture[in] 只支持 MTLPixelFormatBGRA8Unorm / MTLPixelFormatRGBA8Unorm
 * @params resultAddr [out] cpu地址，其宽高必须和texture相同，格式为8UC4。
 * */
void CopyImageBytesFromMTLTexture(id<MTLTexture> texture, void *resultAddr);

/* @brief replace Texture from @imageBytes[in] (如cv::Mat-data / ios-mac-CGImage-Addr)
 * @params texture[in] 只支持 MTLPixelFormatBGRA8Unorm / MTLPixelFormatRGBA8Unorm
 * @params imageBytes[in] 非空，存放数据必须和texture的格式匹配
 * @params bytesPreRow[in] 默认为0，即texture.width * 4
 * */
void CopyImageBytesToMTLTexture(id<MTLTexture> texture, const void *imageBytes, size_t bytesPreRow = 0);

GYAILIB_NAMESPACE_END

#endif  // end of #ifdef __APPLE__
