/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKCamera.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKCamera : LAKComponent

@property(nonatomic, assign) NSInteger sizeConfig;

@property(nonatomic, strong) NSString *renderTargetKey;

@property(nonatomic, assign) NSInteger duplicateInput;

@end

NS_ASSUME_NONNULL_END

