//  exclusive_file.h
//  用于编译kernel写文件加锁
//
//  Created by gennyxu on 2022/0/04.
//  Copyright © 2022 Tencent. All rights reserved.
//


#pragma once

#include <stdlib.h>
#include <string>

#if defined _WIN32
#define NOMINMAX
#include <windows.h>
// Do not remove following statement.
// windows.h replace LoadLibrary with LoadLibraryA, which cause compiling issue of TNN.
#undef LoadLibrary
#elif defined __ANDROID__
#include <fcntl.h>
#include <sys/file.h>
#include <unistd.h>
#else
#include <fcntl.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <unistd.h>
#endif

#include <light_ai_base/gyai_macro_t.h>
GYAILIB_NAMESPACE_START

const int TNN_NAME_MAX = 128;

typedef struct shared_mutex_struct {
  // Pointer to the pthread mutex and share memory segment.
#if defined _WIN32
  HANDLE ptr;
#elif defined __ANDROID__
  struct flock* ptr;
#else
  pthread_mutex_t* ptr;
#endif
  int shm_fd;   // Common: Descriptor of shared memory object. Android: File descriptor of the lock.
  char* name;   // Common: Name of the mutex and associated shared memory object. Android: Name of
                // the file lock.
  int created;  // Equals 1 (true) if initialization of this structure caused creation of
  // a new shared mutex.
  // Equals 0 (false) false if this mutex was just retrieved from shared memory.
} shared_mutex_t;

class ExclFile {
 public:
  explicit ExclFile(std::string fname);

  ~ExclFile();

  // @brief try create the file exclusively
  bool Ready();

 private:
  bool IsLockFileExists();
  bool IsFileExists();

  std::string m_fname;
  std::string m_lock_name;
  bool m_created;
  shared_mutex_t m_mutex;
};

GYAILIB_NAMESPACE_END
