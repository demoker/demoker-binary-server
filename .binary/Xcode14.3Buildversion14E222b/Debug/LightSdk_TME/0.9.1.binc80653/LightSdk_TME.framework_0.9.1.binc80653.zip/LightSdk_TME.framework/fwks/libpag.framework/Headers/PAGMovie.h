///////////////////////////////////////////////////////////////////////////////////////////////////
//
//  The MIT License (MIT)
//
//  Copyright (c) 2016-present, Tencent. All rights reserved.
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy of this software
//  and associated documentation files (the "Software"), to deal in the Software without
//  restriction, including without limitation the rights to use, copy, modify, merge, publish,
//  distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the
//  Software is furnished to do so, subject to the following conditions:
//
//      The above copyright notice and this permission notice shall be included in all copies or
//      substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
//  BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
//  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
///////////////////////////////////////////////////////////////////////////////////////////////////

#import "PAGImage.h"
#import "PAGComposition.h"

@interface PAGMovie : PAGImage

/**
 *  Creates a PAGMovie object from a PAGComposition object, returns null if the composition is null.
 */
+ (PAGMovie *)FromComposition:(PAGComposition *)composition;

/**
 * Creates a PAGMovie object from a path of a video file, return null if the file does not exist or it's not a
 * valid video file.
 */
+ (PAGMovie *)FromVideoPath:(NSString *)filePath;

/**
 * Creates a PAGMovie object from a specified range of a video file, return null if the file does not exist or
 * it's not a valid video file.
 *
 * @param startTime start time of the movie in microseconds.
 * @param duration duration of the movie in microseconds. 
 */
+ (PAGMovie *)FromVideoPath:(NSString *)filePath startTime:(int64_t)startTime duration:(int64_t)duration;

/**
 * Returns the duration of this movie in microseconds.
 */
- (int64_t)duration;

@end
