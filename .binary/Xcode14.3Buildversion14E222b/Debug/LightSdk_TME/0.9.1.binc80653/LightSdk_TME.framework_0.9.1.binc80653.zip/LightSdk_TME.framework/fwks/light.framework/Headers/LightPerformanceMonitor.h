//
//  LightPerUtils.h
//  light
//
//  Created by sheng on 2021/6/29.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, LightPerformanceRunMode) {
    LightPerformanceRunModeCustomer = 0,
    LightPerformanceRunModeOnlyCpu = 1,
    LightPerformanceRunModeOnlyGpu = 2,
};

NS_ASSUME_NONNULL_BEGIN

@interface LightPerformanceMonitor : NSObject

// 是否开启性能监控
+ (void)SetBenchEnable:(BOOL)enable;
+ (void)SetBenchEnable:(BOOL)enable withThreshold:(float)threshold;

// 下发监控配置
+ (void)SetBenchConfig:(NSString *)config;
+ (void)SetBenchConfig:(NSString *)config withThreshold:(float)threshold;

// 是否开启性能报告生成模式
+ (void)SetPerformanceEnable:(BOOL)enable traceEnable:(BOOL)traceEnable;
+ (void)SetPerformanceEnable:(BOOL)enable traceEnable:(BOOL)traceEnable enlishKey:(BOOL)enlishKey;

// 更新性能报告的运行模式
+ (void)UpdateRunMode:(LightPerformanceRunMode)runMode;

// 生成报告到本地
+ (BOOL)SavePerformanceReport;
// 获取性能报告
+ (NSString*)GetPerformanceReport;

@end

NS_ASSUME_NONNULL_END

