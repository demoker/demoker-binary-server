/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKVolumeEffect.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKVolumeEffect : LAKSerializable

@property(nonatomic, assign) NSInteger startOffset;

@property(nonatomic, assign) NSInteger endOffset;

@property(nonatomic, assign) NSInteger duration;

@property(nonatomic, assign) float start;

@property(nonatomic, assign) float end;

@end

NS_ASSUME_NONNULL_END

