﻿//
//  GYImageDataMatExtension.h
//  GYImage和CVMat的扩展
//
//  Created by gennyxu on 2020/11/10.
//  Copyright © 2020 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/data/GYImageDataMatExtension.h>

GYAILIB_NAMESPACE_START

// @brief 根据输入期望fmt，将srcData转换成对应格式的Mat存入dst（支持RGBA/BGRA/BGR/RGB/Gray）
// @params srcData [in] 输入的数据，用于转换成dst（非空）
// @params dst [out] 返回结果，如果成功说明格式是fmt [in] 格式（非空）
// @params fmt [in] 期望输出的dst的数据格式（即便格式与srcData格式相同，也会拷贝一份数据）
// @return 返回执行的错误码
GYAI_PUBLIC
GYAIStatus GYImageDataGetMatWithFormat(const GYImageData &srcData, cv::Mat *dst, DataFormat fmt);

// @brief 从src中拷贝data赋值到dst中（格式相同，直接拷贝；否则转换到dst的格式，再拷贝）
// @params dst [out] 返回结果；其内部fmt用于和srcFmt对比（非空）
// @params src/srcFmt [in] 输入的mat和格式
// @return 返回执行的错误码
GYAI_PUBLIC
GYAIStatus GYImageDataCopyDataFromMat(GYImageData *dst, const cv::Mat &src, DataFormat srcFmt);

GYAILIB_NAMESPACE_END
