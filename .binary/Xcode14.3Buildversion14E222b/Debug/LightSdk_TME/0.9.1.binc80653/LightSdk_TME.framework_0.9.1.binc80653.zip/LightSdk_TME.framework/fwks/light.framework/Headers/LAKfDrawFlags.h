/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKfDrawFlags.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKfDrawFlags) {
    LAKfDrawFlagsNodes = 1,
    LAKfDrawFlagsLinks = 2,
    LAKfDrawFlagsFaces = 4,
    LAKfDrawFlagsTetras = 8,
    LAKfDrawFlagsNormals = 16,
    LAKfDrawFlagsContacts = 32,
    LAKfDrawFlagsAnchors = 64,
    LAKfDrawFlagsNotes = 128,
    LAKfDrawFlagsClusters = 256,
    LAKfDrawFlagsNodeTree = 512,
    LAKfDrawFlagsFaceTree = 1024,
    LAKfDrawFlagsClusterTree = 2048,
    LAKfDrawFlagsJoints = 4096,
    LAKfDrawFlagsNodesWithIndex = 8192,
    LAKfDrawFlagsStd = 12494,
    LAKfDrawFlagsStdTetra = 12498
};

NS_ASSUME_NONNULL_END

