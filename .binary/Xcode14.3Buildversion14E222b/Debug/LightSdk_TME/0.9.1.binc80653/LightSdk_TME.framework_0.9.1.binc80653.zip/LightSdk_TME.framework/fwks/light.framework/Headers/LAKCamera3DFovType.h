/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKCamera3DFovType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKCamera3DFovType) {
    LAKCamera3DFovTypeVERTICAL = 0,
    LAKCamera3DFovTypeHORIZONTAL = 1
};

@interface LAKCamera3DFovTypeStringConverter : NSObject
+ (NSString *)toString:(LAKCamera3DFovType)camera3DFovType;
+ (LAKCamera3DFovType)fromString:(NSString *)string;
@end

NS_ASSUME_NONNULL_END

