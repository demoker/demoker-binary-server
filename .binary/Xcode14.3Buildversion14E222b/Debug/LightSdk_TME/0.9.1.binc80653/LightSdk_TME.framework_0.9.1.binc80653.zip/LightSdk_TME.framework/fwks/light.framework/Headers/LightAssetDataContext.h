//
//  LightAssetDataContext.h
//  light
//
//  Created by zebiaohuang on 2021/9/16.
//

#import <Foundation/Foundation.h>
#import "LightAsset.h"
#import "LAKEntity.h"
#import "LightController.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LightAssetDataContextType) {
    // 以 Json 的形式组织数据结构
    LightAssetDataContextTypeJson = 0,
    // 以 Entity Tree 的形式组织数据结构
    LightAssetDataContextTypeEntityTree = 1
};

typedef NS_ENUM(NSInteger, LAKContextMergeType) {
    // 新内容融合在已有内容的尾部
    LAKContextMergeTypeBack = 0,
    // 新内容融合在已有内容的头部
    LAKContextMergeTypeFront = 1
};

@interface LightAssetDataContext : NSObject

#pragma mark - init

/** 用 LightAsset 进行初始化
 * @param asset 用于构建 Context 的基础 Asset
 * @return 若 asset 不合法可能返回为空
 * @note 相当于 dataType 为 LightAssetDataContextTypeJson
 */
+ (instancetype)Make:(LightAsset *)asset;

/** 用 LightAsset 进行初始化
 * @param asset 用于构建 Context 的基础 Asset
 * @param dataType 指定的数据组织形式
 * @return 若 asset 不合法可能返回为空
 */
+ (instancetype)Make:(LightAsset *)asset dataType:(LightAssetDataContextType)dataType;

// 禁止调用默认的 init 和 new 方法
- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

#pragma mark - LightAsset manipulation

/** 导出为 LightAsset
 * @return 导出的 LightAsset
 */
- (LightAsset *)exportLightAsset;

/** 融合一个 LightAsset 进入当前 Context
 * @param asset 被融合的素材
 * @return 是否成功，若失败可能是因为 1. 被融合的素材不合法 2. 不支持融合这个素材
 * @note 目前仅当以 LightAssetDataContextTypeJson 的数据组织形式时有效
 * @note 相当于 mergeType 为 LAKContextMergeTypeBack
 */
- (BOOL)addLightAsset:(LightAsset *)asset;

/** 融合一个 LightAsset 进入当前 Context
 * @param asset 被融合的素材
 * @param mergeType 融合的方法(位置)
 * @return 是否成功，若失败可能是因为 1. 被融合的素材不合法 2. 不支持融合这个素材
 * @note 目前仅当以 LightAssetDataContextTypeJson 的数据组织形式时有效
 */
- (BOOL)addLightAsset:(LightAsset *)asset mergeType:(LAKContextMergeType)mergeType;

/** 更新一个 inputSource
 * @param inputSource 被更新的 inputSource 的属性
 * @param key 被更新的 inputSource 的索引值
 * @return 是否成功
 * @note 仅当以 LightAssetDataContextTypeEntityTree 的数据组织形式时有效
 * @note 可以通过传入 inputSource = null 来删除
 * @note 目前 SDK 支持动态更新的只有添加的行为，更改和删除需要 reload 来保证生效
 */
- (BOOL)updateInputSource:(NSDictionary *)inputSource forKey:(NSString *)key;

/** 更新一个 property
 * @param property 被更新的 property 的属性
 * @param key 被更新的 property 的索引值
 * @return 是否成功
 * @note 仅当以 LightAssetDataContextTypeEntityTree 的数据组织形式时有效
 * @note 可以通过传入 property = null 来删除
 * @note 目前 SDK 完全不支持支持动态更新，需要 reload 来保证生效
 */
- (BOOL)updateProperty:(NSDictionary *)property forKey:(NSString *)key;

+ (BOOL)componentSupportDynamicallyUpdate:(Class)componentClass;

// 数据组织形式，默认为 LightAssetDataContextTypeJson
@property (nonatomic, assign, readonly) LightAssetDataContextType dataType;

/** 根节点，编辑的同时会反射到 engine 中，可利用这个特点通过改变 OC 数据结构来改变 SDK 的结构
 * @note 仅当以 LightAssetDataContextTypeEntityTree 的数据组织形式时有效
 */
@property (nonatomic, strong, readonly) LAKEntity *rootEntity;

/** inputSources
 * @note 仅当以 LightAssetDataContextTypeEntityTree 的数据组织形式时有效
 */
@property (nonatomic, strong, readonly) NSDictionary<NSString *, NSDictionary *> *inputSources;

/** properties
 * @note 仅当以 LightAssetDataContextTypeEntityTree 的数据组织形式时有效
 */
@property (nonatomic, strong, readonly) NSDictionary *properties;

// 绑定的 LightController，用于 Context 的变化和 SDK 中素材变化的反射
@property (nonatomic, weak) LightController *controller;

@end

NS_ASSUME_NONNULL_END
