// Copyright 2020 Tencent Inc. All Rights Reserved.
//  LightEngine.h
//  light-sdk
//
//  Created by zongyang on 2020/5/25.
//

#import "Definitions.h"
#import "LightSurface.h"
#import "LightMovieController.h"
#import "LightCameraController.h"
#import "LightConfig.h"
#import "LightAudioOutput.h"
#import "LightVideoOutput.h"



@interface LightEngine : NSObject


/// 鉴权接口，返回值为0则表示鉴权成功
/// @param licencePath 证书绝对路径
/// @param appID 发布器中台统一分配的appid
/// @param appEntry 发布器中台统一分配的业务入口
+ (int)initAuth:(NSString *)licencePath
          appID:(NSString *)appID
       appEntry:(NSString *)appEntry;

+ (instancetype)Make:(LightVideoOutputConfig*)videoOutputConfig audioOutputConfig:(LightAudioOutputConfig*)audioOutputConfig rendererConfig:(LightRendererConfig*)rendererConfig;


/**
    Get SDK Version eg. 2.0.0.0
 */
+ (NSString*)Version;

+ (int)ComponentLevel;

+ (BOOL)isDeviceAbilitySupported:(NSString *)abilityKey;

+ (void)initDeviceConfig:(NSString *)path customId:(NSString *)customId;

+ (void)initDeviceConfig:(NSString *)path;

- (BOOL)setSurface:(LightSurface*)surface;

- (LightMovieController*)setAssetForMovie:(LightAsset*)asset;

- (NSArray<LightController*>*)setTemplateAssets:(NSArray<LightClipAsset*>*)assets;

- (LightCameraController*)setAssetForCamera:(LightAsset*)asset;

- (void)setConfig:(LightConfig *)config;

- (LightAudioOutput*)audioOutput;

- (LightVideoOutput*)videoOutput;

+ (NSString *)GetLightAIAvatarMeshVer;

+ (NSInteger)GetLightAIAvatarGender;

+ (void)SwitchToLightAICamera;

+ (void)ReturnFromLightAI:(NSInteger)InResultCode InJsonData:(NSString *)InJsonData;

+ (void)SetCameraUI:(void(^)(void))pFunc;

// gender:0-未确定；1-男生；2-女生
- (void)setUEFaceStr:(NSString *)str gender:(int)gender;

// 通过json设置zplan表情数据
- (void)setZplanExpressionData:(NSString *)dataStr;
@end
