﻿//  FaceDetector.h
//  人脸检测
//
// Created by zijunzhang on 2020/7/31.
// Copyright © 2020 tencent. All rights reserved.
//

#pragma once

#ifdef __APPLE__
#include <TargetConditionals.h>
#endif
#include <light_detect_face/FaceDetectorFeature.h>
#include <algorithm>
#include <memory>
#include <vector>

GYAILIB_NAMESPACE_START

class SystemFaceInfo {
 public:
  int64_t face_id = 0;  // 因为系统人脸id可能为很大的值，使用64 int
  GYAIRect4f frame;     // 人脸框位置 (为归一化的坐标)
  bool hasRoll = true;  // 是否有roll角度（关键值，用于判断人脸方向）
  float pitch = 0, yaw = 0, roll = 0;  // 欧拉角，主要使用roll
};

// 人脸的检测结果（该值用于返回结果）
class FaceDetectResult : public DetectFeatureProtocol {
 public:
  FaceDetectResult();
  ~FaceDetectResult() override;

#pragma mark - DetectFeatureProtocol
  // 接口扩展：如获取默认 DetectFeatureProtocol-feature
  size_t GetFeaturesCount() override { return faces.size(); }
  DetectFeatureProtocol *GetFeatureAtIndex(int idx) override { return faces[idx].get(); }
  size_t GetFeaturePointCount(int idx) override { return faces[idx]->GetFeaturePointCount(0); }
  GYPoint4fPtr GetFeaturePoint4f(int idx) override { return faces[idx]->GetFeaturePoint4f(0); }
  GYPoint2fPtr GetFeaturePoint2f(int idx) override { return faces[idx]->GetFeaturePoint2f(0); }
  GYAIRect4f GetFeatureFrame(int idx) override { return faces[idx]->GetFeatureFrame(0); }
  GYAISize2f GetFeatureImageSize(int idx) override { return faces[idx]->GetFeatureImageSize(0); }
  DeviceOrientation GetFeatureOrientation(int idx) override { return orientation; }

#pragma mark - 对外接口

  // 根据当前图片方向和宽高，计算当前图片旋转回到prefer_ori方向需要的矩阵。
  GYAffineTransform transform(DeviceOrientation prefer_ori, float w, float h);
  // 当前检测结果所使用的图片的方向（部分模块结果计算会需要知道方向）
  DeviceOrientation orientation = DeviceOrientationUp;
  bool flip = false;  // 生成点位计算矩阵时，是否需要左右翻转（通常依赖前后置相机）。

  std::vector<std::shared_ptr<FaceDetectorFeature>> faces;

  // 系统人脸框（输入也是输出）：因为部分模块可能用到系统人脸框，放入结果中作为输入和输出。
  DeviceOrientation DetectOrientationFromSystemFace();
  std::vector<SystemFaceInfo> system_faces;
};

using FaceDetector = FaceDetectResult;  // 创建别名，向前兼容

#pragma mark - platform extension

#ifdef __APPLE__
// 是否支持系统人脸框代替优图检测 （内部的框只适配了iOS，其他系统暂时屏蔽）
# define GYFACE_ENABLE_SYSTEM_FACE_DETECT_RECT TARGET_OS_IPHONE
# define GYFACE_ENABLE_SYSTEM_FACE_ORIENTATION 1  // 是否支持系统人脸矫正图片检测方向
#else
# define GYFACE_ENABLE_SYSTEM_FACE_DETECT_RECT 0  // 是否支持系统人脸框代替优图检测
# define GYFACE_ENABLE_SYSTEM_FACE_ORIENTATION 0  // 是否支持系统人脸矫正图片检测方向
#endif

#if GYFACE_ENABLE_SYSTEM_FACE_ORIENTATION
/* @brief 根据当前设备的方向和系统人脸框，计算期望的人脸检测方向
 * @params faces为系统的人脸信息
 * @params curDeviceOri 当前的设备的方向，根据陀螺仪指定
 * @params flip 由前后置决定，人脸坐标系不一样
 * */
DeviceOrientation PreferDetectOrientationFromSystemFace(const std::vector<SystemFaceInfo> &faces,
                                                        DeviceOrientation curDeviceOri, bool flip);

#pragma mark - 此为人脸对方向进行校正的函数

/* (简单讲就是得到当前人脸朝向，方便用来旋转图片使得人脸为正方向；系统相机是默认的LandRight视频帧)
 ----------------------------------------------------------|
 |     | y+          face roll angleV=0             |      |
 |     |               front camera                 |      |
 |     |                                            | ____ |
 |  o  |---->                                 <-----| |  | |
 | cam |face roll angle=90      face roll angle=270 | |  | |
 |     |                                            | ---- |
 |     |                                            | home |
 |     | (0,0)       face roll angle^=180        x+ |      |
 ----------------------------------------------------------|
 * @params face 为系统的人脸信息
 * @params curDeviceOri 当前的设备的方向，根据陀螺仪指定
 * @params flip 由前后置决定，人脸坐标系不一样
 */
DeviceOrientation SystemFacePreferOrientation(const SystemFaceInfo &face,
                                              DeviceOrientation curDeviceOri, bool flip);
#endif

GYAILIB_NAMESPACE_END
