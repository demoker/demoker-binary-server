//
//  LightWMElement.h
//  light
//
//  Created by honghewang on 2020/11/4.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LightWMElement : NSObject

@property (nonatomic, strong) NSString *materialId;
@property (nonatomic, strong) NSString *elementId;

/**
 * 枚举类型，可取值为：
 * "SINCE", // 正计时
 * "COUNTDOWN", // 倒计时
 * "CHECK_IN", // 打卡
 * "EDITABLE_LOCATION", // 可编辑地址，即fmtstr为"[location]"的
 * "PLAIN_TEXT"; // 文本
 *
 * 以上类型，除了"EDITABLE_LOCATION"内存存储，其他都是持久化存储
 */
@property (nonatomic, strong) NSString *type;


- (instancetype)initWithMaterialId:(NSString *)materialId
                         elementId:(NSString *)elementId
                              type:(NSString *)type;


- (void)setLocation:(NSString *)addr;

//  参数为毫秒
- (void)setDate:(long long)timestamp;

- (void)setText:(NSString *)text;

/**
 * 获取当前设置的值，
 * CHECK_IN返回次数，默认为1
 * SINCE COUNTDOWN 返回日期
 * EDITABLE_LOCATION PLAIN_TEXT返回文本
 */
- (NSString *)getCustomInnerValue;

/**
 * 重置打卡
 */
- (void)resetCheckIn;

/**
 * 打卡，返回打卡错误码
 *
 * @return errCode 0--success, 1--参数错误 11--同一天重复打卡
 */
- (int)doCheckIn;

@end

NS_ASSUME_NONNULL_END
