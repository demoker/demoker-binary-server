//
//  LightReporter.h
//  light-sdk
//
//  Created by llllish on 2020/9/3.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class LightReporter;
@protocol LightReporterDelegate <NSObject>

@required

- (void)LightReporter:(LightReporter *)lightReporter reportEvent:(NSString *)event reportData:(NSDictionary *)data;

@end

@interface LightReporter : NSObject

@property(nonatomic,copy)NSString *appID;
@property(nonatomic,copy)NSString *appEntry;
@property(nonatomic)BOOL aeKitReportEnable;

+ (instancetype)sharedInstance;

- (bool)reportExternalEvent:(NSString *)event data:(NSDictionary *)data;

- (void)launchFromApp:(NSString *)app entry:(NSString *)entry;

- (NSString *)getShareEventKey;

- (void)writeReport:(NSString *)eventID infoDictionary:(NSDictionary *)dic;

- (void)report;

@property (nonatomic, weak) id<LightReporterDelegate> reportDelegate;

@end

NS_ASSUME_NONNULL_END
