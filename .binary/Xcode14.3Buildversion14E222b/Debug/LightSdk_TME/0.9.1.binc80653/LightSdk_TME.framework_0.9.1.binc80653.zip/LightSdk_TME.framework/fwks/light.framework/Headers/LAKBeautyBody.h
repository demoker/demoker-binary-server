/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBeautyBody.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKBeautyBody : LAKComponent

@property(nonatomic, assign) float longLegStrength;

@property(nonatomic, assign) float thinBodyStrength;

@property(nonatomic, assign) float autothinBodyStrength;

@property(nonatomic, assign) float thinShoulderStrength;

@property(nonatomic, assign) float slimWaistStrength;

@property(nonatomic, assign) float slimHeadStrength;

@property(nonatomic, assign) float slimLegStrength;

/**
 * Comments extracted from cpp files:
 *
 * 一键瘦身最小值
 */
@property(nonatomic, assign) float thinBodyParamMin;

/**
 * Comments extracted from cpp files:
 *
 * 一键瘦身最大值
 */
@property(nonatomic, assign) float thinBodyParamMax;

/**
 * Comments extracted from cpp files:
 *
 * 一键瘦身过界值
 */
@property(nonatomic, assign) float thinBodyParamOver;

@end

NS_ASSUME_NONNULL_END

