/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKParticle.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKParticleTriggerType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKParticle : LAKComponent

@property(nonatomic, assign) LAKParticleTriggerType triggerType;

@property(nonatomic, strong) NSString *materialPath;

@property(nonatomic, strong) NSString *triggerJson;

@property(nonatomic, strong) NSString *texturePath;

@property(nonatomic, strong) NSString *colorTexturePath;

@property(nonatomic, strong) NSString *backgroundTexturePath;

@property(nonatomic, strong) NSString *backgroundPath;

@property(nonatomic, strong) NSString *sourcePositionPath;

@property(nonatomic, strong) NSString *inputRenderTarget;

@property(nonatomic, assign) BOOL useColorReference;

/**
 * Comments extracted from cpp files:
 *
 * bool is_trigger;
 */
@property(nonatomic, assign) NSInteger triggerTime;

@end

NS_ASSUME_NONNULL_END

