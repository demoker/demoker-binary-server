/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKAnimoji3DWrapperComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKAnimojiConfig.h"
#import "LAKComponent.h"
#import "LAKEyeSetting.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKAnimoji3DWrapperComponent : LAKComponent

@property(nonatomic, strong) NSArray<LAKAnimojiConfig *> *animojiConfig;

/**
 * Comments extracted from cpp files:
 *
 * [serialization]
 */
@property(nonatomic, strong) NSString *morphName;

@property(nonatomic, assign) BOOL trackEyeRoll;

@property(nonatomic, assign) NSInteger eyeBoneId;

/**
 * Comments extracted from cpp files:
 *
 * 深度模式开关 true：开启深度模型，false：默认High级表情基求解
 */
@property(nonatomic, assign) BOOL enableProMode;

/**
 * Comments extracted from cpp files:
 *
 * 平滑度，在表情准还原度和稳定性之间进行平滑
 */
@property(nonatomic, assign) float smoothStrength;

@property(nonatomic, strong) LAKEyeSetting *eyeSetting;

@end

NS_ASSUME_NONNULL_END

