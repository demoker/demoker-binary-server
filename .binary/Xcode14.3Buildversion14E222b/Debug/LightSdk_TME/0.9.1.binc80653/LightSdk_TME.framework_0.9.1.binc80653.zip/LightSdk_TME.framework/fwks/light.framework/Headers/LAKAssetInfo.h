/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKAssetInfo.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKControllerType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKAssetInfo : LAKComponent

@property(nonatomic, assign) NSInteger randomSeed;

@property(nonatomic, assign) NSInteger duration;

@property(nonatomic, strong) NSString *rootPath;

@property(nonatomic, assign) BOOL inited;

@property(nonatomic, assign) LAKControllerType controllerType;

@end

NS_ASSUME_NONNULL_END

