//
//  Light3DMMData.h
//  light
//
//  Created by zebiaohuang on 2021/4/6.
//

#import <Foundation/Foundation.h>
#import "LightAIBaseData.h"

NS_ASSUME_NONNULL_BEGIN

/// 对应 LightFace3DMMAgentResult
@interface Light3DMMData : LightAIBaseData

///
@property (nonatomic, strong) NSArray<LightAIBaseFeature*> *result_expression;

///
@property (nonatomic, strong) NSArray<LightAIBaseFeature*> *result_points;

///
@property (nonatomic, strong) NSArray<LightAIBaseFeature*> *origin_result;

@end

NS_ASSUME_NONNULL_END
