/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKPreferredCoverTime.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKPreferredCoverTime : LAKComponent

@property(nonatomic, assign) NSInteger coverTime;

@end

NS_ASSUME_NONNULL_END

