/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKPointItem.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKPointItem : LAKSerializable

/**
 * Comments extracted from cpp files:
 *
 * 点位最终位置
 */
@property(nonatomic, assign) float positionX;

@property(nonatomic, assign) float positionY;

/**
 * Comments extracted from cpp files:
 *
 * 点位是否为固定状态
 */
@property(nonatomic, assign) BOOL fixed;

@end

NS_ASSUME_NONNULL_END

