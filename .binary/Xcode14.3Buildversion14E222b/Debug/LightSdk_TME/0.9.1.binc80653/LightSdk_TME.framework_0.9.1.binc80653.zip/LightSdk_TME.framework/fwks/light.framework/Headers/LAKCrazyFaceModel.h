/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKCrazyFaceModel.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKCrazyFaceModel : LAKSerializable

@property(nonatomic, strong) NSString *faceMaskImage;

@property(nonatomic, strong) NSString *faceMaskPoints;

@property(nonatomic, strong) NSArray<NSNumber *> *modelImageFacePoints;

@property(nonatomic, strong) NSArray<NSNumber *> *modelImageFaceColor;

@property(nonatomic, strong) NSString *modelImage;

@property(nonatomic, assign) float blendAlpha;

@property(nonatomic, assign) float distortionAlpha;

@property(nonatomic, assign) BOOL closeEye;

@end

NS_ASSUME_NONNULL_END

