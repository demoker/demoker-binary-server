﻿//  GYDetectCommonHandler.h
//  作为检测、配准、追踪的基础逻辑类，用于封装检测器；子类可以重写实现更加复杂逻辑。
//  Created by gennyxu on 2020/4/13.
//  Copyright © 2020 Tencent. All rights reserved.
//
#pragma once

#include <light_detect_base/GYDetectBaseProtocol.h>
#include <light_detect_base/GYDetectHandlerConfig.h>
#include <vector>

GYAILIB_NAMESPACE_START

class GYAI_PUBLIC DetectHandlerBase {
 public:
  // ----------------------------------------------------------------------------------------------
  /* 第一步初始化, 并设置好参数: */
  DetectHandlerBase();
  virtual ~DetectHandlerBase();

  // ----------------------------------------------------------------------------------------------
  // 第二步设置网络。
  /**
   传入模型资源路径，根据模型生成Rapid网络 (如需多次调用，请先手动调用Cleanup)
   @params config : 资源路径和对应的配置参数。
   @return : 标示执行成功与否， 0-成功，其他-失败。
   备注：对于子类，重写该方法，具体功能初始化好handler后必须赋值给_detectHandler。
   备注：如果机器有大小模型差异，调用该方法前就需要筛选好当前机器应该加载那个模型，并生成路径传入（该方法内不做筛选）
   */
  virtual GYAIStatus SetupWithModelConfig(const DetectHandlerConfig& config);

  // ----------------------------------------------------------------------------------------------
  // 第三部处理
  /**
   处理输入的纹理，得到结果纹理的Mask。（确保加载成功后再调用，并且输入输出纹理大小和要求的一直，否则效果可能有异常）
   @params input_bgra / imageIn : 输入图片，满足模型要求，通常为四通道BGRA32格式。
   @params result :
   可以传入nil，将返回内部的默认texture；默认Texture是唯一的，在下次调用该接口前，及时使用（Texture大小和outputSize一致）。
   @params option : 用于控制本次操作是否关闭部分功能（如只进行手的检测、追踪，不进行配准和分类）。
   @return : 标示执行成功与否,  0-成功，其他-失败。
   备注：请确定必须setupWithModelPath成功才可以调用，否则会Crash。
   备注：如果非视频版本，每一次输入都会执行检测操作；如果是视频，前一帧没有目标或option配置检测，则执行检测操作（如需关闭，通过option控制）
   */
  virtual GYAIStatus Forward(const cv::Mat& input_bgra, GYDetectCommonResultStruct* result,
                             GYDetectCommonForwardOption option);

#pragma mark - Other Info
  // ----------------------------------------------------------------------------------------------
  // 第四部处理（使用完成清除资源）
  /**
   清除内部的检测资源；
   清除后，下次使用前需调用setupWithModelPath重新设置。（重复调用setupWithModelPath:内部也会先调用该方法清除数据）。
   备注：内部会判断mDetector、mTracker、mKeypointer和mClassifyer是否存在，并delete然后设置为null。子类如重写,
   建议调用父类。
   */
  virtual void CleanupModelData();  // NS_REQUIRES_SUPER;

  // 清除缓存的结果，防止进入追踪逻辑 （eg. last result cache）。
  virtual void CleanupCachedResultData();

  // ----------------------------------------------------------------------------------------------
  // 获取网络信息 : 只有初始化或者设置成功后，该返回值才有意义。否则可能返回为（0，0，0, 0）
  const RapidNetSize& GetNetInputSize();

  // 检查模型是否加载好，可以进行forward操作。
  // 默认detector、keypointer、calssify任意一个初始化成功被赋值，便返回true
  bool ModelHadBeenLoaded();

  // 禁止拷贝: 因为内部为模型、纹理等实例，不能轻易拷贝。
  DetectHandlerBase(const DetectHandlerBase &) = delete;
  DetectHandlerBase &operator=(const DetectHandlerBase &) = delete;

 protected:
#pragma mark - subclass override & private
  /**
   执行追踪Track/配准Keypoint/分类Classify操作。
   @params input_image : 输入图片。
   @params output \ params : 用于返回结果，非空。
   @preferPointCount :
   如果大于0，则检测结果的点数量必须和该参数相同，否则会失败。否则会被赋值为检测出的结果。
   @return : 0标示成功，其他是错误码。
   备注：子类可以重写该方法，加上平滑等操作。但是需要判断是否执行成功再决定是否平滑操作。
  */
  virtual GYAIStatus ForwardDetect(const cv::Mat& input_image,
                                   std::vector<GYDetectCommonItemParams>* output,
                                   GYDetectCommonForwardOption option);
  virtual GYAIStatus ForwardTrack(const cv::Mat& input_bgra, GYDetectCommonItemParams* params);
  virtual GYAIStatus ForwardKeypoint(const cv::Mat& input_bgra, GYDetectCommonItemParams* params);
  virtual GYAIStatus ForwardClassify(const cv::Mat& input_bgra, GYDetectCommonItemParams* params);

 protected:
#pragma mark - net data / private from objective-c
  // 内部函数：用于子类调用；用于通过不同的类实现。
  virtual GYAIStatus SetupWithModelConfigInternal(const DetectHandlerConfig& config);
  // 内部函数：用于子类调用；加载成功后设置网络大小、点数量等
  virtual GYAIStatus CustomParamsWhenModelHadBeenLoaded(const DetectHandlerConfig& config);

  GYAISpace::DetectBase* mDetector = nullptr;  // 默认用于判断是否加载完成，setup时赋值
  GYAISpace::DetectBase* mTracker = nullptr;     // setup赋值，cleanup清除
  GYAISpace::DetectBase* mKeypointer = nullptr;  // setup赋值，cleanup清除
  GYAISpace::DetectBase* mClassifyer = nullptr;  // setup赋值，cleanup清除

  RapidNetSize mInputSize;  // 默认为检测或者分类图大小。 注意：在setupWithModelPath成功后才有意义
  int mPreferKeypointsCount = 0;  // 默认关键点的数量：
  float mTrackExpandFactor = 0.2f;  // 追踪区域扩大比例：通常参考值猫0.2; 人体0.25；手0.35。

 protected:
#pragma mark - lastest result cache
  // 记录上一帧结果，用于平滑或者返回结果等操作（参考清除缓存操作接口）
  bool mIsUseingForVideo = true;  // 正常只有视频才会缓存（需要询问算法，内部是否也有缓存）
  GYDetectCommonResultStruct mLastResult;
};

GYAILIB_NAMESPACE_END
