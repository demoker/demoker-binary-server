﻿//
//  GYAIBaseResultObject.h
//  该类定义为加测结果的OC封装。
//
//  Created by gennyxu on 2020/10/30.
//  Copyright © 2020 tencent. All rights reserved.
//

#pragma once

#ifdef __APPLE__

#include <CoreGraphics/CoreGraphics.h>
#include <Foundation/Foundation.h>
#include <light_ai_base/light_ai_mac.h>

#pragma mark - OC对检测结果的封装

// 该类定义为结果的OC封装：检测的具体结果。
@interface GYAIBaseDetectResult : NSObject {
@protected
    // 追踪的ID；追踪使用，妆容平滑时候使用到 (或区分不同目标使用，但各个算法并非都使用了，需咨询算法同学)。
    int _trace_id;
    float _image_width, _image_height;  // 检测图的宽/高度，下方坐标对应的坐标系横轴；换算0~1时x/y需除以该值
    float _confidence; // 总体的置信度，主要用于区分检测框的结果
    CGRect _frame; // 检测目标的位置（基于image_width/height坐标系）
    
    GYAIPoint3f _euler; // 欧拉角，对应pitch\yaw\roll角度，三个轴旋转
    int _classify; // 分类所属的index（可能为非法值，各个模型不一样，并非所有都会使用）
    float _classifyConfidence; // 分类的置信度，主要用于区分分类结果准确性
}

// 该feature的检测结果是否为合法结果（即是否有数据）
@property (nonatomic, assign, readonly, getter=isValid) BOOL valid;

// 追踪的ID；追踪使用，妆容平滑时候使用到 (或区分不同目标使用，但各个算法并非都使用了，需咨询算法同学)。
@property (nonatomic, assign) int trace_id;

// 检测图片的大小，下方所有的点坐标、frame都是基于该检测图坐标系计算的结果，换算0~1时需除以该值。
@property (nonatomic, assign) float image_width;  // 检测图的宽度，下方坐标对应的坐标系横轴；换算0~1时x需除以该值
@property (nonatomic, assign) float image_height; // 检测图的高度，下方坐标对应的坐标系纵轴；换算0~1时y需除以该值
@property (nonatomic, assign) float confidence; // 总体的置信度，主要用于区分检测框的结果
@property (nonatomic, assign, readonly) CGRect frame; // 检测目标的位置（基于image_width/height坐标系）

// 欧拉角，对应pitch\yaw\roll角度，三个轴旋转，需要确定模型是否支持该值，不支持的话不要获取使用。
@property (nonatomic, assign, readonly) GYAIPoint3f euler; // 欧拉角，对应pitch\yaw\roll角度，三个轴旋转
@property (nonatomic, assign, readonly) float pitch; // 人脸的欧拉角 (对应三个坐标轴上的旋转角度)
@property (nonatomic, assign, readonly) float yaw;   // 人脸的欧拉角 (对应三个坐标轴上的旋转角度)
@property (nonatomic, assign, readonly) float roll;  // 人脸的欧拉角 (对应三个坐标轴上的旋转角度)

// 分类的值、置信度：需要确定模型是否支持该值，不支持的话不要获取使用。。
@property (nonatomic, assign) int classify; // 分类所属的index（可能为非法值，各个模型不一样，并非所有都会使用）
@property (nonatomic, assign) float classifyConfidence; // 分类的置信度，主要用于区分分类结果准确性

// 指向点坐标(二维)的指针: 返回指针指向的是内部二维点数组，数值为image_width、height坐标系（结构释放后不可使用，使用前请判空）。
- (const GYPoint2fPtr)getFeatures NS_RETURNS_INNER_POINTER;
- (const float *)getFeatureVisibility NS_RETURNS_INNER_POINTER;
- (const size_t)getFeatureCount;

#pragma mark - 内部使用的方法
// - (instancetype)init NS_UNAVAILABLE;
- (void)resetAllFeatures; // 重置为默认参数，用于清理结果

@end

#pragma mark - OC对检测结果的封装

// 该类定义为通用结果的OC封装：检测的具体结果。
@interface GYAICommonDetectResultObj : GYAIBaseDetectResult

@end
#endif  // #ifdef __APPLE__
