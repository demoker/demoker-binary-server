/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKPosition.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKPosition : LAKComponent

@property(nonatomic, assign) float x;

@property(nonatomic, assign) float y;

@property(nonatomic, assign) float z;

@end

NS_ASSUME_NONNULL_END

