/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKCatTracking.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKTrackingComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKCatTracking : LAKTrackingComponent

@end

NS_ASSUME_NONNULL_END

