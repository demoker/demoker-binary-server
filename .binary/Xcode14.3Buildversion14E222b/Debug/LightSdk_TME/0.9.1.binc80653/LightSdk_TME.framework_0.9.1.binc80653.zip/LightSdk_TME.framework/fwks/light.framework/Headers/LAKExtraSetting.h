/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKExtraSetting.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKExtraSetting : LAKComponent

@property(nonatomic, assign) BOOL enableRotation;

@property(nonatomic, assign) BOOL resetWhenStartRecord;

@property(nonatomic, assign) BOOL useMetal;

/**
 * Comments extracted from cpp files:
 *
 * 支持切换相机, 前置、后置、前后置，默认前后置
 */
@property(nonatomic, assign) NSInteger supportCameraPosition;

@property(nonatomic, assign) BOOL sync3dRenderEnable;

/**
 * Comments extracted from cpp files:
 *
 * 默认相机位置 0: 不做切换 1: 前置相机 2: 后置相机
 */
@property(nonatomic, assign) NSInteger defaultCameraPosition;

/**
 * Comments extracted from cpp files:
 *
 * 是否需要分贝检测
 */
@property(nonatomic, assign) BOOL needVoiceDecibel;

/**
 * Comments extracted from cpp files:
 *
 * 是否需要智能美颜
 */
@property(nonatomic, assign) BOOL needAutoBeauty;

@property(nonatomic, assign) BOOL enableDowngradeAsset;

@end

NS_ASSUME_NONNULL_END

