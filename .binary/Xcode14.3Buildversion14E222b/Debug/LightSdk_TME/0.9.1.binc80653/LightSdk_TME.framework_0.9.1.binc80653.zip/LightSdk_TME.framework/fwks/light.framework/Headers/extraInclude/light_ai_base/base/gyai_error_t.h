﻿//
//  gyai_error_t.h
//  GYAIBase
//
//  Created by gennyxu on 2020/6/6.
//  Copyright © 2020 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/gyai_macro_t.h>

typedef enum {
  GYAIErrorCodeSuccess = 0,  // OK (no error)

  GYAIErrorCodeWrongFilePath = -10,  // model path error or file not exist
  GYAIErrorCodeCloseFileFail = -11,  // close file failed
  GYAIErrorCodeMallocMemFail = -12,  // malloc / new failed
  GYAIErrorCodeNoData = -20,         // data is empty
  GYAIErrorCodeDataFormat = -21,     // data format error / not support
  GYAIErrorCodeInputInvalid = -22,   // input error / not support
  GYAIErrorCodeProtoInvalid = -23,   // proto file error / not exist / decode failed
  GYAIErrorCodeModelInvalid = -25,   // proto file error / not exist / decode failed
  GYAIErrorCodeDataInvalid = -26,    // 数据错误或者格式错误

  // eg. metal device or context
  GYAIErrorCodeWrongDevice = -30,
  GYAIErrorNoImplementation = -31,   // 无实现
  GYAIErrorInvalidRPDNetSize = -32,  // 获取网络大小失败或数量不对
  GYAIErrorCreateInstFailed = -33,   // 网络生成实例失败

  // 网络生成使用常见错误 (检测类使用)
  GYAIErrorNetForwardNoInput = -101,    // no valid input data
  GYAIErrorNetForwardNoResult = -102,   // no output data
  GYAIErrorDetectBoxIsTooSmall = -110,  // Detect (通常是检测到的框太小，即输出)
  GYAIErrorDetectParamsInvalid = -111,
  GYAIErrorDetectOutputIsEmpty = -113,
  GYAIErrorTrackBoxIsTooSmall = -210,  // Track
  GYAIErrorTrackParamsInvalid = -211,
  GYAIErrorTrackLowConfidence = -212,
  GYAIErrorKeyPointBoxIsTooSmall = -310,  // Key point
  GYAIErrorKeyPointParamsInvalid = -311,
  GYAIErrorKeyPointBoxInvalid = -312,  // 框非法（可能太大、超出算法支持比例大小等）
  GYAIErrorKeyPointTrackingFailed = -314,
  GYAIErrorKeyPointOutputInvalid = -315,
  GYAIErrorClassifyForwardFailed = -401,  // Classify failed, no result
  GYAIErrorClassifyForwardEmpty = -401,   // Classify failed, no result
  GYAIErrorClassifyBoxIsTooSmall = -410,  // Classify
  GYAIErrorClassifyParamsInvalid = -411,
  GYAIErrorClassifyLowConfidence = -412,
  GYAIErrorPreDetectBoxIsTooSmall = -510,  // pre detect
  GYAIErrorPreDetectParamsInvalid = -511,
  GYAIErrorPreDetectLowConfidence = -512,
  GYAIErrorPreDetectOutputIsEmpty = -513,

  // 标识未知错误。
  GYAIErrorCodeOtherError = -1000,
  GYAIErrorAuthFail = -1024,          // 鉴权失败
} GYAIErrorCode;

typedef int GYAIStatus;

#pragma mark - 调试Log的方法定义

#ifdef __ANDROID__
#include <android/log.h>

#define GYAILogTE(fmt, ...) \
  __android_log_print(ANDROID_LOG_ERROR, GYAI_DEFAULT_LOG_TAG, fmt, ##__VA_ARGS__)
#define GYAILogTI(fmt, ...) \
  __android_log_print(ANDROID_LOG_INFO, GYAI_DEFAULT_LOG_TAG, fmt, ##__VA_ARGS__)
#define GYAILogTD(fmt, ...) \
  __android_log_print(ANDROID_LOG_DEBUG, GYAI_DEFAULT_LOG_TAG, fmt, ##__VA_ARGS__)
#define GYAI_FUNCTION_NAME __PRETTY_FUNCTION__  // C++宏定义

#else  // else of #ifdef __ANDROID__

#define GYAILogTE(fmt, ...) fprintf(stderr, fmt, ##__VA_ARGS__)
#define GYAILogTI(fmt, ...) fprintf(stdout, fmt, ##__VA_ARGS__)
#if DEBUG
#define GYAILogTD(fmt, ...) fprintf(stdout, fmt, ##__VA_ARGS__)
#else
#define GYAILogTD(fmt, ...)
#endif
#define GYAI_FUNCTION_NAME __FUNCTION__  //

#endif  // end of #ifdef __ANDROID__

#pragma mark - 对外接口Log 带上函数和行号

#define GYAILogE(fmt, ...) \
  GYAILogTE(("%s [%s - %d] " fmt), GYAI_FUNCTION_NAME, __FILE__, __LINE__, ##__VA_ARGS__)
#define GYAILogW(fmt, ...) \
  GYAILogTI(("%s [%s - %d] " fmt), GYAI_FUNCTION_NAME, __FILE__, __LINE__, ##__VA_ARGS__)
#if DEBUG
#define GYAILogD(fmt, ...) \
  GYAILogTD(("%s [%s - %d] " fmt), GYAI_FUNCTION_NAME, __FILE__, __LINE__, ##__VA_ARGS__)
#else
#define GYAILogD(fmt, ...)
#endif

#ifdef GYAILOGPROFILE
#define GYAILogProfile(fmt, ...)                                                      \
  __android_log_print(ANDROID_LOG_ERROR, GYAI_DEFAULT_LOG_TAG, ("%s [%s - %d] " fmt), \
                      __PRETTY_FUNCTION__, __FILE__, __LINE__, ##__VA_ARGS__);
#else
#define GYAILogProfile(fmt, ...)
#endif

#pragma mark - 检测参数 expect

// @brief 判断实例为null或false；则返回error_code。
// 备注：可用于简化很多规范代码行数、圈复杂度；代码看起来简洁。
#define GYAIReturnIfFalse(check_inst, return_false_code) \
  do {                                                   \
    if (!(check_inst)) {                                 \
      return return_false_code;                          \
    }                                                    \
  } while (0)

// @brief 判断实例为null或false；则输出log，返回error_code。
// 备注：可用于简化很多规范代码行数、圈复杂度；代码看起来简洁。
#define GYAIReturnIfFalseLogE(check_inst, return_false_code, error_log, ...) \
  do {                                                                       \
    if (!(check_inst)) {                                                     \
      GYAILogE(error_log, ##__VA_ARGS__);                                    \
      return return_false_code;                                              \
    }                                                                        \
  } while (0)

#define GYAIReturnIfNull(check_inst, error_code) GYAIReturnIfFalse(check_inst, error_code)
#define GYAIReturnIfNullLogE(check_inst, error_code, error_log, ...) \
  GYAIReturnIfFalseLogE(check_inst, error_code, error_log, ##__VA_ARGS__)

#pragma mark - 内存释放

// @brief 判断实例为null或false；则输出log，返回error_code。
#define GYAISafeDeletePtr(ptr) \
  do {                         \
    if ((ptr)) {                 \
      delete (ptr);              \
      (ptr) = nullptr;           \
    }                          \
  } while (0)
