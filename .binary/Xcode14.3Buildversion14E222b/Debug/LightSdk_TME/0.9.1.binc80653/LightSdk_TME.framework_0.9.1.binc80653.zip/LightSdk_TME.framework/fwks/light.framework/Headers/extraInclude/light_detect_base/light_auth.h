//  light_auth.h
//  用于LightSDK的鉴权
//
//  Created by atilazhang on 2021/7/26.
//  Copyright © 2021 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/GYAIBase.h>

GYAILIB_NAMESPACE_START

typedef enum {
  kLightAuthStatusSucceed = 0,
  kLightAuthStatusLicNotExist = -1,
  kLightAuthStatusFail = -2,
  kLightAuthStatusInvalidDate = -3,
  kLightAuthStatusInvalidLic = -4,
  kLightAuthStatusNotAuthed = -1024
} LightAuthStatus;

/**
 * @brief
 * 使用本地license文件鉴权
 * @param license_path 证书绝对路径
 * @param app_id
 * @param bundle_id
 * @return 0 = kLightAuthStatusSucceed；其他为错误码。
 */
LightAuthStatus InitAuth(const char *bundle_id, const char *app_id, const char *license_path);
LightAuthStatus GetAuthStatus();

GYAILIB_NAMESPACE_END
