/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKSegmentation.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKSegmentation : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 暂且是个mask路径，这个需要后面写成通用的资源格式
 */
@property(nonatomic, strong) NSString *maskResource;

/**
 * Comments extracted from cpp files:
 *
 * 裁剪范围[x,y,w,h]
 */
@property(nonatomic, strong) NSArray<NSNumber *> *cutRange;

@property(nonatomic, assign) BOOL strokeEnable;

@property(nonatomic, strong) NSString *strokeColor;

@property(nonatomic, strong) NSString *bgColor;

@property(nonatomic, assign) float strokeWidth;

@property(nonatomic, assign) float strokeGap;

@property(nonatomic, strong) NSString *strokeBorderType;

@property(nonatomic, strong) NSString *renderTarget;

@property(nonatomic, assign) float bgAlpha;

@property(nonatomic, assign) BOOL segmentFollowFace;

@property(nonatomic, strong) NSString *strokeTextureResource;

@property(nonatomic, assign) NSInteger strokeTextureRow;

@property(nonatomic, assign) NSInteger strokeTextureColumn;

@property(nonatomic, assign) NSInteger strokeTextureItemNum;

@property(nonatomic, assign) float strokeSpeedLevel;

@property(nonatomic, assign) BOOL isMaskInvert;

@property(nonatomic, assign) NSInteger strokeItemHeight;

@property(nonatomic, assign) NSInteger strokeItemWidth;

@property(nonatomic, assign) NSInteger strokeItemGap;

@property(nonatomic, assign) NSInteger strokeItemOffset;

@end

NS_ASSUME_NONNULL_END

