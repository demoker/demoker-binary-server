/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKFace3DTrackingComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKFace3DTrackingComponent : LAKComponent

@property(nonatomic, assign) NSInteger faceIndex;

@end

NS_ASSUME_NONNULL_END

