﻿//  GYDetectCommonResult.h
//  GYDetectCommon
//
//  Created by gennyxu on 2020/2/27.
//  Copyright © 2020 Tencent. All rights reserved.
//
#pragma once

// clang-format off
#include <memory>
#include <string>
#include <vector>
#include <light_ai_base/interface/gyai_interface.hpp>
// clang-format on

GYAILIB_NAMESPACE_START

#pragma mark - 结构的定义
/**
 光影检测类型通用原始元素坐标结构: 为了方便后面的追踪、稳定增加。
*/
using GYDetectCommonItemFrame = DetectItemBaseFrame;

#pragma mark - common item

/**
* 光影分类类型通用结构: 分类信息的输入、输出的provider
*/
class GYAI_PUBLIC DetectClassifyProvider {
 public:
  int index = -1;           // 目前性别、年龄、场景、敏感人物用到：分类的int值。
  float confidence = 0.0f;  // 分类可靠度
  std::string name;         // 分类名称（手势、场景等，返回值是字符串）
  std::string type;         // 该分类所属的大类（目前主要场景分类使用）
};
using DetectClassifyResult = DetectClassifyProvider;

/**
光影检测类型通用原始通用结构:
*/
class GYDetectCommonItemParamsHistory;
class GYAI_PUBLIC GYDetectCommonItemParams: public DetectBaseParams {
 public:
  // 目前这种point_x+point_y格式为了目前光影的返回值设计的。
  int pointsCount = 0;  // pointsCount大于0才可以访问point_x、point_y
  std::vector<float> point_x, point_y;  // point的x、y坐标
  std::vector<float> heightMap;         // 点位的height value (存放置信度)
  std::vector<float> eulerAngle;  // pitch yaw roll 角度值（非弧度，主要猫脸使用）

  // 分类也要使用当前结构：因为部分分类需要使用到框位置、点等坐标做参考，所以没有给一个单独结构，而使用通用结构。
  std::string classifyName;         // 分类（目前手势等分类的返回值多是字符串）
  std::string classifyType;         // 该分类所属的大类（目前主要场景分类使用）
  float classifyConfidence = 0.0f;  // 分类可靠度
  int index = -1;                   // 目前性别、场景、敏感人物用到：分类的int值。
  std::shared_ptr<GYDetectCommonItemParamsHistory> history = nullptr;

  std::vector<float> v_visible;
  std::vector<float> v_confidence;
  std::vector<int> v_extInt;
  std::vector<float> v_extFloat;
  std::vector<std::string> v_extString;
};

static inline void DetectClassifyResultAssignFromItem(DetectClassifyProvider *output,
                                                      const GYDetectCommonItemParams &item) {
  output->index = item.index;
  output->confidence = item.classifyConfidence;
  output->name = item.classifyName;
  output->type = item.classifyType;
}

#pragma mark - common result

/**
 光影检测类型通用的返回结构:
 @ imageWidth, imageHeight 为检测图的大小，下方items中所有的元素坐标、大小都是基于该坐标系。
 @ items 是每一个元素的具体属性，如宽高、点位置坐标等。
 */
class GYAI_PUBLIC GYDetectCommonResultStruct: public DetectFeatureProtocol {
 public:
  // 接口扩展：如获取默认BaseFeatureProtocol-feature
  size_t GetFeaturesCount() override { return items.size(); }
  DetectFeatureProtocol *GetFeatureAtIndex(int idx) override { return &items[idx]; }
  size_t GetFeaturePointCount(int idx) override { return items[idx].GetFeaturePointCount(0); }
  GYPoint4fPtr GetFeaturePoint4f(int idx) override { return items[idx].GetFeaturePoint4f(0); }
  GYPoint2fPtr GetFeaturePoint2f(int idx) override { return items[idx].GetFeaturePoint2f(0); }
  GYAIRect4f GetFeatureFrame(int idx) override { return items[idx].GetFeatureFrame(0); }
  GYAISize2f GetFeatureImageSize(int idx) override {
    return GYAISize2fMake(imageWidth, imageHeight);
  }

  DeviceOrientation GetFeatureOrientation(int idx) override { return orientation; }

 public:
  float imageWidth, imageHeight;  // detect image's imageSize
  DeviceOrientation orientation = DeviceOrientationUp;
  std::vector<GYDetectCommonItemParams> items;
};

// #pragma mark - 结构的常用处理

// 对宽高、位置和点进行transform旋转（transform和iOS默认CGAffineTransform结构相似。
// transform=3x2=(a,b,c,d,tx,ty)竖乘，与GYAffineTransform相同，可直接使用其地址（注意和2x3矩阵横乘不同）
void DetectCommonResultApplyTransform(GYDetectCommonResultStruct *pr, const float matrix[3][2]);
void DetectCommonResultApplyTransform(GYDetectCommonResultStruct *pr, const GYAffineTransform &t);
void DetectCommonResultApplyRotation(GYDetectCommonResultStruct *pr, DeviceOrientation ori);
// #pragma mark - 通用结果赋值旋转并存入Map指针 - 内部使用

// 将result根据orientation的反方向进行旋转；并存入Map对应的指针中（内部使用，旋转结果）
// @params result [in-out 非空] 根据 @orientation 的反方向旋转结果
void DetectCommonResultReverseOrientationAndSaveToMap(AIBaseOutputType outputMap,
                                                      GYDetectCommonResultStruct *result,
                                                      DeviceOrientation orientation);

#pragma mark - 参数结构的清理

// 重置参数到默认值：不包括frame
void DetectCommonItemResetToDefaultParamsWithoutFrame(GYDetectCommonItemParams *params);

#pragma mark - 计算 iou
float GYDetectCommonItemFrameIOU(const GYDetectCommonItemParams &params1,
                                 const GYDetectCommonItemParams &params2);

#pragma mark - 计算 distance
float GYDetectCommonItemFrameDistance(const GYDetectCommonItemParams &params1,
                                      const GYDetectCommonItemParams &params2);

GYAILIB_NAMESPACE_END
