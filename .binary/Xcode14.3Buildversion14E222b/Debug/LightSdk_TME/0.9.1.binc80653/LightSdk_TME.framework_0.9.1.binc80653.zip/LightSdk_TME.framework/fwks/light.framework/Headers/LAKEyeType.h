/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKEyeType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKEyeType) {
    LAKEyeTypeLeft = 0,
    LAKEyeTypeRight = 1
};

NS_ASSUME_NONNULL_END

