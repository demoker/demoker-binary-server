/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKTransform.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKPosition.h"
#import "LAKSize.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKTransform : LAKComponent

@property(nonatomic, strong) LAKPosition *anchor;

@property(nonatomic, strong) LAKPosition *position;

@property(nonatomic, strong) LAKSize *size;

@property(nonatomic, assign) float rotation;

@property(nonatomic, assign) BOOL visible;

@end

NS_ASSUME_NONNULL_END

