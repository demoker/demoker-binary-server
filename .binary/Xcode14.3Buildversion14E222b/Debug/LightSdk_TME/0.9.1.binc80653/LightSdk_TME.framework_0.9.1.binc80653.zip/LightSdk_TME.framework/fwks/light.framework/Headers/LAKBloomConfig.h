/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBloomConfig.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKBloomConfig : LAKSerializable

@property(nonatomic, assign) BOOL enable;

/**
 * Comments extracted from cpp files:
 *
 * 0-1
 */
@property(nonatomic, assign) float strength;

/**
 * Comments extracted from cpp files:
 *
 * 3 - 12
 */
@property(nonatomic, assign) float levels;

@property(nonatomic, strong) NSString *bloomColor;

@property(nonatomic, assign) float thresholdValue;

@end

NS_ASSUME_NONNULL_END

