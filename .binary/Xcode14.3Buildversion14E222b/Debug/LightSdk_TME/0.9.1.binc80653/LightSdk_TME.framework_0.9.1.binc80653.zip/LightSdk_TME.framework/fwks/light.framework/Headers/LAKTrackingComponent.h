/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKTrackingComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKTrackingComponent : LAKComponent

@property(nonatomic, strong) NSArray<NSNumber *> *alignPoints;

@property(nonatomic, assign) NSInteger scalePivotPoint1;

@property(nonatomic, assign) NSInteger scalePivotPoint2;

@property(nonatomic, assign) BOOL xAxisTrack;

@property(nonatomic, assign) BOOL yAxisTrack;

@property(nonatomic, assign) BOOL xAxisRotateTrack;

@property(nonatomic, assign) BOOL yAxisRotateTrack;

@property(nonatomic, assign) BOOL zAxisRotateTrack;

@property(nonatomic, assign) BOOL xAxisScale;

@property(nonatomic, assign) BOOL yAxisScale;

@end

NS_ASSUME_NONNULL_END

