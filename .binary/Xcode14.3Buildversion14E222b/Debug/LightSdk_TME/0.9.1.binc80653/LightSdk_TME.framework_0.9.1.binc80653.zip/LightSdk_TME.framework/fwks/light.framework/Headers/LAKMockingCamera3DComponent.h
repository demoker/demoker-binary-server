/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMockingCamera3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKCamera3DFovType.h"
#import "LAKCamera3DProjectionType.h"
#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMockingCamera3DComponent : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * serialization
 */
@property(nonatomic, assign) LAKCamera3DProjectionType projectionType;

@property(nonatomic, assign) float near;

@property(nonatomic, assign) float far;

@property(nonatomic, assign) LAKCamera3DFovType fovType;

@property(nonatomic, assign) float fov;

@property(nonatomic, assign) float orthographicSize;

@end

NS_ASSUME_NONNULL_END

