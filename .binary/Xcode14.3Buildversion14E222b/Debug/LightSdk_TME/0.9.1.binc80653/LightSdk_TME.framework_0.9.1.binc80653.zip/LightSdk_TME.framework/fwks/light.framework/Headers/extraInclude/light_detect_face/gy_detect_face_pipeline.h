﻿//
//  GYFaceDetector.h
//  人脸检测器 —— 计算人脸框
//
// Created by gennyxu on 2020/11/11.
// Copyright © 2020 tencent. All rights reserved.
//

#pragma once

#include <light_detect_base/GYDetectCommon.h>
#include <light_detect_base/gy_reporter_protocol.h>
#include <light_detect_face/FaceDetectorFeature.h>
#include <light_detect_face/YTFaceSDKParam.h>
#include <stdio.h>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

GYAILIB_NAMESPACE_START

class DetectFaceUnit;
class DetectFaceCls;
class DspDelegate;

/* @brief 人脸检测器 —— 计算人脸框
 * */
class FaceUnitPipeline : public GYReporterBase {
 public:
  static constexpr int kSDKVersion = 600;  // 当前sdk的版本号，模型版本需要和该值匹配

 public:
  FaceUnitPipeline();
  ~FaceUnitPipeline();

  // 配置检测模型，生成句柄：成功返回0，否则返回错误码（必须Detect前调用，且调用只有一次）。
  // @params configDir 人脸rootBundleDir + kFaceDetectionVersion [in]
  // @return 返回0-成功；其他-错误码。
  GYAIStatus Setup(const std::string &configDir, const std::string &configName = "config.ini");
  GYAIStatus Cleanup();  // 清理检测句柄，清理后可再次设置。

  // 检测图中的框，返回0标示成功（此时可以获取框，result非空）；否则返回错误码。
  // @params input/inputFmt输入数据和格式，只支持8uc4 rgba/bgra
  // @return 返回0-成功；其他-错误码。
  GYAIStatus Detect(const cv::Mat &input, std::vector<yt_rect> *result,
                    DataFormat inputFormat = DataFormatBGRA_8UC4);

 private:
  // @brief 检测输入的参数是否合法
  bool CheckSetupParams(const AIResourcePathMap &map);

  // 函数功能：DSP初始化。成功则加载DSP功能。失败加载ARM检测（仅切换dsp_mode）
  // 入参：bundle中模型路径（不带模型当前位置）
  // 返回值：0或-1。外部无须判断返回值，失败默认走到ARM模式
  int DspInit(const std::string &rootDir);

  // 函数功能：DSP人脸检测。如果返回失败，外部需要进行失败计数，大于特定次数当前需要切换为ARM模式
  // 入参：输入图像，4通道RGBA
  // 出参：人脸检测框
  // 返回值：0或-1。外部需要判断返回值，并统计失败次数
  int DspFaceDetect(const cv::Mat &rgba, std::vector<DetectItemBaseFrame> *rects);

  // 函数功能：CPU人脸检测。对第一阶段人脸检测封装。
  // 入参：输入图像，4通道RGBA
  // 出参：人脸检测框
  // 返回值：0或-1。
  int CpuFaceDetect(const cv::Mat &rgba, std::vector<DetectItemBaseFrame> *rects);

 private:
  std::unique_ptr<DetectFaceUnit> faceUnit_;
  std::unique_ptr<DetectFaceCls> faceCls_;
#if defined(__ANDROID__) || defined(DSP_DEBUG)
  std::unique_ptr<DspDelegate> dsp_delegate_;
#endif
  std::mutex mutex_;

  // 人脸检测第一阶段执行函数
  // 默认绑定arm cpu版本
  std::function<int(const cv::Mat &, std::vector<DetectItemBaseFrame> *)> face_detect_func_ =
      std::bind(&FaceUnitPipeline::CpuFaceDetect, this, std::placeholders::_1,
                std::placeholders::_2);
  // dsp处理失败次数统计
  uint32_t dsp_failed_times = 0;
};

#pragma mark - rects to rects

static inline void ConvertBaseFramesToYTRects(const std::vector<DetectItemBaseFrame> &rects,
                                              std::vector<yt_rect> *result) {
  for (const auto &rect : rects) {
    yt_rect ytrect;
    ytrect.x = rect.x;
    ytrect.y = rect.y;
    ytrect.width = rect.w;
    ytrect.height = rect.h;
    result->emplace_back(ytrect);
  }
}

GYAILIB_NAMESPACE_END
