//
//  YTTNNFaceSDK.hpp
//  人脸检测
//
//  Created by keyishen on 2020/6/1.
//  Copyright © 2020 com.home.sky. All rights reserved.
//

#pragma once

#include <YTFaceAlignment/yt_face_alignment.h>
#include <light_detect_base/GYDetectCommon.h>
#include <light_detect_base/gy_reporter_protocol.h>
#include <light_detect_face/FaceDetector.h>
#include <light_detect_face/YTFaceSDKParam.h>
#include <map>
#include <memory>
#include <string>
#include <vector>

GYAILIB_NAMESPACE_START

#pragma mark - face detector

class FaceUnitPipeline;
class FaceAlignmenter;
#if !GYAI_FACE_ENABLE_YT_FACE_DETECTOR
using GYFaceDetector = FaceUnitPipeline;
#endif

#pragma mark - face sdk interface

class YTTNNFaceSDK : public AIInterface, public GYReporterBase {
  friend class DetectTask;  // 因task类中会异步调用DoDetect，用友元函数会编译报错，改为友元类。
 public:
  explicit YTTNNFaceSDK(SDKDeviceConfig *config = nullptr);
  ~YTTNNFaceSDK() override;

  // 1、传入模型地址，并构造人脸检测器：必须成功才可以进行后续操作。
  /* @params [in] model.model_path [GYAISpace::kModelRootDirKey] = base_face_res_dir,
   *   1、对应目录下需存在合适版本人脸检测和配准库：eg."face-detection-v600", "face-alignment-v390".
   *   2、也可以单独配置 "face-detector"/"face-alignment"：
   *      { "face-detector", base_face_res_dir + kFaceDetectionVersion },
   *      { "face-alignment", base_face_res_dir + kFaceAlignmentVersion },
   * */
  GYAIStatus SetupWithModel(const SDKModelConfig &model) override;

  // 2、可以根据需要设置部分参数，非空：修改时注意线程，尽量避免频繁修改。
  YTFaceSDKParam *GetSDKParam();
  void ResetSDKParam();

  // 第三步：网络执行（前向操作 —— 内部接口，为了统一封装实现）
  // @params inputMap [in] [kForwardInputKeyImage] = GYImageData* 输入图片，建议bgr格式。
  // @params outputMap的value/output为FaceDetectResult*的封装。
  // @params outputMap [out] 期望结果存放FaceDetectResult的地址指针；key、value参考如下。
  //                   [kForwardOutputKeyDefault] = 存放FaceDetectResult的地址指针。
  // @return 成功返回GYAIErrorCodeSuccess；其他错误码，只成功值结果才有意义。
  GYAIStatus Forward(AIBaseInputType inputMap, AIBaseOutputType outputMap, int option) override;

  // 第三步：网络执行（前向操作 —— 外部接口，相对具体数据类型）
  // @params input [in] 输入的图片 (方向不为Up会旋转输出结果点、框坐标；推荐BGR格式，内部则无需转)
  // @params output [out] 返回结果数据结构的指针。
  // @return 成功返回GYAIErrorCodeSuccess；其他错误码，只成功值结果才有意义。
  GYAIStatus ProcessData(GYImageData *input, FaceDetectResult *output, int option);
  GYAIStatus ProcessData(const cv::Mat &bgra, FaceDetectResult *output, int option);
  GYAIStatus TrackData(const cv::Mat &bgra, const std::vector<yt_rect> &face_rects,
                       FaceDetectResult *output);

  // 4、清理模型：通常结束时候才需要调用；清理后不可再使用。
  GYAIStatus CleanupModelData() override;

  // 清理缓存数据 —— 检测、分割都会缓存平滑数据（根据需要调用，图片批量测试建议经常调用）
  GYAIStatus ClearCachedData() override;

  // Other : 参数设置或者缓存清理等。
  void SetFaceTrackRefineEnable(bool enable);
  bool GetRefineEnable() const { return refine_enable; }

  // @brief 设置/获取最大输出的人脸数量 默认为5 (区间：1~5, 设置下一次检测生效)
  void SetMaxOutputFaceCount(size_t count) { max_output_faces_ = count; }
  size_t GetMaxOutputFaceCount() const { return max_output_faces_; }

  void SetFace3dSmoothStrength(float strength);
  float GetFace3dSmoothStrength() const { return face3d_smooth_strength; }
  GYAIStatus SetBlendShapeNamesEnum(const std::vector<int> &enums);
  GYAIStatus SetBlendShapeNamesStr(const std::vector<std::string> &names);

 private:
  void UpdateLatestTrackInfoByDetectRects(const cv::Mat &mat, const std::vector<yt_rect> &faces);
  void DoAlignment(FaceDetectResult *faces, const yt_image &ytImage, const GYAffineTransform &t);
  void DoDetect(const cv::Mat &bgr_image);
  void DoDetect(const yt_image &ytImg);
  // 根据外部策略执行人脸检测(如每一帧检测、间隔特定帧后进行一次检测、静态图策略等)
  GYAIStatus DoDetectAsyncIfNeeded(const cv::Mat &bgr_image);
  void DoDetectWithSdkParam(const cv::Mat &bgr_image);
  bool CheckFrequencyIfNeedDetect();  // 检测帧数是否达到触发检测的频率（会增加执行的帧数）
  bool CheckUseSysFaceFrames(const FaceDetectResult *result, const cv::Mat &mat,
                             DeviceOrientation prefer_ori);
  GYAIStatus Track3D(std::shared_ptr<FaceAlignmenter> alignmenter, const yt_image &ytImage,
                     std::shared_ptr<FaceDetectorFeature> feature, bool async);

  // 根据当前人脸检测状态返回合适的检测方向：ori为当前设备方向。
  DeviceOrientation GetPreferOrientation(FaceDetectResult *detector);

  bool ResetYTFaceHandle();
  static void printYTFaceAlignmentInfo();
  static void printFace3dmmLibInfo(void *handle);

 private:
  YTFaceSDKParam sdkParam;  // sdk配置参数成员，内部构造，按get->modify路径使用
  std::unique_ptr<GYFaceDetector> faceDetector;  // 人脸检测器：用于检测出框
  std::vector<std::shared_ptr<FaceAlignmenter>> face_alignmenters;  // 当前追踪已有的人脸
  std::mutex face_detecter_mutex_;

  yt_handle alignmentHandle = nullptr;
  void *face3dHandle = nullptr;

  bool is_first_frame = true;
  int process_pass_count = 0;  // 已追踪帧数，控制是否触发检测 (会使用 frequency 取余数)
  int current_detect_frames_frequency = 15;
  int face_id_value = 0;
  bool refine_enable = true;
  std::atomic<size_t> max_output_faces_;  // 最大输出的人脸数量，默认为5 (区间：1~5)

  //  GYFace3DExpressionLevel expression_level = GYFace3DExpressionLv_low;  // 表情基求解级别
  float face3d_smooth_strength = 0.0;  // 3dmm平滑强度，0~10，默认0
  DeviceOrientation last_track_orientation = DeviceOrientationUnknown;  // 当前追踪人脸的方向

  std::unique_ptr<TaskQueue> track3d_queue_;
  std::unique_ptr<TaskQueue> detect_queue_;
};

#pragma mark - 资源定义

// 当前默认的人脸资源路径名称 （会通过该字段拼接默认地址文件夹）

// @brief 根据中台机型档位level_id（高中低等）返回对应configxx.ini名称；找不到返回placeholder。
std::string GetFaceAlignmentConfigName(const std::string &level, const std::string &placeholder);
std::string GetFaceAlignmentConfigName(const std::string &level);  // get config_dense if not found

#pragma mark - image detector & setting

/* @brief 根据device和model_dir创建默认脸检测器：静态图检测设置（返回非空需要手动delete）
 * @params [in] model_dir 是模型文件夹路径，参考model_path[GYAISpace::kModelRootDirKey]。
 * 备注：参考 GYAIFaceSDKParamsApplyStillImageSetting
 * */
YTTNNFaceSDK *CreateStillImageFaceDetecter(const std::string &model_dir);

GYAISPACE_REGISTER_AIMODULE_CREATER_DECLARATION(Face, "Face", YTTNNFaceSDK)

GYAILIB_NAMESPACE_END
