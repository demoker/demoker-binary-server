﻿//
//  DetectBase.h
//  GYDetectCommon
//
//  Created by gennyxu on 2020/3/30.
//  Copyright © 2020 Tencent. All rights reserved.
//
#pragma once

#include <light_ai_base/GYAIBase.h>
#include <light_detect_base/GYDetectHandlerConfig.h>
// clang-format off
#include <algorithm>
#include <string>
#include <vector>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
// clang-format on

GYAILIB_NAMESPACE_START

// 该类为了解耦：方便在RapidLib和TNNLib之间无缝切换（即便将来新增了其他的前向架构也可以通过该层解耦）。
// 1、上层只调用DetectBase，方便封装，实现解耦；上层不用管具体实现事项；
// 2、方便模型和库升级，升级期间可能存在多中不同的前向框架；只要各个前向框架调用类都继承自该类，实现相同接口即可。
class GYAI_PUBLIC DetectBase {
 public:
  DetectBase() = default;
  virtual ~DetectBase() = default;

  // 子类必须实现：需调用文件读取函数或者解密函数(参考几个Private中函数或者方法)。
  virtual GYAIStatus Init(const std::string &proto_path,
                          const std::string &model_path,
                          const std::string &device = "",
                          const std::string &cache_path = "") = 0;

  // 前向网络执行函数（包含前后处理）
  // forward every one / Detect use.
  virtual GYAIStatus Forward(const cv::Mat &input, std::vector<GYDetectCommonItemParams> *output,
                             int maxCount = 0);
  // track/keypoint/classify use.
  virtual GYAIStatus Forward(const cv::Mat &input, GYDetectCommonItemParams *output) = 0;

  // 禁止拷贝: 因为内部为模型、纹理等实例，不能轻易拷贝。
  DetectBase(const DetectBase &) = delete;
  DetectBase &operator=(const DetectBase &) = delete;

 public:
  // 第一个输入、输出的的大小(子类初始化模型Init成功才赋值，此时值才有意义；否则不保证可以使用，可能是0或者未知值)。
  // 如果多输入或者输出，请从模型侧将图片大小控制在第一个输入。（使用前需要确认子类网络初始化时，会对其赋值）
  RapidNetSize mInputSize;   // 第一个输入大小
  RapidNetSize mOutputSize;  // 第一个输出大小
};

#pragma mark - 通用方法，方便子类使用

// @brief  将Rect以中心，上下左右扩张factor为系数的宽高
static inline cv::Rect GYDetectExpendRect(cv::Rect rect, float w, float h, float factorX,
                                          float factorY) {
  float fw = factorX * w, fh = factorY * h;
  rect.x -= fw;
  rect.y -= fh;
  rect.width += fw + fw;
  rect.height += fh + fh;
  return rect;
}

static inline cv::Rect GYDetectExpendRect(cv::Rect rect, float w, float h, float factor) {
  return GYDetectExpendRect(rect, w, h, factor, factor);
}

// @brief 将rect约束到imgW，imgH的边缘范围内
static inline cv::Rect GYDetectInsetRectWithSize(cv::Rect rect, int imgW, int imgH) {
  rect.x = std::max(rect.x, 0);
  rect.y = std::max(rect.y, 0);
  rect.x = std::min(rect.x, imgW);
  rect.y = std::min(rect.y, imgH);
  rect.width = std::min(rect.width, imgW - rect.x);
  rect.height = std::min(rect.height, imgH - rect.y);
  return rect;
}

#pragma mark - 快捷方法

// @brief 根据frame快捷算出裁剪的Rect (追踪、配准都需要使用该方法)
// @params fX / fY 分别为宽高方向上左右、上下需要向外扩展的系数（eg.宽度增加fX*w*2, x-=fX*w）
// @params maxW/maxH计算fX/fY后的最大的宽度和高度，必须大于0。eg.图片的宽高
static inline cv::Rect CVRectFromItemFrame(const GYDetectCommonItemFrame *frame, float fX, float fY,
                                           int maxW, int maxH) {
  cv::Rect rect(frame->x, frame->y, frame->w, frame->h);
  rect = GYDetectExpendRect(rect, rect.width, rect.height, fX, fY);
  rect = GYDetectInsetRectWithSize(rect, maxW, maxH);
  return rect;
}

GYAILIB_NAMESPACE_END
