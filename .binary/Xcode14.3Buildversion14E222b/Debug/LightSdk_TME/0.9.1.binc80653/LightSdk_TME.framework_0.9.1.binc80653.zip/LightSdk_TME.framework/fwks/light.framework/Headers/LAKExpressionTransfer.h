/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKExpressionTransfer.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKExpressionTransfer : LAKComponent

@property(nonatomic, strong) NSString *resourcePath;

@property(nonatomic, strong) NSArray<NSString *> *inputResources;

/**
 * Comments extracted from cpp files:
 *
 * 被驱动类型  1: 内置小图   2: 用户选图（大图）
 */
@property(nonatomic, assign) NSInteger imageType;

/**
 * Comments extracted from cpp files:
 *
 * 内置的小图路径
 */
@property(nonatomic, strong) NSString *originImagePath;

/**
 * Comments extracted from cpp files:
 *
 * 用户选图路径（大图）
 */
@property(nonatomic, strong) NSString *userSelectImagePath;

/**
 * Comments extracted from cpp files:
 *
 * 驱动类型   1: 相机  2: 内置视频
 */
@property(nonatomic, assign) NSInteger driveType;

/**
 * Comments extracted from cpp files:
 *
 * 内置驱动视频路径
 */
@property(nonatomic, strong) NSString *driveVideoPath;

/**
 * Comments extracted from cpp files:
 *
 * 裁剪位置纵坐标
 */
@property(nonatomic, assign) float cropY;

@property(nonatomic, assign) BOOL isEffectEnable;

@end

NS_ASSUME_NONNULL_END

