/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKToneMapping.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKToneMapping) {
    LAKToneMappingLINEAR = 0,
    LAKToneMappingACES_LEGACY = 1,
    LAKToneMappingACES = 2,
    LAKToneMappingFILMIC = 3,
    LAKToneMappingUCHIMURA = 4,
    LAKToneMappingREINHARD = 5,
    LAKToneMappingDISPLAY_RANGE = 6
};

NS_ASSUME_NONNULL_END

