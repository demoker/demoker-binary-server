/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMakeupIrisV6.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKMakeupComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMakeupIrisV6 : LAKMakeupComponent

/**
 * Comments extracted from cpp files:
 *
 * 美瞳图片
 */
@property(nonatomic, strong) NSString *irisImage;

/**
 * Comments extracted from cpp files:
 *
 * 是否处理眼睛镂空区域
 */
@property(nonatomic, strong) NSString *eyeMask;

@property(nonatomic, assign) BOOL enablePreMultiply;

/**
 * Comments extracted from cpp files:
 *
 * 美瞳范围，V6默认值是 0.616 / 2
 */
@property(nonatomic, assign) float multRadius;

@property(nonatomic, assign) BOOL enableRadiusScale;

/**
 * Comments extracted from cpp files:
 *
 * 液化中心相对瞳孔中心的x偏移，跟随瞳孔半径（-1.0 ~ 1.0，大于0则往外，小于0则网内）
 */
@property(nonatomic, assign) float liquifyOffsetX;

/**
 * Comments extracted from cpp files:
 *
 * 液化中心相对瞳孔中心的y偏移，跟随瞳孔半径（-1.0 ~ 1.0，大于0则向下，小于0则向上）
 */
@property(nonatomic, assign) float liquifyOffsetY;

/**
 * Comments extracted from cpp files:
 *
 * 液化强度 0~1
 */
@property(nonatomic, assign) float liquifyStrength;

/**
 * Comments extracted from cpp files:
 *
 * 瞳孔放大倍数
 */
@property(nonatomic, assign) float radiusScale;

/**
 * Comments extracted from cpp files:
 *
 * 瞳孔放大的最大系数，跟随眼睛宽度，即放大后的瞳孔大小不会超过(max_radius_factor_*眼睛宽度)
 */
@property(nonatomic, assign) float maxRadiusFactor;

@end

NS_ASSUME_NONNULL_END

