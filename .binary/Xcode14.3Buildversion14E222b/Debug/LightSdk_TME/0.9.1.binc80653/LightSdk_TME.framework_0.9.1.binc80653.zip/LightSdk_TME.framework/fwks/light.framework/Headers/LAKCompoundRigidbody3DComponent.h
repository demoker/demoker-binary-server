/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKCompoundRigidbody3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKCollisionShapeData.h"
#import "LAKRigidbody3DComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKCompoundRigidbody3DComponent : LAKRigidbody3DComponent

@property(nonatomic, strong) NSArray<LAKCollisionShapeData *> *shape_data_array_;

@end

NS_ASSUME_NONNULL_END

