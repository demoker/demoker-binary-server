/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKHandTracking.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKTrackingComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKHandTracking : LAKTrackingComponent

@property(nonatomic, assign) BOOL isDetectSmooth;

/**
 * Comments extracted from cpp files:
 *
 * 默认都有效
 */
@property(nonatomic, strong) NSArray<NSNumber *> *handIndex;

@end

NS_ASSUME_NONNULL_END

