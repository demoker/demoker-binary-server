/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKAnimoji3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKAnimojiConfig.h"
#import "LAKComponent.h"
#import "LAKEyeSetting.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKAnimoji3DComponent : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * [serialization]
 */
@property(nonatomic, strong) NSString *morphName;

@property(nonatomic, assign) BOOL trackEyeRoll;

@property(nonatomic, assign) NSInteger eyeBoneId;

@property(nonatomic, strong) NSArray<LAKAnimojiConfig *> *animojiConfig;

@property(nonatomic, strong) LAKEyeSetting *eyeSetting;

@end

NS_ASSUME_NONNULL_END

