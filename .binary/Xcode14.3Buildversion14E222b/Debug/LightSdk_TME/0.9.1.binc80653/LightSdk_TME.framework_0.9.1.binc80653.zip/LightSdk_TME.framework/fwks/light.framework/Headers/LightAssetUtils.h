//
//  LightAssetUtils.h
//  light
//
//  Created by llllish on 2022/1/20.
//

#import <Foundation/Foundation.h>
#import "LightAsset.h"

NS_ASSUME_NONNULL_BEGIN

@interface LightAssetUtils : NSObject

+ (NSString *)getAssetJsonString:(LightAsset *)asset;

@end

NS_ASSUME_NONNULL_END
