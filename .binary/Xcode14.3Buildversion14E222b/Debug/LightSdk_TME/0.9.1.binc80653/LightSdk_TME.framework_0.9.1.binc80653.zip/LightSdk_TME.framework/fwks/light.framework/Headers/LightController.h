// Copyright 2020 Tencent Inc. All Rights Reserved.
//  LightController.h
//  light-sdk
//
//  Created by zongyang on 2020/8/15.
//

#ifndef PLATFORM_IOS_LIGHTCONTROLLER_H_
#define PLATFORM_IOS_LIGHTCONTROLLER_H_

#import "Definitions.h"

@class LightWMElement;
@interface LightController : NSObject

/// 重置素材状态
- (void)resetAsset;

/**
 * 素材是否配了特定的美妆类型
 * @param type 美妆类型枚举type
 * @return true 含有，false不含有
 */
- (BOOL)hasSpecMakeUpType:(int)type;

/**
 * Get all the asset data in the template that does not need to be edited by the user
 * @return Key and value of preset data
 */
- (NSDictionary<NSString*, NSString*>*)getAssetData;

/**
 * Set all asset data in the template that does not require user editing
 */
- (void)setAssetData:(NSDictionary<NSString*, NSString*>*)assetData;

/**
 * 设置图片/视频作为模板填充素材, callback里面应该传入一个回调block，用于接收设置的图片是否合规：是否包含敏感人物；是否符满足模板的要求限制
 * bool(^)(NSArray<LightImageFaceDetectResult*>*)) 回调可以传入空，表示不使用LightSDK内部的人脸检测(人脸检测+敏感人物检测)，回调的返回值是表示检测是否通过，参数是检测结果
 * 如果图片检测通过，callback的回调参数里的数组为空；检测不通过，那么图片设置会失败，回调参数里会给与每张图片的检测结果
 */
- (void)setMaterialClipAssets:(NSString*)key clipAssets:(NSArray<LightClipAsset*>*)clipAssets;
- (void)setMaterialClipAssets:(NSString*)key clipAssets:(NSArray<LightClipAsset*>*)clipAssets callback:(void(^)(NSArray<LightImageFaceDetectResult*>*))callback;
/**
 * 返回水印元素
 */
- (NSArray<LightWMElement *> *)getEditableItems;

/**
 * Get rect information of the bounds tracker
 */
- (CGRect)getBoundsByKey:(NSString*)key;

/**
 * Does PAG and filled video contain audio information
 */
- (BOOL)hasAudio;

/**
 * Get all the sound effect IDs used in the template
 */
- (NSArray<NSString*>*)getSoundEffectIDs;

/**
 * Get gbm information in the template
 */
- (NSArray<LightAudioPlaceHolder*>*)getAudioPlaceHolders;

/**
 * Set the audio fill information in the template
 */
- (void)replaceAudioAsset:(LightAudioAsset*)audioAsset forKey:(NSString*)key;

/**
 * Get all the default text information that users in the template can interact with
 */
- (NSArray<LightTextPlaceHolder*>*)getTextPlaceHolders;

/**
 * Set the text information entered by the user
 */
- (void)setTextAsset:(LightTextAsset*)textAsset forKey:(NSString*)key;

/**
 * Get text preset information clicked by user
 */
- (LightTextPlaceHolder*)getEditableTextUnderPoint:(CGPoint)point;

/**
 *  update component to entity by entity id
 *  @param entityId the component binded entityId
 *  @param comonentJson need updated component json str
 */
- (void)updateComponent:(int)entityId componentJson:(NSString*)componentJson;

- (void)addComponent:(int)entityId componentJson:(NSString*)componentJson;

- (void)removeComponent:(int)entityId componentType:(NSString*)componentType;

/**
 *  fetch component by component id
 *  @param componentId component id
 *  @return Json string of the component
 */
- (NSString *)fetchComponent:(int)componentId;

- (void)addEntity:(int)parentId childIndex:(int)childIndex entityJson:(NSString*)entityJson;

- (void)removeEntity:(int)entityId;

/**
 * 设置组件更新回调
 * @param callback
 */
- (void)setComponentUpdateCallback:(void(^)(NSString *))callback;

/**
 * 添加组件更新监控
 * @param componentID
 */
- (void)addComponentUpdateMonitor:(int)componentID;

/**
 * 移除组件更新监控
 * @param componentID
 */
- (void)removeComponentUpdateMonitor:(int)componentID;

/**
 * 添加 inputSource
 * @param jsonString 以 json string 形式存在的 inputSource 数组
 */
- (void)updateResources:(NSString *)jsonString;

/**
 * Get the entityIds clicked by user
 */
- (NSArray<NSNumber*>*)getEntitiesUnderPoint:(CGPoint)point;

/**
 *  Set external audio processors. Used in voice change (uncle, loly, heavy_material) etc.
 *  @param processors the map whose key is a preset type of the processor and value is a block processes a lightAudioFrame
 */
- (void)setExternalAudioProcessors:(NSDictionary<NSString*, id<ExternalAudioProcessor>>*)processors;

@end
#endif
