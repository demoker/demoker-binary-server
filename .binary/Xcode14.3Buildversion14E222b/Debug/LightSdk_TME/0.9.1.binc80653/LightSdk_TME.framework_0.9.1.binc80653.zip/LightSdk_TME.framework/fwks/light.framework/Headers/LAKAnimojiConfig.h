/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKAnimojiConfig.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKAnimojiConfig : LAKSerializable

/**
 * Comments extracted from cpp files:
 *
 * [serialization]
 */
@property(nonatomic, strong) NSString *blendShapeName;

@property(nonatomic, strong) NSString *expressionName;

@end

NS_ASSUME_NONNULL_END

