﻿//
//  GYAIBase.h
//  GYAIBase
//
//  Created by gennyxu on 2020/2/25.
//  Copyright © 2020 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/gyai_macro_t.h>
#include <light_ai_base/base/gyai_error_t.h>
#include <light_ai_base/base/gyai_time_log.h>
#include <light_ai_base/base/gyai_transform_t.h>
#include <light_ai_base/data/gyai_cdata_t.h>
#include <light_ai_base/data/GYDetectCommonResult.h>
#include <light_ai_base/data/GYImageDataMatExtension.h>

#include <light_ai_base/base/gyai_file_extension.hpp>
#include <light_ai_base/data/gyai_data_t.hpp>
#include <light_ai_base/interface/gyai_interface.hpp>
#include <light_ai_base/interface/gyai_interface_feature_t.hpp>
