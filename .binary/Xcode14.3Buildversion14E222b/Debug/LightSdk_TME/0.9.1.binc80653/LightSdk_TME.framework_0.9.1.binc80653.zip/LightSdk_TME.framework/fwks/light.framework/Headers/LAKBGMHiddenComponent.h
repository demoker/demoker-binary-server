/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBGMHiddenComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKBGMHiddenComponent : LAKComponent

@property(nonatomic, assign) BOOL hidden;

@end

NS_ASSUME_NONNULL_END

