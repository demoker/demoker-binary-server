//
//  LightVideoOutput.h
//  light-sdk
//
//  Created by zongyang on 2020/5/25.
//

#import <CoreMedia/CoreMedia.h>

@interface LightVideoOutput : NSObject

- (BOOL)readSampleAtTime:(CMTime)targetTime;
@end
