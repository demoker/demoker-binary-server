/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKPinToMeshComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKPinToMeshComponent : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 需要pin的目标entity id, 该entity应挂载一个mesh component
 */
@property(nonatomic, assign) NSInteger pinToEntityId;

/**
 * Comments extracted from cpp files:
 *
 * 需要pin的mesh位置顶点索引
 */
@property(nonatomic, assign) NSInteger pinPointVertexIndex;

/**
 * Comments extracted from cpp files:
 *
 * 需要pin的mesh的方向顶点索引（方向 = 方向顶点 - 位置顶点)
 */
@property(nonatomic, assign) NSInteger pinDirectionVertexIndex;

/**
 * Comments extracted from cpp files:
 *
 * 另一个辅助点，用于联合另外两个pin点获得平面法线
 */
@property(nonatomic, assign) NSInteger pinTriangleVertexIndex;

@end

NS_ASSUME_NONNULL_END

