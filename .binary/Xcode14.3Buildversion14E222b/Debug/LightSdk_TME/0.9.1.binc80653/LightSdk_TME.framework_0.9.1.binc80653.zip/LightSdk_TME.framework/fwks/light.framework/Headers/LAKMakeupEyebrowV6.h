/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMakeupEyebrowV6.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKMakeupComponent.h"
#import "LAKRect.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMakeupEyebrowV6 : LAKMakeupComponent

/**
 * Comments extracted from cpp files:
 *
 * 眉毛图片
 */
@property(nonatomic, strong) NSString *eyebrowImageName;

/**
 * Comments extracted from cpp files:
 *
 * 最终使用的裁切素材
 */
@property(nonatomic, strong) NSString *eyebrowCropImageName;

/**
 * Comments extracted from cpp files:
 *
 * 眉毛裁剪区域（基于标准人脸点位图）
 */
@property(nonatomic, strong) LAKRect *cropRect;

@end

NS_ASSUME_NONNULL_END

