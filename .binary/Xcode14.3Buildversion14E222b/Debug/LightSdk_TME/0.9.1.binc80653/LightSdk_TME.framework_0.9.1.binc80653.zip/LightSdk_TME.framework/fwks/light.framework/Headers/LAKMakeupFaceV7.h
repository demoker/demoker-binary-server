/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMakeupFaceV7.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKMakeupComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMakeupFaceV7 : LAKMakeupComponent

@property(nonatomic, assign) NSInteger useless_for_macro;

@end

NS_ASSUME_NONNULL_END

