/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKPhysicsWorld3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKVec3.h"
#import "LAKfDrawFlags.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKPhysicsWorld3DComponent : LAKComponent

@property(nonatomic, strong) LAKVec3 *gravity_;

@property(nonatomic, assign) BOOL detailed_configuration_enabled_;

@property(nonatomic, assign) float physics_simulation_speed_;

@property(nonatomic, assign) NSInteger internal_sub_step_;

@property(nonatomic, assign) BOOL debug_draw_enabled_;

@property(nonatomic, assign) NSInteger physics_world_debug_draw_mode_;

@property(nonatomic, assign) LAKfDrawFlags soft_body_debug_draw_flag_;

@end

NS_ASSUME_NONNULL_END

