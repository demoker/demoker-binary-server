/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMakeupFaceV6.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKMakeupComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMakeupFaceV6 : LAKMakeupComponent

/**
 * Comments extracted from cpp files:
 *
 * 是否裁切边缘
 */
@property(nonatomic, assign) BOOL faceExchangeImageDisableFaceCrop;

/**
 * Comments extracted from cpp files:
 *
 * 打开侧脸点位Opacity，仅在faceExchangeImageDisableFaceCrop为1的时候生效
 * 默认0, 代表禁止裁切边缘的时候, 所有的点opacity都认为是1
 * 打开1, 代表禁止裁切边缘的时候, 依然需要计算所有的点的opacity
 * 如果开启边缘裁切, 则任何情况都会计算opacity
 */
@property(nonatomic, assign) BOOL faceExchangeImageEnableOpacity;

@end

NS_ASSUME_NONNULL_END

