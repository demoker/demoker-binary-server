﻿//  gyai_transform_t.h
//  矩阵和方向相关的代码计算
//
//  Created by gennyxu on 2020/11/17.
//  Copyright © 2020 Tencent. All rights reserved.
//

#pragma once

#include <stdio.h>
#include <light_ai_base/data/gyai_data_t.hpp>

GYAILIB_NAMESPACE_START

// 矩阵：对应方向使用，用于旋转点和参数。
class GYAI_PUBLIC GYAffineTransform {
 public:
  GYAffineTransform();  // 默认生成标准矩阵
  GYAffineTransform(float a, float b, float c, float d, float tx, float ty);
  bool IsIdentitiy() const;

  // 当前矩阵的行，乘以t的列：输出结果矩阵。
  GYAffineTransform mul(const GYAffineTransform &t) const;
  GYAffineTransform inverse() const;

 public:
  union {
    struct {
      float a, b;
      float c, d;
      float tx, ty;
    };
    float t32[3][2];  /// 和data[6]\abcd和tx\ty共享6个float变量，为了解析方便
    float data[6];    /// 和t32\abcd和tx\ty共享6个float变量，为了解析方便
  };
};

#pragma mark - 点位旋转

// @brief 根据矩阵旋转坐标点
static inline GYAIPoint2f GYAIPointApplyTransform(const float point[2], const float t[3][2]) {
  GYAIPoint2f p;
  p.x = point[0] * t[0][0] + point[1] * t[1][0] + t[2][0];
  p.y = point[0] * t[0][1] + point[1] * t[1][1] + t[2][1];
  return p;
}

static inline void GYAIPointApplyTransformAndSave(const float point[2], const float t[3][2],
                                                  float result[2]) {
  auto x = point[0], y = point[1];
  result[0] = x * t[0][0] + y * t[1][0] + t[2][0];
  result[1] = x * t[0][1] + y * t[1][1] + t[2][1];
}

// 下方改为内联，为了提升速度：有大量列表会遍历每一个点用到。
static inline GYAIPoint2f GYAIPointApplyTransform(GYAIPoint2f p, const GYAffineTransform &t) {
  return GYAIPointApplyTransform(p.data, t.t32);
}

static inline GYAIPoint2f GYAIPointApplyTransform(const float p[2], const GYAffineTransform &t) {
  return GYAIPointApplyTransform(p, t.t32);
}

static inline GYAIPoint2f GYAIPointApplyTransform(GYAIPoint2f p, const float t[3][2]) {
  return GYAIPointApplyTransform(p.data, t);
}

#pragma mark - 框和大小旋转

GYAI_PUBLIC GYAIRect4f GYAIRect4fApplyTransform(GYAIRect4f rect, const GYAffineTransform &t);
GYAI_PUBLIC GYAIRect4f GYAIRect4fApplyTransform(GYAIRect4f rect, const float t[3][2]);

// 快捷方法：结果存放到输入中 (输入非空)：1、宽、高进行矩阵；2、点位列表进行矩阵操作。
GYAI_PUBLIC void GYAISize2fApplyTransform(float *pw, float *ph, const float t[3][2]);
static inline void GYAISize2fApplyTransform(float *pw, float *ph, const GYAffineTransform &t) {
  GYAISize2fApplyTransform(pw, ph, t.t32);
}

#pragma mark - 批量点位旋转快捷方法

// @brief 输入point和点count数，执行t矩阵旋转后，存入result(可与point相同)。
void GYAIPointsApplyTransform(const float point[][2], size_t count, const float t[3][2],
                              float result[][2]);
void GYAIPointsApplyTransform(float point[][2], size_t count, const GYAffineTransform &t);
void GYAIPointsApplyTransform(float point[][2], size_t count, const float t[3][2]);

#pragma mark - 此为人脸对方向进行校正的函数
// @brief 计算旋转方向后图像的orientation，计算转正需要使用的方向。
DeviceOrientation ComputeReverseOrientation(DeviceOrientation ori);
// @brief 根据方向计算旋转角度：主要分割在使用。
float ComputeAngle(DeviceOrientation ori);

// @brief 根据方向计算矩阵：最早人脸使用，目前其他模块也在使用 (函数名称历史原因暂不修改)
// @params w/h 为当前图片宽、高，矩阵平移参数使用到（如果给OpenCV Mat旋转使用可能需减1）
GYAffineTransform ComputeFaceTransform(DeviceOrientation ori, float w, float h, bool flip = false);

// @brief 通过欧拉角 euler[in]，计算矫正roll后欧拉角，存入result（猫脸也可用，新欧拉角roll值为0）
// @params euler [in] 输入与坐标系有关的欧拉角（矫正结果与坐标系无关，可用于判断点头、摇头等）
// @params degree 标示结果是以度数还是弧度显示，默认度数返回。（备注：euler输入必须是弧度）
void GYAICorrectEulerToRollBackCoords(const float euler[3], float result[3], bool degree = true);

GYAILIB_NAMESPACE_END
