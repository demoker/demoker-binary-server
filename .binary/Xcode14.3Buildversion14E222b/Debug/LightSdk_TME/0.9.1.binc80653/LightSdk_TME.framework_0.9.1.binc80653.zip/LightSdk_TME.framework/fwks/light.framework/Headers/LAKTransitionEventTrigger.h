/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKTransitionEventTrigger.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKEventTrigger.h"
#import "LAKTransitionEventInfos.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKTransitionEventTrigger : LAKEventTrigger

/**
 * Comments extracted from cpp files:
 *
 * 转场触发选择的转场信息(selectionID、时间偏移、触发类型)集合数组
 */
@property(nonatomic, strong) NSArray<LAKTransitionEventInfos *> *transitionEventInfos;

@end

NS_ASSUME_NONNULL_END

