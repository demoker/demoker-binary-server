/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKClusterColor.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKColorItem.h"
#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKClusterColor : LAKComponent

@property(nonatomic, strong) NSString *colorRenderTargetID;

@property(nonatomic, assign) NSInteger colorNum;

@property(nonatomic, assign) NSInteger clusterColorNum;

@property(nonatomic, assign) BOOL colorReady;

@property(nonatomic, strong) NSArray<LAKColorItem *> *colorArray;

@property(nonatomic, assign) BOOL isSync;

@end

NS_ASSUME_NONNULL_END

