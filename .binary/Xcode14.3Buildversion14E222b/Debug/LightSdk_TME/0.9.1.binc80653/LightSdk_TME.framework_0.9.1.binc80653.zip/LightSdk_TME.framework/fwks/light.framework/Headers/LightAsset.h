//
//  LightAsset.h
//  light-sdk
//
//  Created by zongyang on 2020/8/15.
//

#import "Definitions.h"
#import "LightConstants.h"

@interface LightAsset : NSObject

/*
 * 通过jsonPath得到一个Asset
 * @param templatePath template.json 的文件路径
 * @param randomSeed
 * @param errorCode 错误码，当errorCode == 0时，表明初始化成功, > 0 则表示初始化失败
 * @return LightAsset, 需要配合errorCode配合判断初始化是否成功
 */
+ (instancetype)Load:(NSString*)templatePath randomSeed:(int)randomSeed errorCode:(int*)errorCode;

/*
 *通过一个jsonStr 得到一个Asset
 * @param templatePath 这里是模板的父路径，用于模板资源的寻找
 * @param  templateContent template.json 的字符串
 * @param randomSeed
 * @param errorCode 错误码，当errorCode == 0时，表明初始化成功, > 0 则表示初始化失败
 * @return LightAsset, 需要配合errorCode配合判断初始化是否成功
 */
+ (instancetype)LoadFromString:(NSString*)templatePath templateContent:(NSString*)templateContent randomSeed:(int)randomSeed errorCode:(int*)errorCode;


- (BOOL)needRenderAbility:(LightAssetFeatureKey)key;

/*
 * 获取render所需的AI能力对应的bundle类型
 * 比如 {"FACE_AGENT", "GENDER_AGENT"}
 */
- (NSArray<NSString*>*)getRenderAgentTypes;

/*
 * 获取render所需的AI能力对应的 AgentBundleInfo
 */
- (NSArray<LightAgentBundleInfo*>*)getRenderAgentBundleInfos;

/*
 * 获取render所需的AI能力对应的 AgentBundleInfo，包含查询 LightCV 的过程
 */
- (NSArray<LightAgentBundleInfo*>*)getRenderAgentBundleInfosWithCV;

/**
 * Get template width
 */
- (NSInteger)width;

/**
 * Get template height
 */
- (NSInteger)height;

- (NSArray<NSString*>*)getBgmMusicIDs;

/**
 * Get all fontAssets used in the template
 * @return fontAsset Array
 */
- (NSArray<LightFontAsset*>*)getFontAssets;

/**
 * Get all the BoundsTracker related informations in the template
 */
- (NSArray<NSString*>*)getBoundsTrackerPlaceHolders;

/**
 * Get information about template configuration
 */
- (LightMovieConfig*)getMovieConfig;

/**
 * Get information about material configuration
 */
- (NSArray<LightMaterialConfig*>*)getMaterialConfigs;

/**
 * 检查素材中是否有LUT（只检测配置在素材中的）
 */
- (BOOL)hasLUT;

/**
 * 检查素材中配置有液化或者五官形变（只检测配置在素材中的）
 */
- (BOOL)hasMesh;

/**
 * 检查素材中是否配置有美妆（只检测配置在素材中的）
 */
- (BOOL)hasMakeup;
- (BOOL)hasFactorMakeup;


- (BOOL)forbiddenBasicMakeup;

- (BOOL)forbiddenBasicNonReshapeBeauty;

- (BOOL)forbiddenBasicReshape;

- (BOOL)forbiddenBasicSmooth;

/**
 * 是否需要Reset
 */
- (BOOL)needResetAssetWhenStartRecord;

/**
 * 获取变声 voiceKind 参数
 * 默认值为 -1，代表无效果
 */
- (int)voiceKind;

/**
 * 获取变声 environment 参数
 * 默认值为 -1，代表无效果
 */
- (int)voiceEnvironment;

/**
 * 相机前后置状态
 *
 * @return 默认相机位置 0: 不做切换 1: 前置相机 2: 后置相机
 */
- (int)defaultCameraPosition;

/**
 * 相机支持位置
 * @return LightCameraSupportType
 *    LightCameraSupport_Front_Back = 0; 前后置支持
 *    LightCameraSupport_Front = 1; 仅支持前置
 *    LightCameraSupport_Back = 2; 仅支持后置
 *    默认返回LightCameraSupport_Front_Back
 */
- (LightCameraSupportType)supportCameraPosition;

/**
 * Get the LUT filter in the template
 */
- (NSArray<LightLUTPlaceHolder*>*)getLUTPlaceHolders;

/**
 * 获取素材根目录
 */
- (NSString *)getTemplateDir;

@end



@interface LightAsset (Util)

/**
 * 判断是否素材需要重力信息
 */
- (BOOL)needGravityInfo;

/**
 * 判断是否素材需要分贝信息
 */
- (BOOL)needVoiceDecibel;

/**
 * 判断是否是水印素材
 */
- (BOOL)isWatermarkMaterial;

/**
 * 判断是否是可编辑水印素材
 */
- (BOOL)isEditableWatermarkMaterial;

/**
 * Is the sticker need  response touch
 */
- (BOOL)stickerNeedTouchTriggerEvent;

/**
 * Is the sticker need  response paint
 */
- (BOOL)stickerNeedPaintTriggerEvent;
/**
 * Is the sticker need  mask record touch
 */
- (BOOL)stickerNeedMaskRecordTouchPoint;

/**
 * 检查素材中是否有AudioSource
 */
- (BOOL)hasAudioSource;

/**
 * 修改MultiMedia.size
 */
- (void)setRenderMediaSize:(int)width height:(int)height;

@end
