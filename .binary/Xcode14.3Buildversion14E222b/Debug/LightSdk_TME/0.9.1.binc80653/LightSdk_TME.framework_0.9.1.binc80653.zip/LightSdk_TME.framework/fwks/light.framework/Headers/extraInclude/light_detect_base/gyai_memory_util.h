//
//  gyai_memory_util.h
//  获取当前内存
//
//  Created by gennyxu on 2022/4/124.
//  Copyright © 2022 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/GYAIBase.h>

#define GYAI_AVIABLE_MEM_SIZE_MIN 50  // 最低内存需要为100MB

GYAILIB_NAMESPACE_START
namespace memory {
#if __APPLE__

/// @brief 获取剩余物理内存 (取整MB, 非/1024.0/1024.0)
/// @params thresold_mem_debug_log 剩余内存小于该值，打印警告日志（单位MB）
uint64 GetFreeMBytes(uint64 thresold_mem_debug_log = GYAI_AVIABLE_MEM_SIZE_MIN);
uint64 GetFreeBytes();  /// 返回字节数

/// @brief 当前进程可用的内存（OS13以后支持才比较好，建议使用 GetFreeBytes 取小值）
/// @return 返回进程可用字节数（可能返回0）
uint64 GetProcessAviableBytes();

/// @brief 获取脏数据大小
uint64 GetDirtyVMBytes();

/// @brief 获取task使用的memory
uint64 GetUsedBytes();
uint64 GetInternalVMBytes();

#endif  // end of #if __APPLE__
}  // end of namespace memory
GYAILIB_NAMESPACE_END

/// @brief 当内存大小不满足最小条件，不初始化（使用宏为了方便将其他平台隔离开）。
#if __APPLE__
#define GYAIMemoryCheckAviableSize(thresoldMB) GYAISpace::memory::GetFreeMBytes(thresoldMB)
#define GYAIMemoryCheckAviableSizeDefault() GYAIMemoryCheckAviableSize(GYAI_AVIABLE_MEM_SIZE_MIN)
#define GYAIReturnCheckAviableMemorySize()                                \
  do {                                                                    \
    if (GYAISpace::memory::GetFreeMBytes() < GYAI_AVIABLE_MEM_SIZE_MIN) { \
      return GYAIErrorCodeMallocMemFail;                                  \
    }                                                                     \
  } while (0)
#else
#define GYAIMemoryCheckAviableSize(thresoldMB) do {} while (0)
#define GYAIMemoryCheckAviableSizeDefault() GYAIMemoryCheckAviableSize(GYAI_AVIABLE_MEM_SIZE_MIN)
#define GYAIReturnCheckAviableMemorySize() do {} while (0)
#endif
