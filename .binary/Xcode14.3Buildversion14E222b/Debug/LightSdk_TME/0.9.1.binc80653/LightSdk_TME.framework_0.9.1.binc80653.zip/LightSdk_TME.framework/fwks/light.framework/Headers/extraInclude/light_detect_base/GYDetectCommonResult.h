﻿//  GYDetectCommonResult.h
//  GYDetectCommon
//
//  Created by gennyxu on 2020/2/27.
//  Copyright © 2020 Tencent. All rights reserved.
//
#pragma once

#include <light_ai_base/data/GYDetectCommonResult.h>
