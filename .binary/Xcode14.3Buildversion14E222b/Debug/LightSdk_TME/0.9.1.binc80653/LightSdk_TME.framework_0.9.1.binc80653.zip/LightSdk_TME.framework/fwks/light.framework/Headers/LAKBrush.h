/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBrush.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKBrushRenderType.h"
#import "LAKBrushTriggerType.h"
#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKBrush : LAKComponent

@property(nonatomic, strong) NSString *brushColor;

@property(nonatomic, assign) NSInteger brushSize;

@property(nonatomic, strong) NSString *renderTarget;

@property(nonatomic, assign) LAKBrushTriggerType triggerType;

@property(nonatomic, assign) LAKBrushRenderType renderType;

@property(nonatomic, strong) NSArray<NSString *> *brushImages;

@end

NS_ASSUME_NONNULL_END

