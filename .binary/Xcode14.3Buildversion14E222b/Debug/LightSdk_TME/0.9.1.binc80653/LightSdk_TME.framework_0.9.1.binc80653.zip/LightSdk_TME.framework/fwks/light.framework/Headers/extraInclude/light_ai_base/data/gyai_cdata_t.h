﻿//  gyai_data_t.hpp
//  GYAIBase
//
//  Created by gennyxu on 2020/6/6.
//  Copyright © 2020 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/base/gyai_error_t.h>
#include <stdio.h>

#define GYAI_ATTR_STRUCT_PACK4 GYAI_ATTR_ALIGNED(4)

// clang-format off
#ifdef __cplusplus
extern "C" {
#endif

// 指向点坐标(二维)的指针:
// 通常用于返回指针，指向的是结构、类内部二维点坐标（数组）；结构释放后不可使用。
typedef float (*GYPoint2fPtr)[2];
typedef union GYAI_ATTR_STRUCT_PACK4 GYAIPoint2f {
  struct { float x, y; };
  struct { float w, h; };  // 参考：GYAISize2f，为了大小而增加
  float data[2];  // 方便从列表中根据位置解析使用，无需根据位置写死是x\y
} GYAIPoint2f;

static inline GYAIPoint2f GYAIPoint2fMake(float x, float y) {
  GYAIPoint2f p = { { x, y, }, }; return p;  // NOLINT
}

// 将相同的结构定义为2f点，方便参数切换以及后续列表和解析管理（无需解析两个结构）。
typedef GYAIPoint2f GYAISize2f;
static inline GYAISize2f GYAISize2fMake(float w, float h) {
  return GYAIPoint2fMake(w, h);
}

// 指向点坐标(三维)的指针:
// 通常用于返回指针，指向的是结构、类内部三维点坐标（数组）；结构释放后不可使用。
typedef float (*GYPoint3fPtr)[3];
typedef union GYAI_ATTR_STRUCT_PACK4 GYAIPoint3f {
  struct { float x, y, z; };
  float data[3];  // 方便从列表中根据位置解析使用，无需根据位置写死是x\y\z
} GYAIPoint3f;

static inline GYAIPoint3f GYAIPoint3fMake(float x, float y, float z) {
  GYAIPoint3f p = { { x, y, z, }, }; return p;  // NOLINT
}

// 指向点坐标(四维)的指针:
// 将相同的结构定义为4f点，方便GYAIRect4f和GYAIPoint4f内部随意切换。
typedef union GYAI_ATTR_STRUCT_PACK4 GYAIPoint4f {
  struct { float x, y, z, w; };
  float data[4];  // 方便从列表中根据位置解析使用，无需根据位置写死是w\h
} GYAIPoint4f;

static inline GYAIPoint4f GYAIPoint4fMake(float x, float y, float z, float w) {
  GYAIPoint4f p = { { x, y, z, w, }, }; return p;  // NOLINT
}

// 通常用于返回指针，指向的是结构、类内部四维点坐标（数组）；结构释放后不可使用。
typedef float (*GYPoint4fPtr)[4];
typedef union GYAI_ATTR_STRUCT_PACK4 GYAIRect4f {
  struct { float x, y, w, h; };
  float data[4];  // 方便从列表中根据位置解析使用，无需根据位置写死是w\h
} GYAIRect4f;

static inline GYAIRect4f GYAIRect4fMake(float x, float y, float w, float h) {
  GYAIRect4f rect = { { x, y, w, h, }, }; return rect;  // NOLINT
}

#ifdef __cplusplus
}  // end of extern "C"
#endif
// clang-format on

#undef GYAI_ATTR_STRUCT_PACK4  // 取消定义，防止后续影响
