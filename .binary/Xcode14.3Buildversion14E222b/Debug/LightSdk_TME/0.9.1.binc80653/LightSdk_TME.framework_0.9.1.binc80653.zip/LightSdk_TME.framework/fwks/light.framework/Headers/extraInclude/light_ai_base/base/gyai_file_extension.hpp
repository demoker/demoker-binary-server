﻿//
//  gyai_file_extension.hpp
//  文件路径操作相关的方法
//
// Created by gennyxu on 2020/9/22.
// Copyright © 2020 tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/data/gyai_data_base.h>
#include <sys/types.h>
#include <string>

GYAILIB_NAMESPACE_START

#pragma mark - 文件常量定义

#ifdef WIN32
#define KLINE_SEP_CHAR '\r\n'
#define KLINE_SEP_STR  "\r\n"
static constexpr char kFileSep[] = "\\";
#else
#define KLINE_SEP_CHAR '\n'
#define KLINE_SEP_STR  "\n"
static constexpr char kFileSep[] = "/";
#endif

#pragma mark - 文件后缀判定和删除

// 通常用于判断文件路径是否有指定的后缀
static inline bool StringHasEnding(const std::string &prefer, const std::string &ending) {
  if (prefer.length() < ending.length()) {
    return false;
  }
  return 0 == prefer.compare(prefer.length() - ending.length(), ending.length(), ending);
}

// 通常用于判断文件路径是否有指定的后缀
static inline std::string StringDeleteEnding(const std::string &prefer, const std::string &ending) {
  return StringHasEnding(prefer, ending) ? prefer.substr(0, prefer.size()- ending.size()) : prefer;
}

// 获取文件路径的后缀
static inline std::string GetFilePathExtension(const std::string &prefer) {
  // 增加越界判断：如"../xx"， 防止"."出现位置比"/"还小，此时需要为返回空
  auto last_point = prefer.find_last_of('.');
  if (last_point >= prefer.length()) {
    return "";
  }
  auto last_sep = prefer.find_last_of(kFileSep);
  last_sep = last_sep < prefer.length() ? last_sep : 0;
  return last_point > last_sep ? prefer.substr(prefer.find_last_of('.') + 1) : "";
}

// 删除文件路径的后缀
static inline std::string StringByDeletePathExtension(const std::string &prefer) {
  // 增加越界判断：如"../xx"， 防止"."出现位置比"/"还小，此时需要为返回空
  auto last_point = prefer.find_last_of('.');
  if (last_point >= prefer.length()) {
    return prefer;
  }
  auto last_sep = prefer.find_last_of(kFileSep);
  last_sep = last_sep < prefer.length() ? last_sep : 0;
  return last_point > last_sep ? prefer.substr(0, last_point) : prefer;
}

#pragma mark - 算路径

// 通常用于判断文件路径是否有指定的后缀
static inline std::string StringPathAddLastFileSep(const std::string &dir) {
  auto dir_had_sep = GYAISpace::StringHasEnding(dir, kFileSep);
  return dir_had_sep ? dir : dir + kFileSep;
}

// 获取文件路径的最后一个文件或者文件夹元素
GYAI_PUBLIC std::string GetFilePathLastCompoment(const std::string &prefer);

// @brief 删除文件路径的最后一个合法文件元素（点、空格都是合法；末尾多个文件分隔符都会被删除）
// @params suffixSep [in] 删除最后一个元素后，返回的结果末尾：是否留下文件分隔符（默认false）
GYAI_PUBLIC std::string StringByDeleteLastPathCompoment(const std::string &prefer, bool suffixSep);
GYAI_PUBLIC std::string StringByDeleteLastPathCompoment(const std::string &prefer);

// @brief 将文件路径dir、comp 拼接成一个路径（会自动检测并在二者中间加入分隔符）
// @params comp 为该路径下的中间文件夹：如测试模块的名称 (会判断文件后缀)
GYAI_PUBLIC std::string StringPathAddComponent(const std::string &dir, const std::string &comp);

GYAILIB_NAMESPACE_END
