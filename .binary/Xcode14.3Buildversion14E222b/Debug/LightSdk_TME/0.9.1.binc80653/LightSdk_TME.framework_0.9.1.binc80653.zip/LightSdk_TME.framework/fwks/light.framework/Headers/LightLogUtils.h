//
//  LightLogUtils.h
//  light
//
//  Created by ashli on 2020/11/4.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// 对应light.h中的typedef enum LogPriority
typedef NS_ENUM(NSUInteger, LightLogLevel) {
    LightLogLevelUnknown = 0,
    LightLogLevelDefault,
    LightLogLevelVerbose,
    LightLogLevelDebug,
    LightLogLevelInfo,
    LightLogLevelWarn,
    LightLogLevelError,
    LightLogLevelFatal
};

@protocol LightLoggerProtocol <NSObject>

- (void)log:(LightLogLevel)level tag:(NSString *)tag msg:(NSString *)msg;

@end

@interface LightLogUtils : NSObject

+ (void)initLogger:(id<LightLoggerProtocol>)logger;

+ (void)setMinPriority:(LightLogLevel)level;

@end

NS_ASSUME_NONNULL_END
