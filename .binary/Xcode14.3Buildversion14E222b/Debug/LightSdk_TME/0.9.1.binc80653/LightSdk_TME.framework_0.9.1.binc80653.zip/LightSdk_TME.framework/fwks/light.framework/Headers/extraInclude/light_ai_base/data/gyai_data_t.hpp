﻿//
//  gyai_data_t.hpp
//  GYAIBase
//
//  Created by gennyxu on 2020/6/6.
//  Copyright © 2020 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/data/gyai_data_base.h>
#include <stdio.h>
#include <map>
#include <memory>
#include <string>

GYAILIB_NAMESPACE_START

#pragma mark - data type / format

typedef void *GYAIGLTexure;
// 用于区别数据类型：默认是Image，输入是图片数据（其他为扩展，用于参数、数据传递：需对应模块支持）
typedef enum {
  GYDataTypeImage,    // Default. Metal=MTLTexture; OpenCL=ImageBytes; CPU/ARM=ImageBytes
  GYDataTypeBuffer,   // Metal=MTLBuffer; Android=ParamsBytes; CPU/ARM=ParamsBytes
  GYDataTypeTNNBlob,  // Metal=BlobBuffer=MTLBuffer; Android=Blob-Bytes;
  GYDataTypeCPUData,  // 单纯的CPU图片数据，默认RGBAU8C4。eg: cv::Mat.data (GAN 单输入已支持)。
  GYDataTypeGLTex,    // android gl texture 输入
} GYDataType;

// 数据格式（格式为0xABC三位：A为单channel字节数；B为channel数；C为区分位，因AB会重复)
typedef enum {
  DataFormatRGBA_8UC4 = 0x140,
  DataFormatBGRA_8UC4 = 0x141,
  DataFormatRGB_8UC3  = 0x130,
  DataFormatBGR_8UC3  = 0x131,
  DataFormatGray_8UC1 = 0x110,
  DataFormatDepth_16UC1 = 0x210,
} DataFormat;

#pragma mark - GYImageData

class GYImageData;  // 前置声明，为callback使用
typedef void (*GYImageDataCallBack)(GYImageData *image);
class GYAI_PUBLIC GYImageData : public BaseData {
 public:
  GYImageData() { cls_type_ = BaseDataClassTypeImage; }
  ~GYImageData() override { if (deallocCallBack != nullptr) deallocCallBack(this); }

  /* @brief 用于指向具体的数据：通常是\OpenCLARM\CPU=内存data、Metal=id<MTLTexture>。
   * 要保证data在使用结束前不可以被释放（如有释放需求，可以设置deallocCallBack来实现）。
   * 备注：Objc为了防止ARC，使用 __autoreleasing id<MTLTexture> texture = Create2DTexture();
   * xxx.data = (__bridge void *)(texture);  // 加入auto releaseing pool，当前runloop有效。
   * */
  void *data = nullptr;  // 数据（各个平台接口，有各自的数据类型）
  DataFormat format = DataFormatRGBA_8UC4;
  int width = 0, height = 0;
  int channel = 4;
  int bytesPerRow = 0;  // 默认是0，无需填写，除非数据有特殊长度对齐
  GYDataType dataType = GYDataTypeImage;  // 需模块支持：目前只有GAN
  size_t dataOffset = 0;  // 数据所在偏移（不同模块可能未实现，建议传入实际偏移的地址）
  DeviceOrientation orientation = DeviceOrientationUp;  // Image方向，用于控制检测结果旋转。
  GYImageDataCallBack deallocCallBack = nullptr;
  void *context = nullptr;  // 用户自定义，可给deallocCallBack使用：可用于记录释放的源对象
};

#pragma mark - 析构delete的callback

// 加上inline，此处因为会用函数指针，不会真的内联（不加inline会可能会有部分编译器无法编译）
static inline void GYImageDataCallBackFreeData(GYImageData *image) {
  if (image && image->data) {
    free(image->data);
    image->data = nullptr;
  }
}

#pragma mark - DataFormat Extension

// 计算该格式单个像素的字节数（该像素的channel数 x 单channel字节数）
GYAI_PUBLIC int GYGetBytesPerPixelFromDataFormat(DataFormat format);
GYAI_PUBLIC int GYGetChanelsFromDataFormat(DataFormat format);
GYAI_PUBLIC int GYGetBytesPerChannelFromDataFormat(DataFormat format);

#pragma mark - Image Data Create

/* @brief 根据数据创建输入输出的通用结构（返回结果 dataType=GYDataTypeImage——为图片、纹理内存）。
 * @params data 输入的数据：可以为自定义地址、cv::Mat.data等
 * @params format 图片纹理的数据排版的格式（默认其channel也会根据该字段计算）
 * @params w\h 图片纹理的宽高
 * @params bytesPerRow 默认为0，根据fromat生成的channel和w计算 (设置后将使用传入的值，不校验)
 */
GYImageData GYImageDataCreate(void *data, DataFormat format, int w, int h, int bytesPerRow = 0);
GYImageData GYImageDataCreate(uint8_t *data, DataFormat format, int w, int h, int bytesPerRow = 0);

// 将数据赋值到@dst（非空）中 (目前主要是内部使用)
void GYImageDataCreate(GYImageData *dst, void *data, DataFormat format, int w, int h, size_t bpr);

GYAILIB_NAMESPACE_END
