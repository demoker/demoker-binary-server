/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKFaceMeshComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKFaceMeshComponent : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 是否形变
 */
@property(nonatomic, assign) BOOL useMesh;

@property(nonatomic, assign) NSInteger face_index_;

@property(nonatomic, assign) NSInteger face_type_;

/**
 * Comments extracted from cpp files:
 *
 * glb mapping
 */
@property(nonatomic, strong) NSString *mappingPath;

@end

NS_ASSUME_NONNULL_END

