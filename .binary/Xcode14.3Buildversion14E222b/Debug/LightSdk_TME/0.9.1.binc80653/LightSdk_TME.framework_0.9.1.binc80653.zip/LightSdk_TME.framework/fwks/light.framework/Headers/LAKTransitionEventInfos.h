/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKTransitionEventInfos.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"
#import "LAKTimeOffsetType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKTransitionEventInfos : LAKSerializable

@property(nonatomic, assign) NSInteger selectionID;

@property(nonatomic, assign) NSInteger timeOffset;

@property(nonatomic, assign) LAKTimeOffsetType timeOffsetType;

@end

NS_ASSUME_NONNULL_END

