//
//  LAKEntity.h
//  light
//
//  Created by llllish on 2021/11/15.
//

#import <Foundation/Foundation.h>
#import "LAKComponent.h"

typedef NS_ENUM(NSInteger, LAKEntityType) {
    LAKEntityType2D = 0,
    LAKEntityType3D = 1
};

@interface LAKEntity : NSObject <NSCopying, NSCoding>

/** 纯纯的初始化，等于 initWithType:LAKEntityType2D
 * @return Entity
 */
- (instancetype)init;

/** 根据 Entity Type 的默认初始化方法，自带必要的 Component
 * @param type Entity Type
 * @return 2D -> 自带 EntityIdentifier & ScreenTransform，3D -> 自带 EntityIdentifier & BasicTransform
 */
- (instancetype)initWithType:(LAKEntityType)type;

#pragma mark - Entity/查

/** 获取 父Entity
 * @return 父Entity，若为空说明没有 父Entity (一颗独立 Entity 树的根节点)
 */
- (LAKEntity *)parent;

/** 获取所有的 子Entity
 * @return 所有的 子Entity
 */
- (NSArray<LAKEntity *> *)children;

/** 获取特定位置的 子Entity
 * @param index 在子 Entity 数组中的位置
 * @return 该位置的 子Entity，若为空则说明 index 不合法
 */
- (LAKEntity *)childAtIndex:(int)index;

/** 获取特定的 子Entity 在 子Entity 数组中的位置
 * @param child 需要寻找的子 Entity
 * @return 在 子Entity 数组中的位置，若返回 -1 则为没找到
 */
- (int)indexForChild:(LAKEntity *)child;

#pragma mark - Entity/增

/** 插入一个 子Entity
 * @param child 插入的 子Entity
 * @param index 插入的位置
 * @return 是否成功，若失败可能是 子Entity 不合法，或者 index 不存在
 */
- (BOOL)addChild:(LAKEntity *)child atIndex:(int)index;

#pragma mark - Entity/删

/** 删除特定位置的 子Entity
 * @param index 删除的位置
 * @return 是否成功，若失败可能是 index 不存在
 */
- (BOOL)removeChildAtIndex:(int)index;

/** 删除特定的 子Entity
 * @param child 删除的 子Entity
 * @return 是否成功，若失败可能是 子Entity 不存在
 */
- (BOOL)removeChild:(LAKEntity *)child;

/** 删除所有的 子Entity
 */
- (void)removeAllChildren;

/** 删除特定的 Entity，会递归寻找所有世代的 子Entity
 * @attention 这个接口效率很低，尽量不要调用！！
 * @param targetEntity 删除的 Entity
 * @return 是否成功，若失败可能是 target 不存在
 */
- (BOOL)removeTargetEntityRecursively:(LAKEntity *)targetEntity;

#pragma mark - Component/查

/** 获取所有的 Component
 * @return 所有的 Component
 */
- (NSArray<LAKComponent *> *)components;

/** 获取特定种类的 Component
 * @param type 想获取的 Component 种类
 * @return 该种类的 Component，若找不到则为空
 */
- (LAKComponent *)componentByType:(NSString *)type;

#pragma mark - Component/增

/** 添加一个 Component
 * @param component 添加的 Component
 * @param index 插入的位置
 * @return 是否成功，若失败可能是 component 不合法
 */
- (BOOL)addComponent:(LAKComponent *)component;

#pragma mark - Component/删

/** 移除一个 Component
 * @param component 想要移除的 Component
 * @return 是否成功，若失败可能是 component 不合法 / 未找到该 component
 */
- (BOOL)removeComponent:(LAKComponent *)component;

/** 移除特定种类 Component
 * @param type 想要移除的 Component 种类
 * @return 是否成功，若失败可能是 type 不合法 / 未找到符合条件的 component
 */
- (BOOL)removeComponentByType:(NSString *)type;

/** 删除所有的 Component
 */
- (void)removeAllComponents;

// Entity ID
@property (nonatomic, assign) int id;

@end
