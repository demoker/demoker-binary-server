/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKDynamicBone.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKPosition.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKDynamicBone : LAKComponent

@property(nonatomic, strong) LAKPosition *gravity;

@property(nonatomic, assign) NSInteger resetType;

/**
 * Comments extracted from cpp files:
 *
 * 默认false, 每次会更新骨骼旋转角
 */
@property(nonatomic, assign) BOOL noRotationUpdate;

/**
 * Comments extracted from cpp files:
 *
 * 是否关闭用动画重置骨骼位置, 默认打开
 */
@property(nonatomic, assign) BOOL disableAnimationReset;

@end

NS_ASSUME_NONNULL_END

