/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKTimeRange.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKTimeRange : LAKSerializable

@property(nonatomic, assign) NSInteger startTime;

@property(nonatomic, assign) NSInteger duration;

@end

NS_ASSUME_NONNULL_END

