/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKSmartColorItem.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKSmartColorItem : LAKSerializable

@property(nonatomic, assign) NSInteger r;

@property(nonatomic, assign) NSInteger g;

@property(nonatomic, assign) NSInteger b;

@property(nonatomic, assign) float percent;

@end

NS_ASSUME_NONNULL_END

