/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKTextReplaceItem.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKTextReplaceItem : LAKSerializable

@property(nonatomic, assign) BOOL fauxBold;

@property(nonatomic, assign) BOOL fauxItalic;

@property(nonatomic, strong) NSString *fontFamily;

@property(nonatomic, strong) NSString *fontStyle;

@property(nonatomic, assign) BOOL applyStroke;

@property(nonatomic, strong) NSString *strokeColor;

@property(nonatomic, assign) float strokeWidth;

@property(nonatomic, assign) float leading;

@property(nonatomic, assign) float tracking;

@property(nonatomic, strong) NSString *backgroundColor;

@property(nonatomic, assign) NSInteger backgroundAlpha;

@property(nonatomic, strong) NSString *textColor;

@property(nonatomic, assign) NSInteger justification;

@property(nonatomic, assign) float layerWidth;

@property(nonatomic, assign) float layerHeight;

@property(nonatomic, assign) BOOL strokeOverFill;

@end

NS_ASSUME_NONNULL_END

