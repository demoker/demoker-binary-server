/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMaterialSupportRenderToTargetType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKMaterialSupportRenderToTargetType) {
    LAKMaterialSupportRenderToTargetTypeRenderTarget = 0,
    LAKMaterialSupportRenderToTargetTypeCameraTexture = 1
};

@interface LAKMaterialSupportRenderToTargetTypeStringConverter : NSObject
+ (NSString *)toString:(LAKMaterialSupportRenderToTargetType)materialSupportRenderToTargetType;
+ (LAKMaterialSupportRenderToTargetType)fromString:(NSString *)string;
@end

NS_ASSUME_NONNULL_END

