//
//  LightDeviceUtil.h
//  light-sdk
//
//  Created by gallenshao on 2020/11/4.
//

#import "LightConstants.h"
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

///机型级别
typedef NS_ENUM(NSInteger, kLightDeviceLevel){
    kLightDeviceLevelSuperLow = 1,   //超低
    kLightDeviceLevelLow = 2,        //低
    kLightDeviceLevelMid = 3,        //中
    kLightDeviceLevelHigh = 4,       //高
    kLightDeviceLevelSuperHigh = 5   //超高
};

typedef NS_ENUM (NSInteger, kLightCPULevel) {
    kLightCPULeveliPhone4  = 4,
    kLightCPULeveliPhone4s = 5,
    kLightCPULeveliPhone5  = 6,
    kLightCPULeveliPhone5s = 7,
    kLightCPULeveliPhone6  = 8,
    kLightCPULeveliPhone6p = kLightCPULeveliPhone6,
    kLightCPULeveliPhone6s = 9,
    kLightCPULeveliPhoneSE  = kLightCPULeveliPhone6s,
    kLightCPULeveliPhone6sp = kLightCPULeveliPhone6s,
    kLightCPULeveliPhone7 = 10,
    kLightCPULeveliPhone7p = kLightCPULeveliPhone7,
    kLightCPULeveliPhone8 = 11,
    kLightCPULeveliPhone8p = kLightCPULeveliPhone8,
    kLightCPULeveliPhoneX = kLightCPULeveliPhone8,
    kLightCPULeveliPhoneXs = 12,
    kLightCPULeveliPhoneXsMax = kLightCPULeveliPhoneXs,
    kLightCPULeveliPhoneXR = kLightCPULeveliPhoneXs,
    kLightCPULeveliPhone11 = 13,
    kLightCPULeveliPhone11Pro = kLightCPULeveliPhone11,
    kLightCPULeveliPhone11ProMax = kLightCPULeveliPhone11,
    kLightCPULeveliPhoneSE2 = kLightCPULeveliPhone11,
    kLightCPULeveliPhone12 = 14,
    kLightCPULeveliPhone12Mini = kLightCPULeveliPhone12,
    kLightCPULeveliPhone12Pro = kLightCPULeveliPhone12,
    kLightCPULeveliPhone12ProMax = kLightCPULeveliPhone12,
    kLightCPULevelTopLevel = 14, //当前最顶级的CPU
};

@interface LightDeviceUtil : NSObject

+ (NSString *)wmcGetPlatformType;
+ (NSString *)wmcGetDeviceType;

+ (kLightCPULevel)wmcCPULevel;
+ (float)wmcSystemVersion;
+ (double)availableMemory;
+ (double)currentMemory;
+ (NSInteger)wmcRAMLevel;   //内存量，越高越好

/// 机型级别判断
+ (kLightDeviceLevel)deviceLevel;

/// 机型级别数字转string
+ (NSString*) deviceLevelEnumToLevelName:(kLightDeviceLevel)level;

/// 机型级别string转数字
+ (kLightDeviceLevel) deviceLevelNameToLevelEnum:(NSString*)level;

@end

NS_ASSUME_NONNULL_END
