﻿//  gyai_interface.hpp
//  对外接口头文件定义
//
//  Created by gennyxu on 2020/6/6.
//  Copyright © 2020 Tencent. All rights reserved.
//

#pragma once

// clang-format off
#include <stdio.h>
#include <map>
#include <string>
#include <light_ai_base/interface/gyai_interface_feature_t.hpp>
// clang-format on

GYAILIB_NAMESPACE_START

class GYAI_PUBLIC AIInterface {
 public:
  // 第一步：初始化信息
  explicit AIInterface(SDKDeviceConfig *config = nullptr);

  // 第二步：设置模型
  // @return : 0=success; other=failed
  // 备注：子类重写需调用父类，会赋值各类 AIInputParamsMap 到默认参数。
  virtual GYAIStatus SetupWithModel(const SDKModelConfig &model) = 0;

  // 前两步骤特殊组合步骤：默认将device、model一步完成，子类可重写。
  // @return : 0=success; other=failed
  virtual GYAIStatus InitWithConfig(const AIInitConfigType &model);

  // @brief 获取初始化、forward输入输出参数key值和类型
  virtual const AIInputParamsMap &GetInfoWithType(AIInputParamsType type);

  /*!
   * 用于设置参数值（诸如额外参数、smooth配置等），可反复调用
   * @param config 可点击查看类型定义，采用map<string,vector>方式支持int float string类型value
   * @return GYAIErrorCodeSuccess=success; other=failed
   */
  virtual GYAIStatus SetupSDKCommonConfig(const SDKCommonConfig &config);

  // 第三步：网络执行（前向操作）
  // @brief Forward 网络前向，ForwardFast是方便调用进行的简单封装。
  // @params inputMap、outputMap：输入、输出的结果存放（通常存放GYImageData*）。
  // @params option：GPU时，0 异步执行；1 同步执行；GPU建议用异步，除非立刻检验结果。
  // @return : 0=success; other=failed
  virtual GYAIStatus Forward(AIBaseInputType inputMap, AIBaseOutputType outputMap, int option) = 0;

  // 快速接口：默认调用Forward(map, map, option)接口
  virtual GYAIStatus ForwardFast(void *input, AIBaseOutputType outputMap, int option);
  // 快速接口：默认调用ForwardFast(input, map, option)接口
  virtual GYAIStatus ForwardFast(void *input, void *output, int option);

  // 第四步：清理数据
  // @return : 0=success; other=failed
  virtual GYAIStatus CleanupModelData() { return 0; }

  // Other ：清理缓存数据 —— 检测、分割都会缓存平滑数据（根据需要调用，图片批量测试建议经常调用）
  virtual GYAIStatus ClearCachedData() { return 0; }

  // 子类需要实现，调用Cleanup。（尽量自己调用）
  virtual ~AIInterface() = default;

  // 禁止拷贝: 因为内部为模型、纹理等实例，不能轻易拷贝。
  AIInterface(const AIInterface &) = delete;
  AIInterface &operator=(const AIInterface &) = delete;

 protected:
  // @brief 将下方 AIInputParamsMap 填上默认参数，子类可重写（参考 GetInfoWithType）。
  // 三个参数通常用于指定Init、Forward input+output的参数和key值
  AIInputParamsMap init_config_map_;     // 初始化时需赋值，参考AIInitConfigKeyType
  AIInputParamsMap forward_input_map_;   // forward前需赋值，参考 AIForwardInputKeyType
  AIInputParamsMap forward_output_map_;  // forward前需赋值，参考 AIForwardOututKeyType

 protected:
  SDKDeviceConfig device_config_;
};

#pragma mark - 注册机制

// 根据名称注册的creater方法的回调函数。
typedef AIInterface *(*AIInterfaceCreaterCallback)(SDKDeviceConfig *config);

#define GYAISPACE_REGISTER_AIMODULE_CREATER_DECLARATION(module, fid, className) \
  static inline AIInterface *GYAICreate##className(SDKDeviceConfig *config) {   \
    return new className(config);                                               \
  }
#define GYAISPACE_REGISTER_AIMODULE_CREATER_IMPLEMENTION(module, fid, className)

GYAILIB_NAMESPACE_END
