//
//  LightSurface.h
//  light-sdk
//
//  Created by zongyang on 2020/5/25.
//

#import "LightAsset.h"

@interface LightSurface : NSObject

+ (instancetype)MakeFromLayer:(CAEAGLLayer*)layer;

+ (instancetype)MakeFromGPU:(CGSize)size;

+ (instancetype)MakeFromTexture:(unsigned)textureID width:(int)width height:(int)height filpY:(bool)flipY;

- (int)width;

- (int)height;

- (void)updateSize:(CGSize)size;

- (CVPixelBufferRef)getCVPixelBuffer;

- (EAGLContext*)getContext;

- (void)freeCache;

/// 用于标记是否忽略后台状态，正常执行上下文的操作，默认值为 NO
/// 业务使用过程中，在 pip 的情况下，会出现后台状态，但此时渲染是可以正常运行的
/// 提供接口，业务使用过程中根据需要自行设置
/// @param ignore 是否忽略后台状态
- (void)updateIgnoreAppBackgroundStatus:(BOOL)ignore;

@end
