// gy_time.h
// 相对Timer模块增加平均耗时统计功能
// Timer被很多模块公用且，故通过继承新建一个增强版本Timer
//
// Created by easonycwang on 2022/2/15.
// Copyright © 2021 Tencent. All rights reserved.
//
#pragma once

#include <light_ai_base/base/gyai_time_log.h>
#include <map>
#include <chrono>
#include <string>

GYAILIB_NAMESPACE_START

class TimerEnh : public Timer {
 public:
  TimerEnh();

  void Start();

  // 仅记录当前单帧耗时
  float Tick();

  // 根据不同的函数名称，记录当前的平均耗时
  float Tick(const std::string &func_name);

 private:
  // 平均耗时计算
  float GetAverageDuration(const std::string &func_name);

  // 单帧耗时计算
  float GetSingleDuration();

 private:
  std::chrono::time_point<std::chrono::steady_clock> start;
  std::chrono::time_point<std::chrono::steady_clock> end;
};

GYAILIB_NAMESPACE_END
