/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMakeupIris.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKMakeupComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMakeupIris : LAKMakeupComponent

/**
 * Comments extracted from cpp files:
 *
 * 美瞳图片
 */
@property(nonatomic, strong) NSString *irisImage;

/**
 * Comments extracted from cpp files:
 *
 * 是否处理眼睛镂空区域
 */
@property(nonatomic, strong) NSString *eyeMask;

/**
 * Comments extracted from cpp files:
 *
 * 美瞳范围，V5默认值是0.72
 */
@property(nonatomic, assign) float multRadius;

@end

NS_ASSUME_NONNULL_END

