//
//  LightFaceData.h
//  light-sdk
//  人脸检测返回数据结构
//
//  Created by rickshe on 2020/11/7.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LightFaceFeature.h"
#import "LightAIBaseData.h"

NS_ASSUME_NONNULL_BEGIN

/// 对应 LightFaceAgentResult
@interface LightFaceData : LightAIBaseData

@property(nonatomic, strong) NSArray<LightFaceFeature *> *faceFeatures;

@property(nonatomic, assign) CGSize detectImageSize;

@property(nonatomic, assign) CGSize cameraSize;

@property(nonatomic, assign) CGSize renderSize;

// 这里由于吃一个 c++ class <FaceInfoManager>，申明里用 void *
- (instancetype)initWithRawFaceInfo:(void *)faceInfo;

// 这个接口一定要在返回的同步调用！！不保证一段时间后的生命周期，有需要请copy
// To cv::mat -> cv::Mat(size.height, size.width, CV_8UC4, data);
- (void *)getDetectImageData;

- (void *)convertToRawFaceInfo;

@end

NS_ASSUME_NONNULL_END

