/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKGlobalSubAssetComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKGlobalSubAssetSizeType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKGlobalSubAssetComponent : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 指定GlobalSubAsset使用的size类型
 */
@property(nonatomic, assign) LAKGlobalSubAssetSizeType globalSubAssetSizeType;

@property(nonatomic, assign) NSInteger width;

@property(nonatomic, assign) NSInteger height;

@end

NS_ASSUME_NONNULL_END

