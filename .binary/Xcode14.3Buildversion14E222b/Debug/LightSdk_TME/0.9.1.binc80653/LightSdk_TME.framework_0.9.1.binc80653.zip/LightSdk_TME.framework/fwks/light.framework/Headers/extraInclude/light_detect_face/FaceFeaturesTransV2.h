﻿//
//  FaceFeaturesTransV2.h
//  人脸检测
//
// Created by zijunzhang on 2020/7/31.
// Copyright © 2020 tencent. All rights reserved.
//

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void GYAITransYT2Facepp90V2(float *ytFeatures, float faceOutline[][2]);

void GYAITransYT2FaceppVis90V2(float *ytVisibility, float pointVisibilty[]);

#ifdef __cplusplus
}
#endif
