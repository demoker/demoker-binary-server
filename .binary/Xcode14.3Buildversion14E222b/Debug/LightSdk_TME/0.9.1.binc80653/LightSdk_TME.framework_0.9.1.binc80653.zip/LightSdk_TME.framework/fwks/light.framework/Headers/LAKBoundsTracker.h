/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBoundsTracker.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKSize.h"
#import "LAKTimeRange.h"
#import "LAKVec3.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKBoundsTracker : LAKComponent

@property(nonatomic, strong) NSString *key;

@property(nonatomic, strong) NSString *pagLayerName;

@property(nonatomic, assign) float zoom;

@property(nonatomic, strong) LAKVec3 *startPosition;

@property(nonatomic, strong) LAKVec3 *endPosition;

@property(nonatomic, strong) LAKSize *startSize;

@property(nonatomic, strong) LAKSize *endSize;

@property(nonatomic, strong) LAKTimeRange *timeRange;

@end

NS_ASSUME_NONNULL_END

