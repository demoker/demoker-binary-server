﻿//
//  GYAIMetalExtension.h
//  该类定义为Metal公共函数封装。
//
//  Created by gennyxu on 2021/1/18.
//  Copyright © 2021 tencent. All rights reserved.
//

#pragma once

#ifdef __APPLE__

#include <Foundation/Foundation.h>
#include <Metal/Metal.h>
#include <light_ai_base/mac/GYAIImageApplePublic.h>
#include <light_ai_base/data/gyai_cdata_t.h>

#pragma mark - texture with image

GYAILIB_NAMESPACE_START

#pragma mark - texture blit synchronized in buffer

#if TARGET_OS_OSX
/* @brief 只有Mac会使用：根据option在command buffer上执行texture的BlitSchronized操作 (只有Mac支持)
 * @params texture 操作的对象texture
 * @params cmdBuffer 任务需要发送到的buffer
 * @params cmdQueue 会新建 cmd_buffer并提交
 * @params option [CommandCommitWaitType] CommandCommitWaitBiltSynchronize 才会执行
 * */
void MetalSynchronizedTextureInCmdBuffer(id<MTLCommandBuffer> cmdBuffer, id<MTLTexture> texture, int option);
void MetalSynchronizedTextureInQueue(id<MTLCommandQueue> cmdQueue, id<MTLTexture> texture, int option);
#endif

#pragma mark - commit with option

// MTLCommandBuffer 常用的纹理查看的方法集锦：内部使用  (部分方法只有Mac需要，iOS用宏屏蔽掉)
/* @brief 根据option执行cmd_buffer提交和等待
 * @params cmdBuffer 需执行提交或者等待的MTLCommandBuffer
 * @params commitCmdBuffer 内部等待前是否先执行commit操作；如果已经提交，此处传入false。
 * @params option [CommandCommitWaitType] CommandCommitWait...
 * 备注：BiltSynchronize不会执行，参考 GYAIMetalSynchronizedTextureInCmdBuffer。
 * */
void MetalCommandBufferWaitWithOption(id<MTLCommandBuffer> cmdBuffer, bool commitCmdBuffer, int option);
void MetalCommandBufferCommitWithOption(id<MTLCommandBuffer> cmdBuffer, int option);

GYAILIB_NAMESPACE_END

// @brief 只有Mac会使用：根据option在command buffer上执行texture的BlitSchronized操作 (只有Mac支持)
// 加入宏定义：主要为了iOS也调用（和Mac一样，不用每一处调用都做宏区分），但是不生成任何代码。
#if TARGET_OS_OSX
#define GYAIMetalSynchronizedTextureInCmdBuffer(cmdBuffer, texture, option)  \
    GYAISpace::MetalSynchronizedTextureInCmdBuffer(cmdBuffer, texture, option)
#define GYAIMetalSynchronizedTextureInQueue(cmdQueue, texture, option)     \
    GYAISpace::MetalSynchronizedTextureInQueue(cmdQueue, texture, option)
#else
#define GYAIMetalSynchronizedTextureInCmdBuffer(cmdBuffer, texture, option)
#define GYAIMetalSynchronizedTextureInQueue(cmdQueue, texture, option)
#endif

#define GYAIMetalCommandBufferWaitWithOption(cmdBuffer, commitCmdBuffer, option) \
    GYAISpace::MetalCommandBufferWaitWithOption(cmdBuffer, commitCmdBuffer, option)
#define GYAIMetalCommandBufferCommitWithOption(cmdBuffer, option) \
    GYAISpace::MetalCommandBufferCommitWithOption(cmdBuffer, option)

#endif  // #ifdef __APPLE__
