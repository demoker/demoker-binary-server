//
//  gyai_error_report.h
//  GYAIBase
//
//  Created by dreamqian on 2021/11/3.
//  Copyright © 2021 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/gyai_macro_t.h>
#include <stdarg.h>
#include <stdio.h>
#include <memory>
#include <string>

GYAILIB_NAMESPACE_START

#pragma mark - logger agent override

typedef enum {
  LightAILoggerLevelFatal = -3,
  LightAILoggerLevelError = -2,
  LightAILoggerLevelWarning = -1,
  LightAILoggerLevelInfo = 0,
  LightAILoggerLevelDebug = 1,
  LightAILoggerLevelVerbose = 2
} LightAILoggerLevel;

class GYAI_PUBLIC LightAILogger {
 public:
  // @brief 是否调用 Log(...) 进行输出
  virtual bool NeedLog(LightAILoggerLevel level) = 0;
  virtual void Log(LightAILoggerLevel level, const std::string& msg) = 0;

  // @brief 是否打印到终端；默认(未设置agent-override方法)，会打印Warning以及以上级别Log
  virtual bool NeedLogToConsole(LightAILoggerLevel level) { return level < LightAILoggerLevelInfo; }
};

void SetKeyPointCheckLogAgent(std::shared_ptr<LightAILogger> agent);

void PrintKeyPointLog(LightAILoggerLevel level, const std::string& msg);
bool NeedKeyPointLog(LightAILoggerLevel level);
void PrintKeyPointLogToConsole(LightAILoggerLevel level, const std::string& msg);
bool NeedKeyPointLogConsole(LightAILoggerLevel level);

// @brief 格式化字符串，并添加到result后面。
// @return 返回格式字符的长度（大于0；小于等于0为错误码；用整数做返回值，是为了使用__printflike）
#ifdef WIN32
int FormatString(std::string* result, _Printf_format_string_ const char* __restrict fmt, ...);
#else
int FormatString(std::string* result, const char* __restrict format, ...) __printflike(2, 3);
#endif

#pragma mark - logger level macro

// @brief 打印Log (上层需要实现回调；do{}while为了解决编译提示和警告)
#define LIGHTAI_LOG(level, format, ...)                             \
  do {                                                              \
    auto needLog = GYAISpace::NeedKeyPointLog(level);               \
    auto needLogConsole = GYAISpace::NeedKeyPointLogConsole(level); \
    if (!needLog && !needLogConsole) {                              \
      break;                                                        \
    }                                                               \
    std::string msg = "[LightAI] ";                                 \
    FormatString(&msg, format, ##__VA_ARGS__);                      \
    if (needLog) {                                                  \
      GYAISpace::PrintKeyPointLog(level, msg);                      \
    }                                                               \
    if (needLogConsole) {                                           \
      GYAISpace::PrintKeyPointLogToConsole(level, msg);             \
    }                                                               \
  } while (0)

#define LightAILogE(format, ...) LIGHTAI_LOG(LightAILoggerLevelError, format, ##__VA_ARGS__)
#define LightAILogW(format, ...) LIGHTAI_LOG(LightAILoggerLevelWarning, format, ##__VA_ARGS__)
#define LightAILogI(format, ...) LIGHTAI_LOG(LightAILoggerLevelInfo, format, ##__VA_ARGS__)
#define LightAILogD(format, ...) LIGHTAI_LOG(LightAILoggerLevelDebug, format, ##__VA_ARGS__)

GYAILIB_NAMESPACE_END
