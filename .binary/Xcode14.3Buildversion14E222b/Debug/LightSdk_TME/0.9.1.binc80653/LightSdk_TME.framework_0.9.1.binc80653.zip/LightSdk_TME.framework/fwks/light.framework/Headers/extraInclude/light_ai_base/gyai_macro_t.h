﻿//
//  gyai_macro_t.h
//  GYAIBase
//
//  Created by gennyxu on 2020/6/6.
//  Copyright © 2020 Tencent. All rights reserved.
//

#pragma once

// 按照规范namespace改为小写
#define GYAISpace gyailib  // name space
#define LightSpace gyailib  // name space

#define GYAILIB_NAMESPACE_START namespace gyailib {
#define GYAILIB_NAMESPACE_END }  // end of namespace GYAISpace

#define LIGHT_NAMESPACE_START namespace gyailib {
#define LIGHT_NAMESPACE_END }

// Log的默认tag，用于区分模块
#define GYAI_DEFAULT_LOG_TAG "LightAI"

#if defined(_MSC_VER) || defined(WIN32)
#define GYAI_ATTR_ALIGNED(n) __declspec(align(n))
#define GYAI_DEPRECATED_ATTR __declspec(deprecated)
#define GYAI_UNUSE    __declspec((unused)
#ifdef BUILD_WIN_STATIC
#define GYAI_PUBLIC
#define GYAI_INTERNAL
#else
#define GYAI_PUBLIC   __declspec(dllexport)
#define GYAI_INTERNAL __declspec(dllexport)  // __declspec(dllimport)
#endif
#define GYAI_PRIVATE
#else  // __GNUC__
#define GYAI_ATTR_ALIGNED(n) __attribute__((aligned(n)))
#define GYAI_DEPRECATED_ATTR __attribute__((deprecated))
#define GYAI_UNUSE    __attribute__((unused))
#define GYAI_PUBLIC   __attribute__((visibility("default")))
#define GYAI_INTERNAL __attribute__((visibility("default")))
#define GYAI_PRIVATE  __attribute__((visibility("hidden")))  // -fvisibility=hidden
#endif
#define GYAI_PUBLIC_EXTERN extern GYAI_PUBLIC  // 用于C接口
#define GYAI_PUBLIC_C  extern "C" GYAI_PUBLIC  // 用于C接口

GYAILIB_NAMESPACE_START

// Metal/OpenCL-GPU操作指令的等待类型：不等待、等待提交、等待完成、同步到CPU内存等；
typedef enum {
  CommandCommitWaitTypeNone = -1,       // commit only (no wait)
  CommandCommitWaitUntilScheduled = 0,  // wait until Scheduled
  CommandCommitWaitUntilDone,           // wait until finished
  CommandCommitWaitBiltSynchronize,     // [Mac] synchronize data from GPU to CPU texture
} CommandCommitWaitType;

GYAILIB_NAMESPACE_END
