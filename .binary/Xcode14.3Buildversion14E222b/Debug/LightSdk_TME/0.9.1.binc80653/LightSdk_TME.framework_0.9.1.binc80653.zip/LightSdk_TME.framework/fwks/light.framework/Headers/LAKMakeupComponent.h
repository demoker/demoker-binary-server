/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMakeupComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKMakeupExtraFlag.h"
#import "LAKMakeupVisMethod.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMakeupComponent : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 融合图片
 */
@property(nonatomic, strong) NSString *faceImage;

/**
 * Comments extracted from cpp files:
 *
 * 处理面部镂空的mask
 */
@property(nonatomic, strong) NSString *faceMask;

/**
 * Comments extracted from cpp files:
 *
 * 素材人脸点
 */
@property(nonatomic, strong) NSString *facePointsFile;

/**
 * Comments extracted from cpp files:
 *
 * 0：拍摄器， 1：直播， 2：禁用可见性
 */
@property(nonatomic, assign) LAKMakeupVisMethod visMethod;

/**
 * Comments extracted from cpp files:
 *
 * 遮挡出框最低的妆容透明度，支持素材配置
 */
@property(nonatomic, assign) float minVisibility;

/**
 * Comments extracted from cpp files:
 *
 * 额外标志位，目前0x01代表不受美妆滑竿影响
 */
@property(nonatomic, assign) LAKMakeupExtraFlag extraFlag;

@end

NS_ASSUME_NONNULL_END

