/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKPrimitiveConfigV2.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKPrimitiveConfigV2 : LAKSerializable

@property(nonatomic, strong) NSString *materialResourceKey;

@property(nonatomic, strong) NSString *meshResourceKey;

@end

NS_ASSUME_NONNULL_END

