/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKUserMaterial.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKMaterialSupportRenderToTargetType.h"
#import "LAKUserMaterialTrackerType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKUserMaterial : LAKComponent

@property(nonatomic, strong) NSString *defaultResourceSrc;

@property(nonatomic, assign) LAKMaterialSupportRenderToTargetType renderToTargetType;

/**
 * Comments extracted from cpp files:
 *
 * 选图器增加[扣头]、[扣脸]相关能力。
 */
@property(nonatomic, assign) LAKUserMaterialTrackerType trackerType;

/**
 * Comments extracted from cpp files:
 *
 * 扣脸需要一个Mask图
 */
@property(nonatomic, strong) NSString *faceMaskPath;

/**
 * Comments extracted from cpp files:
 *
 * Studio默认产生的五个RT,通过模板json传入到SDK
 */
@property(nonatomic, strong) NSArray<NSString *> *trackerTargetKeys;

/**
 * Comments extracted from cpp files:
 *
 * 统一是用src去LoadResourceFromKey加载
 */
@property(nonatomic, strong) NSString *src;

@end

NS_ASSUME_NONNULL_END

