/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKAnimationChannel.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKChannelTransformTarget.h"
#import "LAKChannelTransformType.h"
#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKAnimationChannel : LAKSerializable

@property(nonatomic, strong) NSString *channel_name_;

@property(nonatomic, assign) LAKChannelTransformTarget transform_target_;

@property(nonatomic, assign) LAKChannelTransformType transform_type_;

@property(nonatomic, strong) NSString *sampler_path_;

@end

NS_ASSUME_NONNULL_END

