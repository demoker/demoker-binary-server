//
//  LightAudioOutput.h
//  light-sdk
//
//  Created by zongyang on 2020/5/25.
//

#import "Definitions.h"

@interface LightAudioOutput : NSObject

- (void)seekTo:(CMTime)time;

/*
 Light SDK里面的音频数据源依赖视频画面渲染和脚本以及事件触发，所以调用copyNextSample一定要先调用LightVideoOutput的readSampleAtTime渲染。
 正确的做法是：渲染一帧画面(LightVideoOutput readSampleAtTime),然后调用LightAudioOutput的copyNextSample获取对应帧数的音频帧(1个视频帧对应若干音频帧)
 直接调用LightAudioOutput的copyNextSample可能会造成音频数据源错误(音频数据源可能依赖画面渲染结果)
 */
- (LightAudioFrame*)copyNextSample;

@end
