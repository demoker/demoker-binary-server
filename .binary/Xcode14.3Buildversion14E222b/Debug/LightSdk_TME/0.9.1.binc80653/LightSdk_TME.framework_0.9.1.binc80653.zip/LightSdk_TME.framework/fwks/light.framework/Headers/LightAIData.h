//
//  LightAIData.h
//  light
//
//  Created by zebiaohuang on 2021/4/6.
//

#import <Foundation/Foundation.h>
#import "LightAIBaseData.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_OPTIONS(NSInteger, LightAIDataType) {
    LightAIDataTypeDefault = 1 << 0,
    LightAIDataTypeSerializedData = 1 << 1,
    LightAIDataTypeReadableData = 1 << 2,
};

/// 对应 LightSDK 内部 LightAgentResult
/// 之前内部包含的 LightAIBaseData 类型应该继承此类型，由于时间原因先保持原样，作为存储非标准数据的类
@interface LightAIData : NSObject

/// 对应数据的 agent type
@property (nonatomic, strong) NSString *key;

/// 标记当前数据内容类型
@property (nonatomic, assign) LightAIDataType dataType;

#pragma - ReadableData Part
@property (nonatomic, strong) LightAIBaseData *data;
@property (nonatomic, strong) NSDictionary<NSNumber*, NSArray<NSNumber*>*> *keyPoints;
@property (nonatomic, strong) NSDictionary<NSNumber*, NSArray<NSString*>*> *classifier;

#pragma - SerializedData Part
@property (nonatomic, strong) NSString *jsonString;

/// 通过 sdk 的 c++ 数据结构初始化
/// @param info void *，根据不同的 agent 返回的数据来处理
- (instancetype)initWithRawInfo:(void *)info jsonString:(NSString*)jsonString key:(NSString*)key;

/// 生成 sdk 的 c++ 数据结构返回
/// 根据 data，keyPoints，classifier 生成数据（不使用 jsonString），若数据无效，则返回 nullptr
- (void *)convertToRawInfo;

@end

/// 封装多个 AI Data 数据结构
@interface LightAIDataWrapper : NSObject

@property (nonatomic, strong) NSDictionary<NSString*, LightAIData*> *dataDictionary;

@end

NS_ASSUME_NONNULL_END
