/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKCrazyFace.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKCrazyFaceModel.h"
#import "LAKFaceMorphingMethodType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKCrazyFace : LAKComponent

@property(nonatomic, assign) NSInteger modelIndex;

@property(nonatomic, strong) NSArray<LAKCrazyFaceModel *> *models;

@property(nonatomic, strong) NSString *modelImage;

@property(nonatomic, strong) NSString *faceMaskImage;

@property(nonatomic, strong) NSString *imageFaceJson;

@property(nonatomic, assign) float progress;

/**
 * Comments extracted from cpp files:
 *
 * 默认启用缓存模式（先缓存一帧，下一帧再做人脸融合）:
 * 场景: 当前帧拿不到人脸点位
 * (使用美型后人脸做人脸、选图器切换图片做人脸融合)
 */
@property(nonatomic, assign) BOOL needCache;

@property(nonatomic, assign) LAKFaceMorphingMethodType method;

@end

NS_ASSUME_NONNULL_END

