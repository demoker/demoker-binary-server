/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKCurvesConfig.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"
#import "LAKVec3.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKCurvesConfig : LAKSerializable

@property(nonatomic, strong) LAKVec3 *shadowGamma;

@property(nonatomic, strong) LAKVec3 *midPoint;

@property(nonatomic, strong) LAKVec3 *highlightScale;

@end

NS_ASSUME_NONNULL_END

