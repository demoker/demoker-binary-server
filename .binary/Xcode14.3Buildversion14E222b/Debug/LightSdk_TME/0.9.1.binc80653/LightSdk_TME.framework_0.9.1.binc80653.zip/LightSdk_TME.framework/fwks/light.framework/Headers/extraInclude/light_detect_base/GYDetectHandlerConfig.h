﻿//
//  GYDetectHandlerConfig.h
//  GYDetectCommon
//
//  Created by gennyxu on 2020/4/13.
//  Copyright © 2020 Tencent. All rights reserved.
//
#pragma once

#include <light_detect_base/GYDetectCommonPublic.h>
#include <string>
#include <vector>

GYAILIB_NAMESPACE_START

class RapidModelInfo {
 public:
  std::string proto;  // proto path
  std::string model;  // model path
};

class GYAI_PUBLIC DetectHandlerConfig {
 public:
  std::string device = "CPU";  // "ARM" "METAL" "NAIVE" "OPENCL" (CPU=x86)
  RapidModelInfo predetect;
  RapidModelInfo detect;
  RapidModelInfo track;
  RapidModelInfo keypoint;
  RapidModelInfo classify;
  std::vector<std::string> classifyNames;
  int preferKeypointsCount = 0;  // 期望keypoint结果数量，不满足会报错，0是通配
  bool isUseingForVideo = true;  // 如果给视频使用，会记录上一帧结果用于下一帧追踪
};

#pragma mark - RapidNetSize

// RapidNetSize use for
typedef struct GYAI_PUBLIC RapidNetSize {
  // 占用内存大小通常是：number * height * width * channel（不考虑通道对齐的Pack排列）
  // 可以参考DimsVectorUtils::Count(...)!
  int number, channel, height, width;  // padHeight, padWidth, strideHeight, strideWidth;
} RapidNetSize;

// default number,channel is 1, 1 : 即单输入、单通道
static inline RapidNetSize RapidNetSizeMake(int width, int height, int channel = 1,
                                            int number = 1) {
  RapidNetSize size = { number, channel, height, width, };
  return size;
}

// @params input default size must be 4
static inline RapidNetSize RapidNetSizeMake(const std::vector<int> &input) {
  if (input.size() == 2) {
    return RapidNetSizeMake(input[1], input[0], 1, 1);
  }
  if (input.size() == 3) {
    return RapidNetSizeMake(input[2], input[1], input[0], 1);
  }
  assert(input.size() >= 4);
  return RapidNetSizeMake(input[3], input[2], input[1], input[0]);
}

GYAILIB_NAMESPACE_END
