/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKScript.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKScript : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 需要加载的脚本路径
 */
@property(nonatomic, strong) NSString *scriptPath;

/**
 * Comments extracted from cpp files:
 *
 * 脚本里定义的所需要的ai数据， 能使用的值在 sdk/src/Constant.h里
 */
@property(nonatomic, strong) NSArray<NSString *> *aiRequire;

@property(nonatomic, strong) NSArray<NSString *> *dataRequire;

/**
 * Comments extracted from cpp files:
 *
 * 脚本中 entity id 的偏移值 (id_in_js + offset = real_id)
 */
@property(nonatomic, assign) NSInteger entityIDOffset;

@end

NS_ASSUME_NONNULL_END

