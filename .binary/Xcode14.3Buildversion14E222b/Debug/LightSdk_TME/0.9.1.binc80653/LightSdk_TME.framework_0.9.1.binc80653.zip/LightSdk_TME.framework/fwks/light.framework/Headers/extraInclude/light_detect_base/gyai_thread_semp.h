//
//  gyai_thread_semp.h
//  线程扩展 —— 信号量，增加超时等待等操作。
//
//  Created by gennyxu on 2021/12/14.
//  Copyright © 2021 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/GYAIBase.h>
#include <condition_variable>
#include <future>
#include <mutex>
#include <thread>

GYAILIB_NAMESPACE_START

#pragma mark - semaphore 信号量

// @brief 避免使用promise，每一帧new一个只能等待、获取一次。
class Semaphore {
 public:
  explicit Semaphore(int count = 0) : count_(count) {}

  // @brief 信号量计数增加
  void Signal() {
    std::unique_lock<std::mutex> lock(mutex_);
    ++count_;
    condition_.notify_one();
  }

  // @brief 等待引用计数：只有收到一个才退出等待。
  bool Wait(int64_t timeout_ms = 0) {
    std::unique_lock<std::mutex> lock(mutex_);
    if (timeout_ms <= 0) {
      condition_.wait(lock, [=] { return count_ > 0; });
      --count_;  // 成功等到信号量，计数减一
      return true;
    }

    // auto duration = std::chrono::milliseconds(static_cast<int64_t>(timeout * 1000));
    auto duration = std::chrono::milliseconds(timeout_ms);
    auto status = condition_.wait_for(lock, duration, [=] { return count_ > 0; });
    if (status) {
      --count_;  // 成功等到信号量，计数减一
    }
    return status;
  }

 private:
  std::condition_variable condition_;
  std::mutex mutex_;
  int count_ = 0;
};

GYAILIB_NAMESPACE_END
