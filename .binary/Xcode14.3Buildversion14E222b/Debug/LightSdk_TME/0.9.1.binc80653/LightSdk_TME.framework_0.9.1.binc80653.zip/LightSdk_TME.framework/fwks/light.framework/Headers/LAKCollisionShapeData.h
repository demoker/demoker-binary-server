/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKCollisionShapeData.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"
#import "LAKVec3.h"
#import "LAKkRigidBody3DShapeType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKCollisionShapeData : LAKSerializable

@property(nonatomic, strong) LAKVec3 *local_position_;

@property(nonatomic, strong) LAKVec3 *local_rotation_;

@property(nonatomic, assign) LAKkRigidBody3DShapeType shape_type_;

@property(nonatomic, strong) LAKVec3 *box_half_length_;

@property(nonatomic, assign) float sphere_radius_;

@property(nonatomic, assign) float capsule_radius_;

@property(nonatomic, assign) float capsule_height_;

@property(nonatomic, assign) float cylinder_radius_;

@property(nonatomic, assign) float cylinder_height_;

@end

NS_ASSUME_NONNULL_END

