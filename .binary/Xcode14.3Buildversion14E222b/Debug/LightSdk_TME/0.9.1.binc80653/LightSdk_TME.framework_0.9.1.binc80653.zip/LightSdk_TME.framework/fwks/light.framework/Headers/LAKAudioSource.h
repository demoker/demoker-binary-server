/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKAudioSource.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKAudioSourceType.h"
#import "LAKComponent.h"
#import "LAKVolumeEffect.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKAudioSource : LAKComponent

@property(nonatomic, assign) float volume;

@property(nonatomic, assign) float speed;

@property(nonatomic, strong) NSArray<LAKVolumeEffect *> *volumeEffects;

@property(nonatomic, assign) LAKAudioSourceType audioSourceType;

/**
 * Comments extracted from cpp files:
 *
 * 统一是用src去LoadResourceFromKey加载
 */
@property(nonatomic, strong) NSString *src;

@end

NS_ASSUME_NONNULL_END

