/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBodyDriving3D.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKModelMoveType.h"
#import "LAKVec3.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKBodyDriving3D : LAKComponent

@property(nonatomic, strong) NSString *halfBodyMode;

@property(nonatomic, assign) BOOL enableHandMode;

/**
 * Comments extracted from cpp files:
 *
 * [serialization]
 * 跟踪的骨骼点
 */
@property(nonatomic, strong) NSDictionary<NSString *, NSNumber *> *trackingBones;

/**
 * Comments extracted from cpp files:
 *
 * 0：用户比例移动，1：模型比例移动
 */
@property(nonatomic, assign) LAKModelMoveType modelMoveType;

@property(nonatomic, strong) LAKVec3 *offsetXYZ;

@property(nonatomic, assign) BOOL enableTranslateXY;

@property(nonatomic, assign) BOOL enableTranslateZ;

@property(nonatomic, assign) BOOL enableBlockByBody;

@property(nonatomic, assign) BOOL enableContactGround;

@property(nonatomic, assign) NSInteger groundPlaneEntityId;

@end

NS_ASSUME_NONNULL_END

