//
//  LightFaceFeature.h
//  light-sdk
//  人脸检测返回的单个人脸数据结构
//
//  Created by rickshe on 2020/11/7.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LightFaceOriginDataModel.h"
#import <SceneKit/SceneKit.h>
#import "LightAIBaseFeature.h"

#define LIGHT_FACE_FEATURE_POINT_NUM 83
#define LIGHT_FACE_FEATURE_RAW_POINT_NUM 94
#define LIGHT_FACE_FEATURE_256_POINT_NUM 256
#define LIGHT_FACE_FEATURE_3D_POINT_NUM 1000

NS_ASSUME_NONNULL_BEGIN

/// 对应 Face2DInfo
@interface LightFaceFeature : LightAIBaseFeature
// 人脸标识
@property (nonatomic, assign) int trace_id;
// 检测图片大小
@property (nonatomic, assign) CGSize imageSize;
// 相机输入大小
@property (nonatomic, assign) CGSize cameraSize;
// 渲染大小
@property (nonatomic, assign) CGSize renderSize;
// 人脸框
@property (nonatomic, assign) CGRect faceBounds;
// 左眼框
@property (nonatomic, assign) CGRect leBounds;
// 右眼眶
@property (nonatomic, assign) CGRect reBounds;
// 嘴巴框
@property (nonatomic, assign) CGRect mouthBounds;
// 人脸角度
@property (nonatomic, assign) CGFloat pitch;
@property (nonatomic, assign) CGFloat yaw;
@property (nonatomic, assign) CGFloat roll;
// 这个是啥意思 (暂时没东西) 
@property (nonatomic, readonly) BOOL hasOutline;
// 性别 (前五帧没数据)
@property (nonatomic, strong) NSString* gender;
// 年龄
@property (nonatomic, assign) NSInteger age;
// 表情 (string - bool)
@property (nonatomic, strong) NSDictionary<NSString *, NSNumber *> *expression;
// 情绪识别结果
@property (nonatomic, strong) NSString *emotion;

// float[LIGHT_FACE_FEATURE_POINT_NUM][2]
@property (nonatomic, strong, readonly) NSArray<NSArray<NSNumber *> *> *faceFeaturePoints;
// bool[LIGHT_FACE_FEATURE_POINT_NUM]
@property (nonatomic, strong, readonly) NSArray<NSNumber *> *faceFeatureVisibility;

// float[LIGHT_FACE_FEATURE_RAW_POINT_NUM][2]
@property (nonatomic, strong, readonly) NSArray<NSArray<NSNumber *> *> *faceFeatureRawPoints;
// bool[LIGHT_FACE_FEATURE_RAW_POINT_NUM]
@property (nonatomic, strong, readonly) NSArray<NSNumber *> *faceFeatureRawVisibility;


// float[LIGHT_FACE_FEATURE_256_POINT_NUM][2]
@property (nonatomic, strong, readonly) NSArray<NSArray<NSNumber *> *> *faceFeature256Points;
// bool[LIGHT_FACE_FEATURE_256_POINT_NUM]
@property (nonatomic, strong, readonly) NSArray<NSNumber *> *faceFeature256Visibility;

// 3d transform matrix
@property (nonatomic, assign, readonly) SCNMatrix4 transform3D;
// float[LIGHT_FACE_FEATURE_3D_POINT_NUM][3]
@property (nonatomic, strong, readonly) NSArray<NSArray<NSNumber *> *> *faceFeature3DPoints;

// 给音视频的数据结构
@property (nonatomic, strong, readonly) LightFaceOriginDataModel *faceOriginDataModel;

// 这里由于吃一个 c++ class <Face2DInfo>，申明里用 void *
- (instancetype)initWithRawFaceFeature:(void *)faceFeature;

/// 手动设置必要人脸点数据（83点）
/// @param faceFeaturePoints size：166
/// @param faceFeatureVisibility size：83
- (void)updateFaceFeaturePoints:(NSArray<NSArray<NSNumber *>*>*)faceFeaturePoints
          faceFeatureVisibility:(NSArray<NSNumber*>*)faceFeatureVisibility;

- (void *)convertToRawFaceFeature;

@end

NS_ASSUME_NONNULL_END
