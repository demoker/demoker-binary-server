//
//  light_detect_base_version.h
//
//  Copyright 2022 Tencent. All rights reserved.
//

#pragma once

static char *branch_name = "release/0.33";
static char *commit_date = "2022-04-28 10:00:15";
static char *commit_hash = "f61a17012";
