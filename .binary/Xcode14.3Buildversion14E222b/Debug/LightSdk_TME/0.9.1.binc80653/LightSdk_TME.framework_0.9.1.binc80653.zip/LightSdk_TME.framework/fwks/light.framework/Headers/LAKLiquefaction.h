/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKLiquefaction.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKLiquefaction : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 形变资源文件
 */
@property(nonatomic, strong) NSString *resourcePath;

/**
 * Comments extracted from cpp files:
 *
 * 形变强度
 */
@property(nonatomic, assign) float strength;

/**
 * Comments extracted from cpp files:
 *
 * 短脸形变资源文件
 */
@property(nonatomic, strong) NSString *shortFaceResourcePath;

/**
 * Comments extracted from cpp files:
 *
 * 短脸形变强度
 */
@property(nonatomic, assign) float shortFaceStrength;

/**
 * Comments extracted from cpp files:
 *
 * 边缘形变弱化开关，默认0为关闭，1为开启
 */
@property(nonatomic, assign) NSInteger boundaryFixMode;

@end

NS_ASSUME_NONNULL_END

