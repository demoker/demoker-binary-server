//
//  LightCameraController.h
//  light
//
//  Created by 吕所军 on 2020/8/27.
//

#import "LightController.h"
#import "Definitions.h"

@interface LightCameraController : LightController

// 厘米秀/AR相关接口
- (void)setKapuModel:(NSDictionary <NSString*, NSString*>*)pathMap
             faceStr:(NSString*)faceStr
            callback:(CmShowCallbackBlock)callback;
- (void)setKapuAnimation:(NSString*)path
                callback:(CmShowCallbackBlock)callback;
- (void)updateKapuMorph:(LightCmShowAnimojiExpressionType)type;
- (void)updateTouchScale:(float)scale;
- (void)updateTouchRotate:(float[3])rotate;
- (void)updateTouchEvent:(LightTouchEvent *)event;
- (void)updateVoiceDecibel:(float)decibel;
- (void)setARFrameInfo:(LightARFrameInfo *)info;
- (void)pause3DAnimation;
- (void)resume3DAnimation;
- (void)register3DAnimation:(NSArray<NSString *>*)animations;
- (void)setHitTestAfterUnprojection:(float[3])downPoints;
- (void)getHitTestFilamentAssets:(float[3])hitPoint callback:(HitfilaCallback)callback;
- (void)getFilamentAssetPosition:(FilaPosCallback)callback;
- (void)rotateArModelToFront:(int)deviceOrientation;
- (void)updateViewParamsFullViewSize:(float[2])fullViewSize
                      modelViewFrame:(float[4])modelViewFrame
                        bottomMargin:(float)bottomMargin;
- (void)setKapuCameraViewType:(LightCmShowCameraViewType)type;
- (void)setKapuDisplayType:(LightCmShowMaterialDisplayType)type;

// 手Q在使用
- (void)setSegmentationFastMode:(bool)isOn;

/**
 * 更新相机纹理数据时间戳
 * 如果用到了AR/3D玩法最好通过该接口每帧update；
 * timestamp数据在AR玩法会使用到，与IMU时间戳是同数量级和同时间线上的，用于一些算法计算
 * @param timestamp 当前相机纹理数据时间戳
 */
- (void)updateCameraTextureTimestamp:(CMTime)timestamp;

@end
