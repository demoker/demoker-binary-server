//  gyai_thread_queue.h
//  线程扩展，用于简单的异步操作
//
//  Created by gennyxu on 2021/12/14.
//  Copyright © 2021 Tencent. All rights reserved.
//

#pragma once

#include <light_detect_base/gyai_thread_semp.h>
#include <condition_variable>
#include <deque>
#include <future>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#ifdef __ANDROID__
#include "gy_cpu_policy.h"  // NOLINT
#endif

GYAILIB_NAMESPACE_START

// @brief 用于简单的多线程支持：通过传入执行函数、lambda实现。
// 创建线程任务：目前只支持单线程，内部FIFO顺序执行传入任务。
// class TaskQueue : public std::enable_shared_from_this<TaskQueue> {
class TaskQueue {
 public:
  using Task = std::function<void()>;
  // @brief 默认线程queue，主要CV内部使用（尽量自己新建Queue线程执行）
  static std::shared_ptr<TaskQueue> DefaultQueue();

 public:
  explicit TaskQueue(const std::string &identifier, size_t threads_count = 1);
  ~TaskQueue();

  // @brief 执行操作：传入任务，加入队列（会立刻返回，任务异步执行）
  void RunTask(Task task);
  void CancelAllWaitingTasks();
  size_t GetWaitingTasksCount();  // 获取当前任务列表数量（Wait同步操作也是一个task任务）
  size_t GetRunningTasksCount();  // 正在运行的任务数量（不包括等待列表）
  size_t GetTasksCount();         // 正在运行的任务数量 + 等待列表 数量

  // @brief 等待并设置等待超时时间，时间范围完成，返回true（单位：秒，大于0为合法值）
  bool WaitAllTasksFinished(double timeout = 0);  // 所有任务结束，等待后插入列表的任务还会等
  bool WaitCurrentTasksFinished(double timeout);  // 等当前已有任务完成（任务列表插入楔子）
  void WaitCurrentTasksFinished();  // 等当前已有任务完成（任务列表插入楔子）

  // @brief 强制关停当前线程接口，仅针对含有硬件的场景使用（DSP/GPU）
  // @Note  普通计算任务不得使用
  void ForceToKillThisThread();

  // 禁止拷贝: 因为内部为模型、纹理等实例，不能轻易拷贝。
  TaskQueue(const TaskQueue &) = delete;
  TaskQueue &operator=(const TaskQueue &) = delete;

 private:
  // @brief 线程执行loop (静态或者全局函数)
  static void RunLoop(TaskQueue *queue, int threadIdx);

 private:
  std::string identifier_;
  std::unique_ptr<std::thread> thread_;
  // std::vector<std::thread> threads_;

  // 内部变量类型：用于线程执行数据 & 控制参数
  class TaskData {
   public:
    std::condition_variable condition_;  // std::condition_variable<std::mutex>
    std::mutex mutex_;
    std::deque<Task> tasks_;
    size_t running_ = 0;  // 正在执行的任务数量，可用于反应是否有任务在执行
    bool exit_ = false;
  } task_data_;
};

GYAILIB_NAMESPACE_END
