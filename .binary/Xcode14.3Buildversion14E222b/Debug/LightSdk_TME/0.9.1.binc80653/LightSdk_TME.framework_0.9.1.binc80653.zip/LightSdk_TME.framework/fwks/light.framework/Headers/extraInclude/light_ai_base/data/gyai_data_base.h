﻿//  gyai_data_base.h
//  基础对象和数据
//
//  Created by gennyxu on 2021/1/28.
//  Copyright © 2021 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/data/gyai_cdata_t.h>
#include <map>
#include <string>
#include <vector>

GYAILIB_NAMESPACE_START

#pragma mark - orientation

// 各个图像对应的旋转方向（默认情况，手机理解为图片：上方相机朝向哪个方向）
// 需结合实际情况设置：如手机相机传入的检测图片为横屏图，则横屏为正方向Up。
typedef enum {
  DeviceOrientationUnknown,
  DeviceOrientationUp,
  DeviceOrientationLeft,
  DeviceOrientationDown,
  DeviceOrientationRight,
} DeviceOrientation;

// @brief 输入的图片方向是否为横向（部分矩阵计算宽高需交换；不包括 unknown）
static inline bool DeviceOrientationIsLandscape(DeviceOrientation ori) {
  return ori == DeviceOrientationLeft || ori == DeviceOrientationRight;
}

#pragma mark - forward input object base

// 目前常见的数据类型
typedef enum {
  BaseDataClassTypeUnknown = 0,     // 常见的输入参数对象定义基类，管理输入数据
  BaseDataClassTypeImage = 'img0',  // 输入的为GYImageData类型
  BaseDataClassTypeFeature = 'feas',  // 输入的为feature provider
} BaseDataClassType;

// 主要为了方便外界输入数据的内存管理，避免使用void *数据，导致析构函数调用不便。
// 可以让各种类型输入数据都继承该类：方便内存管理
class GYAI_PUBLIC BaseData {
 public:
  virtual ~BaseData() = default;
  BaseDataClassType GetObjectType() const { return cls_type_; }

 protected:
  BaseDataClassType cls_type_ = BaseDataClassTypeUnknown;
};

#pragma mark - forward input / output frame

// 光影检测类型通用原始元素坐标结构: 为了方便后面的追踪、稳定增加。
typedef struct GYAI_PUBLIC DetectItemBaseFrame {
  union {
    // 如需兼容人脸对其调用, 即w/widht指向相同；需再加一层 union{{w,h;}; {width,height;};}
    struct { float x, y, w, h; };
    GYAIRect4f rect4f;  // left-top position
    GYAIPoint4f point4f;
  };
  float confidence;  // 框的置信度；检测模块使用而增加，方便返回结果统一存储
} DetectItemBaseFrame;

/*!
 * 通用配置类，map参数可支持配置int float string类型值，可用于业务层设置额外成员变量
 */
class GYAI_PUBLIC SDKCommonConfig {
 public:
  virtual ~SDKCommonConfig() = default;
  std::map<std::string, std::vector<int>> map_vec_int_;
  std::map<std::string, std::vector<float>> map_vec_float_;
  std::map<std::string, std::vector<std::string>> map_vec_string_;
//  std::map<std::string, std::vector<bool>> map_vec_bool_;
};

GYAILIB_NAMESPACE_END
