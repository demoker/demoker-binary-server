/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKSSAOConfig.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKSSAOConfig : LAKSerializable

@property(nonatomic, assign) BOOL enable;

@property(nonatomic, assign) float radius;

@property(nonatomic, assign) float intensity;

@property(nonatomic, assign) float bias;

@property(nonatomic, assign) float power;

@end

NS_ASSUME_NONNULL_END

