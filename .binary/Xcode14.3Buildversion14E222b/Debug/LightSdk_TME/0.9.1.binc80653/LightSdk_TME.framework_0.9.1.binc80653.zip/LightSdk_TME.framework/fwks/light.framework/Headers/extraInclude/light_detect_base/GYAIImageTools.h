﻿//
//  GYAIImageTools.h
//  该类定义为图片 to cv::Mat 常用方法封装。
//
//  Created by gennyxu on 2020/10/30.
//  Copyright © 2020 tencent. All rights reserved.
//

#pragma once

#ifdef __APPLE__

#include <light_ai_base/light_ai_mac.h>
#include <opencv2/opencv.hpp>

GYAILIB_NAMESPACE_START

// 结果图通常是四通道RGBA字节序的格式 (返回的Mat是BigEndian-RGBA；注意cv::imwrite写入需要BGRA)。
// @params alphaExist 目前只支持true
// @params bgra 表示生成bgra格式还是rgba格式（只支持iOS-GPU最常用的这两种）
void ConvertImageToCVMat(const GYAIImputImageClass *image, cv::Mat *pmat, bool alphaExist = true,
                         bool bgra = false);

GYAILIB_NAMESPACE_END
#endif  // #ifdef __APPLE__
