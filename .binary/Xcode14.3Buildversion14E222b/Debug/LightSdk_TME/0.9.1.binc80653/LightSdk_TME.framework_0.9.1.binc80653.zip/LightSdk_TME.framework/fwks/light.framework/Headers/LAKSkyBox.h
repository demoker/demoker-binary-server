/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKSkyBox.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKSkyBoxMaskType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKSkyBox : LAKComponent

@property(nonatomic, strong) NSString *bgLut;

@property(nonatomic, strong) NSString *cubeMap;

@property(nonatomic, assign) LAKSkyBoxMaskType maskType;

@end

NS_ASSUME_NONNULL_END

