/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKRigidbody3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKRigidbody3DComponent : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 控制这个刚体是否是一个Dynamic或者Kinematic刚体
 * (最基本的区别，dynamic物体transfrom被物理驱动，而kinematic驱动物理体的transform)
 */
@property(nonatomic, assign) BOOL is_dynamic_;

@property(nonatomic, assign) float mass_;

@property(nonatomic, assign) float friction_;

@property(nonatomic, assign) float rolling_friction_;

@property(nonatomic, assign) float restitution_;

@property(nonatomic, assign) float linear_damping_;

@property(nonatomic, assign) float angular_damping_;

@property(nonatomic, assign) float ccd_motion_threshold_;

@property(nonatomic, assign) NSInteger collision_filter_group_;

@property(nonatomic, assign) NSInteger collision_filter_mask_;

@property(nonatomic, assign) BOOL emit_collision_event_;

@end

NS_ASSUME_NONNULL_END

