/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBeauty.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKBeauty : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 美颜版本
 */
@property(nonatomic, strong) NSString *beautyVersion;

/**
 * Comments extracted from cpp files:
 *
 * 清晰滤镜, v7新增
 */
@property(nonatomic, assign) float lutClearAlpha;

/**
 * Comments extracted from cpp files:
 *
 * 美白滤镜, v7新增
 */
@property(nonatomic, assign) float lutFoundationAlpha;

/**
 * Comments extracted from cpp files:
 *
 * 美白滤镜, v7新增
 */
@property(nonatomic, assign) float lutFoundationAlphatme;

/**
 * Comments extracted from cpp files:
 *
 * 五官立体脸部叠加层五官立体, v7新增
 */
@property(nonatomic, assign) float faceFeatureBlendFaceAlphaSoftlight;

/**
 * Comments extracted from cpp files:
 *
 * 五官立体脸部叠加层腮红, v7新增
 */
@property(nonatomic, assign) float faceFeatureBlendFaceAlphaRedCheek;

/**
 * Comments extracted from cpp files:
 *
 * 五官立体脸部叠加层
 */
@property(nonatomic, assign) float faceFeatureBlendFaceAlpha;

/**
 * Comments extracted from cpp files:
 *
 * 白牙
 */
@property(nonatomic, assign) float faceFeatureTeethLutAlpha;

/**
 * Comments extracted from cpp files:
 *
 * 嘴唇, v7新增
 */
@property(nonatomic, assign) float faceFeatureLipsLutAlpha;

/**
 * Comments extracted from cpp files:
 *
 * 去皱
 */
@property(nonatomic, assign) float deepSmoothAlpha;

/**
 * Comments extracted from cpp files:
 *
 * 法令纹
 */
@property(nonatomic, assign) float wrinkleAlpha;

/**
 * Comments extracted from cpp files:
 *
 * 亮眼
 */
@property(nonatomic, assign) float eyeLightenAlpha;

/**
 * Comments extracted from cpp files:
 *
 * 眼眉对比度
 */
@property(nonatomic, assign) float eyebrowContrastAlpha;

/**
 * Comments extracted from cpp files:
 *
 * 鲜明
 */
@property(nonatomic, assign) float imageContrastAlpha;

/**
 * Comments extracted from cpp files:
 *
 * 肤色
 */
@property(nonatomic, assign) float skinColorSlider;

/**
 * Comments extracted from cpp files:
 *
 * 祛眼袋
 */
@property(nonatomic, assign) float eyePouchAlpha;

/**
 * Comments extracted from cpp files:
 *
 * 基础美美妆单项开关（v6:腮红、五官立体；v7：口红腮红五官立体）
 */
@property(nonatomic, assign) BOOL enableFaceFeature;

/**
 * Comments extracted from cpp files:
 *
 * 唇彩type
 */
@property(nonatomic, assign) NSInteger lipsType;

/**
 * Comments extracted from cpp files:
 *
 * 磨皮，v8新增
 */
@property(nonatomic, assign) float beautySmooth;

/**
 * Comments extracted from cpp files:
 *
 * 锐化，v8新增
 */
@property(nonatomic, assign) float beautySharpen;

/**
 * Comments extracted from cpp files:
 *
 * 锐化，v8新增
 */
@property(nonatomic, assign) float beautySharpentme;

/**
 * Comments extracted from cpp files:
 *
 * 曝光，v8新增
 */
@property(nonatomic, assign) float beautyExposure;

/**
 * Comments extracted from cpp files:
 *
 * 沟壑平整：眼周, v9新增
 */
@property(nonatomic, assign) float facialShadowEye;

/**
 * Comments extracted from cpp files:
 *
 * 沟壑平整：鼻周, v9新增
 */
@property(nonatomic, assign) float facialShadowNose;

/**
 * Comments extracted from cpp files:
 *
 * 五官立体Mask路径
 */
@property(nonatomic, strong) NSString *softLightPath;

/**
 * Comments extracted from cpp files:
 *
 * 腮红Mask路径
 */
@property(nonatomic, strong) NSString *beautyMultiplyPath;

/**
 * Comments extracted from cpp files:
 *
 * 唇彩Mask路径
 */
@property(nonatomic, strong) NSString *lipsMaskPath;

@end

NS_ASSUME_NONNULL_END

