//
//  yt_face_detector_version.h
//
//  Copyright 2022 Tencent. All rights reserved.
//\n
#pragma once\n
static char *branch_name = "";
static char *commit_date = "2022-01-11 20:49:55";
static char *commit_hash = "c905d91";
static char *tag = "v3.9.0-light.5";
