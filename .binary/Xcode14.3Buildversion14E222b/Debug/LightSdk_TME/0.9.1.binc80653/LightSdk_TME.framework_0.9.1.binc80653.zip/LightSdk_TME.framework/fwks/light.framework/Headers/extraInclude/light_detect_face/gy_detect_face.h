﻿//
//  gy_detect_face.h
//  人脸检测——因历史原因，外界已使用，所以该文件没有重新命名为light_xxx_xxx.
//
// Created by zijunzhang on 2020/6/16.
// Copyright © 2020 tencent. All rights reserved.
//

#pragma once

#include <light_detect_face/FaceDetector.h>
#include <light_detect_face/FaceDetectorFeature.h>
#include <light_detect_face/FaceDetectorFeaturePerspective.h>
#include <light_detect_face/YTTNNFaceSDK.hpp>
