/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKParticleTriggerType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKParticleTriggerType) {
    LAKParticleTriggerTypeNonStatic = 0,
    LAKParticleTriggerTypeStatic = 1
};

@interface LAKParticleTriggerTypeStringConverter : NSObject
+ (NSString *)toString:(LAKParticleTriggerType)particleTriggerType;
+ (LAKParticleTriggerType)fromString:(NSString *)string;
@end

NS_ASSUME_NONNULL_END

