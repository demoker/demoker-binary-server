//
//  gy_reporter.h
//  用于LightCV的数据上报
//
//  Created by atilazhang on 2021/12/29.
//  Copyright © 2021 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/GYAIBase.h>
#include <memory>
#include <string>
#include <unordered_map>

GYAILIB_NAMESPACE_START

class GYReporter {
 public:
  static std::shared_ptr<GYReporter> getInstance();
  GYReporter(const GYReporter&);
  GYReporter& operator=(const GYReporter&);

  /**
   * 设置common字段，会覆盖
   * @param commonParams
   */
  void SetCommonParam(const std::unordered_map<std::string, std::string>& commonParams);
  void SetCommonParam(const std::string& key, const std::string& value);

  // clear
  void ClearCommonParam();
  /*
   * Report 内部sdk使用
   */
  void Report(const std::string &event,
              const std::unordered_map<std::string, std::string> &report_items);
  /*
   * ReportError 内部sdk使用，上报内部错误
   */
  void ReportError(const std::string& event, std::string errorType, std::string errorMsg);

 private:
  static std::shared_ptr<GYReporter> instance;

  GYReporter() {}

  // 记录common字段
  static std::unordered_map<std::string, std::string> CommonParam;

  static std::unordered_map<std::string, std::string> CreateCommonParam();
};

GYAILIB_NAMESPACE_END
