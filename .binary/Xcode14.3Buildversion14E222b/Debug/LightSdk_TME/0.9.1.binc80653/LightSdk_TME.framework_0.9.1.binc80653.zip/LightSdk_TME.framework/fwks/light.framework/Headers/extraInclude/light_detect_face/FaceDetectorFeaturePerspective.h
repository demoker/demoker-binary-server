﻿//
//  FaceDetectorFeaturePerspective.h
//  人脸检测
//
// Created by zijunzhang on 2020/7/31.
// Copyright © 2020 tencent. All rights reserved.
//

#pragma once

#include <YTFaceAlignment/yt_face_alignment.h>
#include <light_ai_base/GYAIBase.h>

// 优图最大的3d点数量 (跟版本，通常不会修改)
#define KGYAI_FACE_3DPOINTS_NUM YT_3D_DENSE_POINTS_NUM  // 1000

#ifdef __cplusplus
extern "C" {
#endif

typedef yt_point3f GYFace3DPoint;  // GYAIPoint3f vs yt_point3f

/* @brief 通用的结构，为了兼容C++/OC改为C的结构，方便两边同时引用。
 * 优图3d点结构
 * */
typedef struct GYAIFaceFeaturePerspective {
  GYFace3DPoint face_points_3d[KGYAI_FACE_3DPOINTS_NUM];
  size_t face_points_count;  // face_points_3d 点的真实数量
  float pitch;
  float yaw;
  float roll;
  float transform[4][4];  // 4*4 matrix from objective coordinates to camera coordinates
} GYAIFaceFeaturePerspective;

#ifdef __cplusplus
}  // end of extern "C"
#endif
