//
//  gy_reporter_def.h
//  用于LightCV的数据上报
//
//  Created by atilazhang on 2021/12/29.
//  Copyright © 2021 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/GYAIBase.h>
#include <string>

GYAILIB_NAMESPACE_START

// 灯塔为Light分配的业务id
#if __ANDROID__
#define kBeaconAppKey "0AND0WH9714UPYKY"
#else
#define kBeaconAppKey "0IOS00N9714YU8EN"
#endif

GYAILIB_NAMESPACE_END
