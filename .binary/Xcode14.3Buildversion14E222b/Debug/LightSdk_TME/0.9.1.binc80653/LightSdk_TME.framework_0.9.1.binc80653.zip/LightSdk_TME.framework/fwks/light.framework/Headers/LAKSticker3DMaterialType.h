/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKSticker3DMaterialType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKSticker3DMaterialType) {
    LAKSticker3DMaterialTypeNormal = 0,
    LAKSticker3DMaterialTypeAR = 1
};

@interface LAKSticker3DMaterialTypeStringConverter : NSObject
+ (NSString *)toString:(LAKSticker3DMaterialType)sticker3DMaterialType;
+ (LAKSticker3DMaterialType)fromString:(NSString *)string;
@end

NS_ASSUME_NONNULL_END

