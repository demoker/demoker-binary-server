/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKHairColor.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKHairColorItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKHairColor : LAKComponent

@property(nonatomic, strong) NSArray<LAKHairColorItem *> *effectList;

/**
 * Comments extracted from cpp files:
 *
 * 染发分割资源图
 */
@property(nonatomic, strong) NSString *hairMask;

/**
 * Comments extracted from cpp files:
 *
 * 阴阳分割mask图片
 */
@property(nonatomic, strong) NSString *yyMaskImage;

@end

NS_ASSUME_NONNULL_END

