﻿//
//  Face3DResult.h
//  人脸检测
//
// Created by zijunzhang on 2020/7/31.
// Copyright © 2020 tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/GYAIBase.h>

// 3dmm点、exp（表情参数的系数）最大数量，实际使用时，请根据变量点数量使用（此处使用最大数量申请内存）。
#define KGYAI_FACE_3DMM_POINT_MAX_NUM 2459  // 全头低模1827点；正常美妆只用全脸1220点；
#define KGYAI_FACE_3DMM_EXP_MAX_NUM 52
#define KGYAI_FACE_3DMM_RAW_EXP_MAX_NUM 46

#ifdef __cplusplus
extern "C" {
#endif

/* @brief 3dMM结构 通用的结构，为了兼容C++/OC改为C的结构，方便两边同时引用。
 * 涉及人脸id，表情系数（kapu），3D点（上妆、3d模型效果）
 * 下方参数都是算法结果的封装：使用时参考算法的文档，或者询问算法同学。
 * */
typedef struct GYAIFace3DResult {
  int trace_id;
  float transMatrix[4][4];  // SCNMatrix4
  float transform[4][4];
  float euler[3];           // pitch, yaw, roll
  float translate[2];       // CGPoint
  float scale;              // GLfloat
  float point_scale;

  size_t expNum, rawExpNum, facekitVertexNum;
  float exp[KGYAI_FACE_3DMM_EXP_MAX_NUM];          // 表情系数：需要参考数量取值
  float raw_exp[KGYAI_FACE_3DMM_RAW_EXP_MAX_NUM];  // 原始46基底的表情系数，用于触发判定
  float facekitVertices[KGYAI_FACE_3DMM_POINT_MAX_NUM * 3];  // 需要参考数量取值

  bool is_kissing;  // 是否嘟嘴
} GYAIFace3DResult;

#ifdef __cplusplus
}  // end of extern "C"
#endif
