/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKImage.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKPAGScaleMode.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKImage : LAKComponent

@property(nonatomic, assign) LAKPAGScaleMode scaleMode;

@property(nonatomic, assign) NSInteger duration;

@property(nonatomic, assign) BOOL loop;

/**
 * Comments extracted from cpp files:
 *
 * 统一是用src去LoadResourceFromKey加载
 */
@property(nonatomic, strong) NSString *src;

@end

NS_ASSUME_NONNULL_END

