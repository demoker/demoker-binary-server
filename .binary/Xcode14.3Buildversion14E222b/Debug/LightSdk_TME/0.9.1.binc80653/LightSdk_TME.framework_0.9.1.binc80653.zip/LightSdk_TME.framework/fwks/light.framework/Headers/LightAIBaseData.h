//
//  LightAIBaseData.h
//  light
//
//  Created by zebiaohuang on 2021/4/6.
//

#import <Foundation/Foundation.h>
#import "LightAIBaseFeature.h"

NS_ASSUME_NONNULL_BEGIN

/// 基类，代表检测能力输出的检测数据集合
/// 对应 XXXManager，如 Face2DInfoManager
@interface LightAIBaseData : NSObject

/// 对应数据的 agent type
@property (nonatomic, strong) NSString *key;

/// 以具体可被识别单元区分，如多个人脸，则有多个 feature
@property (nonatomic, strong) NSArray<LightAIBaseFeature*> *features;

/// 检测图片大小
@property (nonatomic, assign) CGSize detectImageSize;

/// 相机输入大小
@property (nonatomic, assign) CGSize cameraSize;

/// 渲染大小
@property (nonatomic, assign) CGSize renderSize;

/// 判断内部数据是否有效
@property (nonatomic, assign, readonly) BOOL isEmpty;

/// 通过 sdk 的 c++ 数据结构初始化
/// @param info void *，根据不同的 agent 返回的数据来处理
- (instancetype)initWithRawInfo:(void *)info;

/// 生成 sdk 的 c++ 数据结构返回
- (void *)convertToRawInfo;

@end

@interface LightAIDataUtility : NSObject

+ (LightAIBaseData*)convertLightObjectToSpecifiedAIBaseData:(void *)info key:(NSString*)key;

@end

NS_ASSUME_NONNULL_END
