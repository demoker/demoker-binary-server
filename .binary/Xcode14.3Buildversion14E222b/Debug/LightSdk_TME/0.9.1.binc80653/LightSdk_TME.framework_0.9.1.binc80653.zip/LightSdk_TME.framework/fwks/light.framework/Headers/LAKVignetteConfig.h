/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKVignetteConfig.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKVignetteConfig : LAKSerializable

/**
 * Comments extracted from cpp files:
 *
 * 0 ~ 1
 */
@property(nonatomic, assign) float midPoint;

/**
 * Comments extracted from cpp files:
 *
 * 0 ~ 1
 */
@property(nonatomic, assign) float roundness;

/**
 * Comments extracted from cpp files:
 *
 * 0 ~ 1
 */
@property(nonatomic, assign) float feather;

@property(nonatomic, strong) NSString *color;

@property(nonatomic, assign) BOOL enable;

@end

NS_ASSUME_NONNULL_END

