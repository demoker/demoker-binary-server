/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKRandomGroup.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKRandomType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKRandomGroup : LAKComponent

@property(nonatomic, assign) LAKRandomType randomType;

@property(nonatomic, strong) NSArray<NSNumber *> *weights;

@property(nonatomic, strong) NSArray<NSNumber *> *selections;

@end

NS_ASSUME_NONNULL_END

