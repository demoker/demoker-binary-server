/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKAnimationClip.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKAnimationClipState.h"
#import "LAKAnimationClipType.h"
#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKAnimationClip : LAKSerializable

@property(nonatomic, assign) LAKAnimationClipType type;

@property(nonatomic, assign) LAKAnimationClipState state;

@property(nonatomic, assign) NSInteger duration;

@property(nonatomic, assign) NSInteger progress;

@property(nonatomic, assign) NSInteger startTime;

@property(nonatomic, strong) NSString *name;

/**
 * Comments extracted from cpp files:
 *
 * Component 动画对应 动画 JSON 文件 Key
 * glTF 动画对应 glTF 文件 Key
 */
@property(nonatomic, strong) NSString *resourceKey;

@property(nonatomic, assign) NSInteger resourceVersion;

@property(nonatomic, assign) NSInteger clipIndex;

@end

NS_ASSUME_NONNULL_END

