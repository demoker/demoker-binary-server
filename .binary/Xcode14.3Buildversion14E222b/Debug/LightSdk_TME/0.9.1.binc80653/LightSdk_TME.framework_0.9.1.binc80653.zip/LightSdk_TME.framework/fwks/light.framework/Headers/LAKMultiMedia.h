/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMultiMedia.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKBackgroundFillMode.h"
#import "LAKComponent.h"
#import "LAKPAGScaleMode.h"
#import "LAKSize.h"
#import "LAKVolumeEffect.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMultiMedia : LAKComponent

@property(nonatomic, assign) float fillScale;

@property(nonatomic, assign) float volume;

@property(nonatomic, assign) float speed;

/**
 * Comments extracted from cpp files:
 *
 * 用户素材背景填充模式：单选，选项为高斯模糊和纯色填充，选择纯色填充时，需要能够取色/填写色值
 */
@property(nonatomic, assign) LAKBackgroundFillMode backgroundFillMode;

/**
 * Comments extracted from cpp files:
 *
 * 纯色填充颜色,格式：RGBA，示例：#ff0911df
 */
@property(nonatomic, strong) NSString *backgroundColor;

@property(nonatomic, assign) BOOL fixedBackground;

@property(nonatomic, assign) NSInteger imageEffect;

@property(nonatomic, strong) LAKSize *size;

@property(nonatomic, strong) NSArray<LAKVolumeEffect *> *volumeEffects;

@property(nonatomic, assign) LAKPAGScaleMode scaleMode;

/**
 * Comments extracted from cpp files:
 *
 * 统一是用src去LoadResourceFromKey加载
 */
@property(nonatomic, strong) NSString *src;

@end

NS_ASSUME_NONNULL_END

