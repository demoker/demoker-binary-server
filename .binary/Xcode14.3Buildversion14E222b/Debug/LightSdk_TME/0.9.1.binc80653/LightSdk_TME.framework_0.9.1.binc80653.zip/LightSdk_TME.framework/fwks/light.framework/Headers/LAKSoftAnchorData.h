/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKSoftAnchorData.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKSoftAnchorData : LAKSerializable

@property(nonatomic, assign) NSInteger anchor_target_;

@property(nonatomic, strong) NSArray<NSNumber *> *anchor_node_indices_;

@end

NS_ASSUME_NONNULL_END

