/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKReplaceItem.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKReplaceType.h"
#import "LAKScaleMode.h"
#import "LAKSerializable.h"
#import "LAKTextReplaceItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKReplaceItem : LAKSerializable

@property(nonatomic, assign) NSInteger index;

@property(nonatomic, strong) NSString *src;

@property(nonatomic, assign) LAKReplaceType replaceType;

@property(nonatomic, assign) NSInteger sourceIndex;

@property(nonatomic, assign) NSInteger textMaxLength;

@property(nonatomic, assign) LAKScaleMode scaleMode;

@property(nonatomic, assign) BOOL interactive;

@property(nonatomic, strong) LAKTextReplaceItem *textReplaceItem;

@property(nonatomic, strong) NSString *layerName;

@end

NS_ASSUME_NONNULL_END

