/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKVec2.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKVec2 : LAKSerializable

@property(nonatomic, assign) float x;

@property(nonatomic, assign) float y;

@end

NS_ASSUME_NONNULL_END

