/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKPaint.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKPaint : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 通过#RRGGBBAA指定涂抹的画布颜色，默认#00000000
 */
@property(nonatomic, strong) NSString *canvasColor;

/**
 * Comments extracted from cpp files:
 *
 * 通过#RRGGBBAA指定涂抹的笔刷颜色，默认#FFFFFFFF
 */
@property(nonatomic, strong) NSString *brushColor;

/**
 * Comments extracted from cpp files:
 *
 * 涂抹笔触大小, 像素值
 */
@property(nonatomic, assign) NSInteger brushSize;

/**
 * Comments extracted from cpp files:
 *
 * 涂抹笔触样式图片(png，不支持pag)
 */
@property(nonatomic, strong) NSString *brushImage;

/**
 * Comments extracted from cpp files:
 *
 * 涂抹遮罩生成的RenderTarget
 */
@property(nonatomic, strong) NSString *renderTarget;

/**
 * Comments extracted from cpp files:
 *
 * 画笔模式，参考AEPaintMode
 */
@property(nonatomic, assign) NSInteger paintMode;

@end

NS_ASSUME_NONNULL_END

