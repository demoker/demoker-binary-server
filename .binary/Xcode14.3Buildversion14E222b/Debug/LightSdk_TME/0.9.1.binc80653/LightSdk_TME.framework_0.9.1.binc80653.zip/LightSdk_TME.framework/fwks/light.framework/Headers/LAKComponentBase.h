/**
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKComponentBase.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: rickshe
 */

#import <Foundation/Foundation.h>
#import "LAKSerializable.h"

#define kLAKComponentTypeKey @"type"

// 监听 SDK 层 Component 变化的代理
@class LAKComponentBase;
@protocol LAKComponentSDKChangeDelegate <NSObject>

- (void)onLAKComponentSDKChange:(LAKComponentBase *)component;

@end

@interface LAKComponentBase : LAKSerializable

+ (NSString *)type;

- (NSString *)type;

@property (nonatomic, weak) id<LAKComponentSDKChangeDelegate> sdkChangeDelegate;

@end

