/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKHeadInset.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKHeadInset : LAKComponent

@property(nonatomic, strong) NSString *renderTarget;

/**
 * Comments extracted from cpp files:
 *
 * 是否矫正
 */
@property(nonatomic, assign) BOOL isCorrected;

@property(nonatomic, assign) float blurRadius;

@end

NS_ASSUME_NONNULL_END

