/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKMarkerTrackingComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKMarkerTrackingComponent : LAKComponent

@property(nonatomic, strong) NSString *imageMarker;

@end

NS_ASSUME_NONNULL_END

