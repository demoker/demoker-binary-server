//
//  LightAIBaseFeature.h
//  light
//
//  Created by zebiaohuang on 2021/4/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 基类，代表单个检测数据结果
/// 如检测数据是多人脸，则代表单个人脸数据结构
/// 对应 XXXInfo，如 Face2DInfo
@interface LightAIBaseFeature : NSObject

/// 通过 sdk 的 c++ 数据结构初始化
/// @param info void *，根据不同的 agent 返回的数据来处理
- (instancetype)initWithRawInfo:(void *)info;

/// 生成 sdk 的 c++ 数据结构返回
- (void *)convertToRawInfo;

@end

NS_ASSUME_NONNULL_END
