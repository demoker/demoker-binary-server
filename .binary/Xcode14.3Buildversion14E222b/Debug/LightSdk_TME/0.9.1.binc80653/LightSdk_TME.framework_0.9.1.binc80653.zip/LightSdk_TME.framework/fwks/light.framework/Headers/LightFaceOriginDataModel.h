//
//  LightFaceOriginDataModel.h
//
//  Created by rickshe on 2020/11/7.
//  Copyright © 2020 ddd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LightFaceOriginDataModel : NSObject

// 人脸标识
@property (nonatomic, assign) int trace_id;

//以下是为配合
@property(nonatomic,strong) NSArray *facePoint;

@property(nonatomic,strong) NSArray *facePointVisible;

@property(nonatomic,assign) float pitch;

@property(nonatomic,assign) float yaw;

@property(nonatomic,assign) float roll;

@property(nonatomic,assign) float cls;

- (NSData *)encode;

- (instancetype)initWithData:(NSData *)data;

+ (NSArray <LightFaceOriginDataModel *> *)arrayWithData:(NSData *)data;

@end

NS_ASSUME_NONNULL_END
