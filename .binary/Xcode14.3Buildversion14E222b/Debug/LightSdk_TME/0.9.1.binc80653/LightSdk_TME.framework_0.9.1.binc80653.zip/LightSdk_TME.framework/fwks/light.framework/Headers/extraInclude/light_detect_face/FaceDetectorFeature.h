﻿//  FaceDetectorFeature.h
//  人脸检测
//
// Created by zijunzhang on 2020/7/31.
// Copyright © 2020 tencent. All rights reserved.
//

#pragma once

#include <YTFaceAlignment/yt_common.h>
#include <light_ai_base/GYAIBase.h>
#include <light_detect_face/Face3DResult.h>
#include <light_detect_face/FaceDetectorFeaturePerspective.h>
#include <memory>
#include <vector>

#define FACE_FEATURE_POINT_NUM 83
#define FACE_FEATURE_POINT_256 256

// 新版本人脸识别点数量是94，在旧版本90个点基础上增加了4个瞳孔点
#define GYAI_FACE_ORIGIN_FEATURE_POINT_NUM 94
#define kYoutuDetectorFaceFeaturePointsCount 94

GYAILIB_NAMESPACE_START

using Face3DResult = GYAIFace3DResult;  // 3DMM点，兼容以前结构加的重定义
using FaceDetectorFeaturePerspective = GYAIFaceFeaturePerspective;  // 3D点，兼容以前结构加的重定义

class FaceDetectorFeature : public DetectBaseParams {
 public:
  explicit FaceDetectorFeature(int track_id = -1, float w = 0, float h = 0);
  ~FaceDetectorFeature();

#pragma mark - DetectFeatureProtocol
  // 接口扩展：如获取默认 DetectFeatureProtocol-feature
  size_t GetFeaturesCount() override { return 1; }
  DetectFeatureProtocol *GetFeatureAtIndex(int idx) override { return this; }
  size_t GetFeaturePointCount(int index) override { return FACE_FEATURE_POINT_256; }
  GYPoint4fPtr GetFeaturePoint4f(int index) override { return nullptr; }
  GYPoint2fPtr GetFeaturePoint2f(int index) override { return f_features_256; }
  GYAIRect4f GetFeatureFrame(int index) override {
    return GYAIRect4fMake(bounds.x, bounds.y, bounds.width, bounds.height);
  }



  // 指向点坐标(二维)的指针: 返回指针指向的是内部二维点数组（结构释放后不可使用）。
  const GYPoint2fPtr GetFeatures(bool is_point_origin = false) {
    return is_point_origin ? f_features_youtu_origin : f_features;
  }

  const float *GetFeatureVisibility(bool is_point_origin = false) {
    return is_point_origin ? f_features_youtu_visibility : f_feature_visibility;
  }

  const size_t GetFeatureCount(bool is_point_origin = false) {
    return is_point_origin ? GYAI_FACE_ORIGIN_FEATURE_POINT_NUM : FACE_FEATURE_POINT_NUM;
  }

  const GYPoint2fPtr GetFeature256() { return f_features_256; }

  const float *GetFeature256Visibility() { return f_features_256_visibility; }

  size_t GetFeature256Count() const { return refine_enable ? FACE_FEATURE_POINT_256 : 0; }

  /* @brief 根据矩阵旋转所有的点和框（旋转后当前的参数将更改）。
   * @params imgW/imgH只有大于0，才会更新image_width/height；否则（默认）不更新。
   * 备注：欧拉角只有roll值会被更改；不会改变内部的3D点(因为3D点无法旋转正确)。
   * */
  void ApplyTransform(const GYAffineTransform &t, float imgW = -1, float imgH = -1);
  void UpdateFaceShape(yt_face_shape *faceShape, bool position_correct = false);
  void UpdatePointsWithShape(yt_face_shape *faceShape);

  // 是否开启了refine状态（内部检测时候赋值，外界只可以获取）
  bool GetRefineEnable() const { return refine_enable; }

  yt_rect bounds;
  yt_rect leBounds;
  yt_rect reBounds;
  yt_rect mouthBounds;
  bool hasOutline;
  float pitch, yaw, roll;  // 基于世界坐标系的欧拉角，通常基于图片左上角坐标计算的结果
  // 基于人脸坐标系的欧拉角，此时roll接近为0，可用于判断摇头、点头等操作。
  float pitchFixed, yawFixed, rollFixed;

  // 人脸各部件高可见度点位占比
  float leftEyeHighVisRatio;
  float rightEyeHighVisRatio;
  float leftEyebrowHighVisRatio;
  float rightEyebrowHighVisRatio;
  float mouthHighVisRatio;

  std::shared_ptr<FaceDetectorFeaturePerspective> feature_perspective_;
  std::shared_ptr<Face3DResult> facekit3DResult;

  float f_features_youtu_visibility[GYAI_FACE_ORIGIN_FEATURE_POINT_NUM];
  float f_features_youtu_origin[GYAI_FACE_ORIGIN_FEATURE_POINT_NUM][2];
  float f_feature_visibility[FACE_FEATURE_POINT_NUM];
  float f_features[FACE_FEATURE_POINT_NUM][2];
  float f_features_256_visibility[FACE_FEATURE_POINT_256];
  float f_features_256[FACE_FEATURE_POINT_256][2];

  void ConvertPoint94ToPoint83();

 private:
  bool Outlined();
  bool refine_enable = false;  // 如果开启refine检测结果，该值会true，此时256点才有意义
};

// 判断shape是否为refine的256点 (根据眼睛点的数量来，refine=16点，普通版为8个点)
static inline bool GYYTFaceShapeIsRefine256(const yt_face_shape *faceShape) {
  return faceShape != nullptr && faceShape->eye_size >= 16;
}

// 将youtu-rect进行旋转，并返回旋转后的结果。
static inline yt_rect GYYTRectApplyTransform(yt_rect rect, const GYAffineTransform &t) {
  GYAIRect4f rect4f = GYAIRect4fMake(rect.x, rect.y, rect.width, rect.height);
  rect4f = GYAIRect4fApplyTransform(rect4f, t);
  rect.x = rect4f.x;
  rect.y = rect4f.y;
  rect.width = rect4f.w;
  rect.height = rect4f.h;
  return rect;
}

GYAILIB_NAMESPACE_END
