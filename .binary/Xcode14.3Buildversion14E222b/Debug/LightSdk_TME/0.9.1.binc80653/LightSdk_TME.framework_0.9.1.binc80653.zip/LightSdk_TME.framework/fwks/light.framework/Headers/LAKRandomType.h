/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKRandomType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKRandomType) {
    LAKRandomTypeNone = 0,
    LAKRandomTypeRandom = 1,
    LAKRandomTypeOrder = 2,
    LAKRandomTypeCustomOrder = 3
};

NS_ASSUME_NONNULL_END

