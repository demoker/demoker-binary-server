//
//  LightErrorCode.h
//  light-sdk
//
//  Created by zongyang on 2021/7/22.
//

#ifndef ERRORCODE_H
#define ERRORCODE_H

typedef NS_ENUM(NSInteger, LightErrorCode) {
    LightNoError = 0,
    // unknown
    LightUnknown = -1,
    // 模板path异常
    LightTemplateJsonPathEmpty = -2,
    // 3D引擎资源不存在
    Light3DEngineResourceNotExists = -100,
    // 不支持GAN素材
    LightGANResourceNotSupport = -200,
    // 设备不支持此素材组件
    LightDeviceNotSupport = -300,
    // 模板json内容为空
    LightTemplateJsonEmpty = -400,
    // SDK版本低
    LightSDKVersionNotSupport = -500,
    // 不支持抠头
    LightHeadInsetResourceNotSupport = -600,
    // 不支持OpenCL
    LightAndroidOpenCLNotSupport = -700,
    // 不支持脚本
    LightJavaScriptNotSupport = -800,
    // 不支持被裁剪的组件
    LightCutComponentsNotSupport = -900,
    // 不支持被裁剪的组件
    FilamentNotSupport = -1100
};

#endif
