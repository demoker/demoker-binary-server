/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKPrimitiveConfig.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKPrimitiveConfig : LAKSerializable

/**
 * Comments extracted from cpp files:
 *
 * [serialization]
 */
@property(nonatomic, assign) NSInteger primitiveIndex;

@property(nonatomic, assign) BOOL receiveShadow;

@property(nonatomic, assign) BOOL castShadow;

@property(nonatomic, assign) BOOL frustumCulling;

@property(nonatomic, strong) NSString *materialResourceKey;

@property(nonatomic, strong) NSString *meshResourceKey;

/**
 * Comments extracted from cpp files:
 *
 * blendOrder is valid between 0 to 7. (4 is default)
 */
@property(nonatomic, assign) NSInteger blendOrder;

@end

NS_ASSUME_NONNULL_END

