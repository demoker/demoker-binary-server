/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKScreenTransform.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKBasicTransform.h"
#import "LAKRect.h"
#import "LAKVec2.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKScreenTransform : LAKBasicTransform

/**
 * Comments extracted from cpp files:
 *
 * 锚定矩形的计算基于父节点的区域，用于定位entity位置。
 * 其中，0表示父节点的锚点位置，1或者-1表示父节点的边界（1/-1需要根据方位来定）。
 * 整体坐标系以右方与上方为正。
 * 具体来说，top=1.0指entity的top与parent中心点(center
 * point)的距离为parent的top与parent中心点(center point)的距离
 * bottom=-0.5指entity的bottom与parent的中心点(center
 * point)距离为parent的bottom与parent中心点(center point)的距离的一半
 * right=0指entity的right与parent的中心点(center point)重合
 * left=-2指entity的left与parent的中心点(center point)距离为parent的bottom与parent中心点(center
 * point)的距离的两倍
 */
@property(nonatomic, strong) LAKRect *anchor;

/**
 * Comments extracted from cpp files:
 *
 * 在锚定矩阵之后，支持固定大小的offset用于改变锚定矩阵。
 * 整个屏幕的高分为1280个单位长度，left,right,top,bottom均基于该值计算
 */
@property(nonatomic, strong) LAKRect *offset;

/**
 * Comments extracted from cpp files:
 *
 * 锚点基于中心点的偏移坐标(-1, -1)是左下角, (0, 0)为中心点, (1, 1)是右上角
 */
@property(nonatomic, strong) LAKVec2 *pivot;

@end

NS_ASSUME_NONNULL_END

