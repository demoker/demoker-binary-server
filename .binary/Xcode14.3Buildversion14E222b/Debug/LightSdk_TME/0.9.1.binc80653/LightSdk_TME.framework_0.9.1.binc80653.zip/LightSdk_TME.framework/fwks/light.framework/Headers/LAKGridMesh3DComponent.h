/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKGridMesh3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKVec3.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKGridMesh3DComponent : LAKComponent

@property(nonatomic, assign) NSInteger gridNum;

@property(nonatomic, strong) LAKVec3 *eye;

@property(nonatomic, strong) LAKVec3 *center;

@property(nonatomic, strong) LAKVec3 *up;

@end

NS_ASSUME_NONNULL_END

