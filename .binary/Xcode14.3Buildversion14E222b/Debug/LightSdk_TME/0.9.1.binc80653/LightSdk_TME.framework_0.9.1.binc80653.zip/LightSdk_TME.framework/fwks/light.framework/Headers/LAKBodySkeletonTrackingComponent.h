/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBodySkeletonTrackingComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKBodySkeletonTrackingComponent : LAKComponent

@property(nonatomic, strong) NSString *config_file;

@property(nonatomic, strong) NSString *smpl_model_file;

/**
 * Comments extracted from cpp files:
 *
 * Mesh瘦腰
 */
@property(nonatomic, assign) float slim_waist_mesh;

/**
 * Comments extracted from cpp files:
 *
 * Mesh长腿
 */
@property(nonatomic, assign) float long_leg_mesh;

/**
 * Comments extracted from cpp files:
 *
 * Mesh瘦手臂
 */
@property(nonatomic, assign) float slim_arm_mesh;

/**
 * Comments extracted from cpp files:
 *
 * Mesh瘦腿
 */
@property(nonatomic, assign) float slim_leg_mesh;

/**
 * Comments extracted from cpp files:
 *
 * 图像瘦腰
 */
@property(nonatomic, assign) float slim_waist;

/**
 * Comments extracted from cpp files:
 *
 * 图像长腿
 */
@property(nonatomic, assign) float long_leg;

/**
 * Comments extracted from cpp files:
 *
 * 图像瘦手臂
 */
@property(nonatomic, assign) float slim_arm;

/**
 * Comments extracted from cpp files:
 *
 * 图像瘦腿
 */
@property(nonatomic, assign) float slim_leg;

@property(nonatomic, strong) NSString *maskResource;

@property(nonatomic, strong) NSString *renderTarget;

@property(nonatomic, strong) NSString *fireRenderTarget;

@property(nonatomic, assign) BOOL enable_cut_body_index;

@property(nonatomic, assign) float x_offset_scale;

@property(nonatomic, assign) float y_offset_scale;

@property(nonatomic, assign) BOOL use_gpu_inpainting;

/**
 * Comments extracted from cpp files:
 *
 * 0是只支持火焰，1是只支持inpainting，2是其他都关闭
 */
@property(nonatomic, assign) float render_type;

/**
 * Comments extracted from cpp files:
 *
 * 是否打开额外的头模算法进行校正
 */
@property(nonatomic, assign) BOOL use_head_alg;

@property(nonatomic, assign) NSInteger queue_size;

@end

NS_ASSUME_NONNULL_END

