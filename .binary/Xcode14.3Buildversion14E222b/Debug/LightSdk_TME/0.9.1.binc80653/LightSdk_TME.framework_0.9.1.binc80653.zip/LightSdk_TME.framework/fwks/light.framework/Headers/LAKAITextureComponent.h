/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKAITextureComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKAITextureComponent : LAKComponent

@property(nonatomic, strong) NSString *aiType;

@property(nonatomic, strong) NSString *aiInputType;

@property(nonatomic, assign) BOOL isRealTimeResult;

/**
 * Comments extracted from cpp files:
 *
 * 输入RT (表情迁移使用)
 */
@property(nonatomic, strong) NSString *inputRenderTarget;

/**
 * Comments extracted from cpp files:
 *
 * 资源文件 (表情迁移使用)
 */
@property(nonatomic, strong) NSString *resourcePath;

/**
 * Comments extracted from cpp files:
 *
 * 表情迁移输出帧率
 */
@property(nonatomic, assign) NSInteger fps;

/**
 * Comments extracted from cpp files:
 *
 * 是否预加载 (表情迁移使用)
 */
@property(nonatomic, assign) BOOL preLoad;

/**
 * Comments extracted from cpp files:
 *
 * 输出RT列表
 */
@property(nonatomic, strong) NSArray<NSString *> *renderTargetList;

@property(nonatomic, strong) NSDictionary *aiTextureInputParams;

@property(nonatomic, strong) NSDictionary *aiTextureOutputParams;

@end

NS_ASSUME_NONNULL_END

