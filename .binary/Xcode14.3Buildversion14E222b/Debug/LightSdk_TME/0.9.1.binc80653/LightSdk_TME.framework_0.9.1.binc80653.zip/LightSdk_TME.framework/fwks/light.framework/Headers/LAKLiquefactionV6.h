/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKLiquefactionV6.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKLiquefactionParam.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKLiquefactionV6 : LAKComponent

@property(nonatomic, strong) NSArray<LAKLiquefactionParam *> *liquefactionParams;

@property(nonatomic, assign) BOOL editMode;

/**
 * Comments extracted from cpp files:
 *
 * 大眼使用到液化v6，这里是叠加程度值，做成素材可配
 */
@property(nonatomic, assign) float enlargeeyeFactor;

@end

NS_ASSUME_NONNULL_END

