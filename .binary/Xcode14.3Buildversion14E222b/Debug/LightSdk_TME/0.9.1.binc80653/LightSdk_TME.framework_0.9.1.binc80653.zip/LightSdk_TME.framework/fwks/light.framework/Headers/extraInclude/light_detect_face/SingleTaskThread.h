﻿//
//  SingleTaskThread.h
//  人脸检测
//
// Created by zijunzhang on 2020/7/31.
// Copyright © 2020 tencent. All rights reserved.
//

#pragma once

#include <future>
#include <memory>
#include <queue>
#include <string>
#include <thread>
#include <unordered_map>
#ifdef WIN32
#define _GLIBCXX_HAS_GTHREADS
#endif
GYAILIB_NAMESPACE_START

class TaskConfig {};

class DetectorTask {
 public:
  virtual std::string type() = 0;

  virtual void runTask() = 0;

  explicit DetectorTask(std::shared_ptr<TaskConfig> config) : detector_config_(config) {}

  virtual ~DetectorTask() { GYAILogD("~DetectorTask"); }

  void updateConfig(std::shared_ptr<TaskConfig> config) { detector_config_ = config; }

 protected:
  std::shared_ptr<TaskConfig> detector_config_ = nullptr;
};

class SingleTaskThread {
 public:
  explicit SingleTaskThread(std::string threadName)
      : stop_(false), single_thread_name_(threadName) {
    tasks_ = std::make_shared<std::queue<std::shared_ptr<DetectorTask>>>();
    single_thread_ = std::make_shared<std::thread>([this] {
      // 从队列中拿任务的逻辑
      GYAILogD("start thread : %s\n", single_thread_name_.c_str());
#ifdef __APPLE__
      pthread_setname_np(this->single_thread_name_.c_str());
#else
#ifndef WIN32
      pthread_setname_np(pthread_self(), this->single_thread_name_.c_str());
#endif
#endif
      while (!this->stop_) {
        std::shared_ptr<DetectorTask> task;
        {
          std::unique_lock<std::mutex> lock(this->queue_mutex_);
          this->condition_.wait(lock, [this] {
            return this->stop_ || !this->tasks_->empty();  // ??
          });
          if (this->stop_ && this->tasks_->empty()) break;
          task = this->tasks_->front();
          this->tasks_->pop();  // 可考虑回收
        }
        if (task != nullptr) {
          task->runTask();
          task = nullptr;
        }
      }
    });
  }

  void postTask(std::shared_ptr<DetectorTask> task) {
    std::unique_lock<std::mutex> lock(queue_mutex_);

    // don't allow enqueueing after stopping the pool
    if (stop_) {
      GYAILogD("%s : enqueue on stopped ThreadPool", single_thread_name_.c_str());
      return;
    }

    // 新任务到来时，已经入队并且没有执行的任务就没有意义了，需要丢弃，这是和人脸检测异步业务关联的
    while (!tasks_->empty()) {
      tasks_->pop();
    }
    tasks_->push(task);
    condition_.notify_one();
  }

  void removeAllTasks() {
    std::unique_lock<std::mutex> lock(queue_mutex_);

    while (!tasks_->empty()) {
      tasks_->pop();
    }
  }

  ~SingleTaskThread() {
    GYAILogD("SingleTaskThreadd. start.");
    {
      std::unique_lock<std::mutex> lock(queue_mutex_);
      stop_ = true;
    }
    condition_.notify_all();
    GYAILogD("SingleTaskThreadd. end.");
    single_thread_->join();  // 等待结束
    single_thread_ = nullptr;
    if (tasks_ != nullptr) {
      while (!tasks_->empty()) {
        tasks_->pop();
      }
    }
  }

 private:
  std::shared_ptr<std::thread> single_thread_ = nullptr;
  std::shared_ptr<std::queue<std::shared_ptr<DetectorTask>>> tasks_ = nullptr;
  // synchronization
  std::mutex queue_mutex_;
  std::condition_variable condition_;
  bool stop_;
  std::string single_thread_name_;
};

GYAILIB_NAMESPACE_END
