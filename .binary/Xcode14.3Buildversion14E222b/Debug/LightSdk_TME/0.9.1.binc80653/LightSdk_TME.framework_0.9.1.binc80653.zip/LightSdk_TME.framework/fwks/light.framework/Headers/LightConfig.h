// Copyright 2020 Tencent Inc. All Rights Reserved.
//  LightConfig.h
//  light
//
//  Created by 吕所军 on 2020/8/27.
//

#ifndef PLATFORM_IOS_LIGHTCONFIG_H_
#define PLATFORM_IOS_LIGHTCONFIG_H_

#import <Foundation/Foundation.h>
#import "LightConstants.h"
#import "Definitions.h"
#import "LightListeners.h"
#import "LightAIData.h"
#import "LightDeviceUtil.h"


@interface Texture : NSObject
@property (nonatomic, assign) NSInteger id;
@property (nonatomic, assign) NSInteger width;
@property (nonatomic, assign) NSInteger height;
@end

@interface LightConfig : NSObject
/**
 此接口只能给微视动态库使用，其他业务调用会失败
 */
+ (int)AuthForDymanicLib;
/**
 todo configData是否要做隔离!
 */

/** todo
 获取并查看已经设置了的configData
 */
- (NSDictionary<NSString *, NSString *>*)getConfigData;

/** todo
 设置跨素材的数据，切换素材之后会继续生效，业务层随时随地可以设置并生效
 eg: 美颜滑杆的值， AI的工作模式
 */
- (void)setConfigData:(NSDictionary<NSString *, NSString *>*)configData;

/// 设置renderSize
- (void)setRenderSize:(CGSize)size;

/// 设置相机水平Fov
- (void)setHorizontalFov:(float)horizontalFov;

/// 外挂渲染滤镜
- (void)setExternalRenderCallback:(void(^)(Texture *input, NSString *key, NSString *data, Texture *output))callback;

/// setOnClickWatermarkListener
- (void)setOnClickWatermarkListener:(id<LightClickWatermarkListener>)listener;

/// setWatermarkDataListener
- (void)setWatermarkDataListener:(id<LightWatermarkDataListener>)listener key:(NSString *)key;

/// registerFont
- (void)registerFont:(NSString *)fontFamily fontStyle:(NSString *)fontStyle fontPath:(NSString *)fontPath;

/// 人脸数据
- (LightFaceData *)getFaceData;

/// 设置外部人脸数据
- (void)setExternalFaceData:(LightFaceData *)faceData;

/// 清理AI缓存
- (void)clearAICachedData;

/// pause
- (void)onPause;

/// resume
- (void)onResume;

/// 设置AI路径(直接给定path、level、name)
- (void)setLightAIModelWithPath:(NSString *)modelPath
                 withModelLevel:(NSString *)modelLevel
                       forAgent:(NSString *)agentName;

/// 设置AI路径(给定path以及AgentBundleInfo结构体)
/// 同时会遍历设置所有的subFolders
- (void)setLightAIModelWithPath:(NSString *)modelPath
                AgentBundleInfo:(LightAgentBundleInfo *)info;

/// 是否同步创建某些功能的Processor，目前此接口仅对GAN有效，切默认为异步初始化
/// @param need 需要
/// @param agentName 模块名称
- (void)setSyncInitFlag:(BOOL)need
               forAgent:(NSString *)agentName;

// 设置检测大小，目前仅用于人脸，agentName可不填
- (void)setDetectShorterEdgeLength:(int)length
                          forAgent:(NSString *)agentName;

// 设置同步/异步渲染
- (void)setSyncMode:(BOOL)sync;


/// 获取当前支持的所有 agent 的 AI 数据
/// 目前支持 kFACE_AGENT, kHAND_AGENT, kBODY_AGENT, k3D_MM_AGENT 的获取
/// @param keyList 自定义批量获取的 key
/// @param dataType LightAIData 数据内容选项
- (LightAIDataWrapper*)getAIData:(NSArray<NSString*>*)keyList dataType:(LightAIDataType)dataType;

/// 替换内部的 AI 数据
/// @param data AI 数据
- (void)replaceAIData:(LightAIDataWrapper*)data;

/// 设置渲染策略
/// @param key 策略key值
/// @param level 策略枚举类型
- (void)setDowngradeStrategy:(NSString *)key deviceLevel:(int)level;

/**
 * Register font
 */
+ (void)RegisterFontWithAsset:(LightFontAsset*)fontAsset fontPath:(NSString*)fontPath;

/// 设置默认美颜版本号
/// @param version 版本号
- (void)setDefaultBeautyVersion:(LightDefaultBeautyVersion)version;

/// 控制 BGM
/// @param hidden
- (void)setBGMusicHidden:(bool)hidden;

/// 设置是否关闭渲染
/// @param disableRenderer
- (void)setDisableRendererFlag:(bool)disableRenderer;

/// 异常帧检测频率
- (void)setAbnormalFrameDetectFrequency:(int)frequency;

/// 获取关闭渲染的状态
- (BOOL)getDisableRendererFlag;

- (LightPerformanceData*)performanceData;

///设置 or 清理 提示语listener
- (void)setTipsStatusListener:(id<LightTipsStatusListener>)listener;

///设置 or 清理 脚本输出listener
- (void)setScriptOutputListener:(id<LightScriptOutputListener>)listener;

///设置 or 清理 ai data listener
- (void)setAIDataListener:(id<LightAIDataListener>)listener;

//设置 or 清理 AssetListener
- (void)setLoadAssetListener:(id<LightLoadAssetListener>)listener;

- (void)freeCache;

- (void)CleanFileCacheForKey:(NSString*)rootKey;

+ (void)cleanFileCacheFromRoot:(NSString*)rootPath;

- (void)setPreInitAgents:(NSArray<NSString *> *)preInitAgents;

/// 给定agentName，获取所需的ResourceBundle的level
+ (NSString*)getResourceBundleLevelNameByAgentName:(NSString*)agentName;

/// 给定agentName，获取所需的ResourceBundle的level，包含查询 LightCV 的过程
+ (NSString*)getResourceBundleLevelNameByAgentNameWithCV:(NSString*)agentName;

/// 根据agent获取AgentBundleInfo
+ (LightAgentBundleInfo *)getAgentBundleInfoByAgent:(NSString*)agentName;

/// 根据agent获取AgentBundleInfo，包含查询 LightCV 的过程
+ (LightAgentBundleInfo *)getAgentBundleInfoByAgentWithCV:(NSString*)agentName;

@end
#endif
