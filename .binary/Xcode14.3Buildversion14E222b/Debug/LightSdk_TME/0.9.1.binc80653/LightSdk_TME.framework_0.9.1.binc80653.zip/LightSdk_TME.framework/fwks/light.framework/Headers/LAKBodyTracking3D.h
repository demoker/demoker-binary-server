/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKBodyTracking3D.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKBodyTracking3D : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * [serialization]
 */
@property(nonatomic, assign) NSInteger followEntityId;

@property(nonatomic, strong) NSString *firstKeyPointName;

@property(nonatomic, strong) NSString *secondKeyPointName;

@property(nonatomic, assign) float smoothLevel;

@property(nonatomic, assign) BOOL followSpin;

@property(nonatomic, assign) BOOL syncSpin;

@property(nonatomic, assign) BOOL directionalScale;

@end

NS_ASSUME_NONNULL_END

