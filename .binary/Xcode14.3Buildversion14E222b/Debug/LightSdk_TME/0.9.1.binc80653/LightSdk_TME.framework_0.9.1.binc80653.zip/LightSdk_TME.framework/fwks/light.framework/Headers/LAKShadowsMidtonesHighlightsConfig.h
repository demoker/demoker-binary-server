/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKShadowsMidtonesHighlightsConfig.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"
#import "LAKVec4.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKShadowsMidtonesHighlightsConfig : LAKSerializable

/**
 * Comments extracted from cpp files:
 *
 * alpha 通道忽略，只是因为前端没有3通道RGB color组件
 */
@property(nonatomic, strong) NSString *shadowsColor;

/**
 * Comments extracted from cpp files:
 *
 * -2 ~ 2
 */
@property(nonatomic, assign) float shadowsWeight;

@property(nonatomic, strong) NSString *midtonesColor;

/**
 * Comments extracted from cpp files:
 *
 * -2 ~ 2
 */
@property(nonatomic, assign) float midtonesWeight;

@property(nonatomic, strong) NSString *highlightsColor;

/**
 * Comments extracted from cpp files:
 *
 * -2 ~ 2
 */
@property(nonatomic, assign) float highlightsWeight;

/**
 * Comments extracted from cpp files:
 *
 * 0 ~ 1
 */
@property(nonatomic, strong) LAKVec4 *ranges;

@end

NS_ASSUME_NONNULL_END

