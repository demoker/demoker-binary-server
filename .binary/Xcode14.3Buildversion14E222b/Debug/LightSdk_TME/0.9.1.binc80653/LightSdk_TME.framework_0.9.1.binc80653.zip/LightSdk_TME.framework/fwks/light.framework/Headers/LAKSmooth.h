/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKSmooth.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKSmoothSharpenType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKSmooth : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 磨皮强度
 */
@property(nonatomic, assign) float smooth;

/**
 * Comments extracted from cpp files:
 *
 * face color
 */
@property(nonatomic, assign) float faceColorAlpha;

/**
 * Comments extracted from cpp files:
 *
 * 锐化强度  // 默认锐化程度改成0.0（v6默认值）
 */
@property(nonatomic, assign) float sharpenStrength;

/**
 * Comments extracted from cpp files:
 *
 * 锐化强度  // 默认锐化程度改成0.0（v6默认值）
 */
@property(nonatomic, assign) float sharpenStrengthtme;

/**
 * Comments extracted from cpp files:
 *
 * 亮眼强度
 */
@property(nonatomic, assign) float brightenEyeStrength;

/**
 * Comments extracted from cpp files:
 *
 * 曝光度
 */
@property(nonatomic, assign) float exposureValue;

/**
 * Comments extracted from cpp files:
 *
 * 匀肤强度
 */
@property(nonatomic, assign) float averageSkinDegree;

/**
 * Comments extracted from cpp files:
 *
 * 锐化类型。目前仅fallback磨皮生效
 */
@property(nonatomic, assign) LAKSmoothSharpenType sharpenType;

@property(nonatomic, assign) NSInteger histogramMinVal;

@property(nonatomic, assign) NSInteger histogramMaxVal;

/**
 * Comments extracted from cpp files:
 *
 * 磨皮版本
 */
@property(nonatomic, strong) NSString *smoothVersion;

@property(nonatomic, assign) BOOL overallSmooth;

@end

NS_ASSUME_NONNULL_END

