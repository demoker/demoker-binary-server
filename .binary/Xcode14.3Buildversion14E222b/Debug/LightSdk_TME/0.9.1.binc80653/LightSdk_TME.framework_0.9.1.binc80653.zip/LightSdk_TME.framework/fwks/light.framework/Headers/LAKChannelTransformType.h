/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKChannelTransformType.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LAKChannelTransformType) {
    LAKChannelTransformTypekUnknown = 0,
    LAKChannelTransformTypekTranslation = 1,
    LAKChannelTransformTypekRotation = 2,
    LAKChannelTransformTypekScale = 3,
    LAKChannelTransformTypekWeights = 4
};

NS_ASSUME_NONNULL_END

