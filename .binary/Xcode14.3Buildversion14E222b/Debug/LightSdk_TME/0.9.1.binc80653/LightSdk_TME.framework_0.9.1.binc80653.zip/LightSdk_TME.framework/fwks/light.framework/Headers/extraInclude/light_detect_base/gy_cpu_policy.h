//
// Created by easonycwang on 2022/2/11.
// Copyright © 2021 Tencent. All rights reserved.
//
#pragma once

#ifdef __ANDROID__

#include <map>
#include <string>
#include <mutex>

// @brief ARM CPU绑核策略配置
class CpuPolicy {
 public:
  CpuPolicy();
  ~CpuPolicy();

  void Init();

  // @brief 根据传入的线程名称进行绑核配置
  void SetCpuAffinity(const std::string &thread_name);

  // @brief 解除绑核
  void ClrCpuAffinity(const std::string &thread_name);

 private:
  // @brief 加载所有注册过的线程绑核策略
  // 每个线程，对应不同的CPU架构有不同的绑核方法，可以手动配置mask
  // 绑核策略不对外暴露，需要手动修改
  void LoadCpuPolicy();

  // @brief 读取手机中/proc/cpuinfo的所有信息
  int ReadCpuInfo(std::string *info);

  // @brief 解析/proc/cpuinfo的信息，获取CPU核数信息
  void ParseCpuInfo(const std::string &cpu_info, std::map<std::string, int> *cpu_cnt);

  // @brief 根据解析出的CPU核数信息，判断正确的CPU架构类型
  void GetCpuType(const std::map<std::string, int> &cpu_cnt);

 private:
  // 静态变量，因为每部手机的CPU信息唯一，可以防止重复获取，节省资源
  static bool is_inited_;
  static int cpu_nums_;
  static int cpu_arch_;
  static std::mutex mtx;
};

#endif  // __ANDROID__
