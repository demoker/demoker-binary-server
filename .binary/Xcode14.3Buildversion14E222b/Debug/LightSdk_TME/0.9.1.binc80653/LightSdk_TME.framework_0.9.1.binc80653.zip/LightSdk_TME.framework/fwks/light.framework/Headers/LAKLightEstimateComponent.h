/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKLightEstimateComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"
#import "LAKLightEstimateType.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKLightEstimateComponent : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 序列化属性
 */
@property(nonatomic, assign) LAKLightEstimateType lightEstimateType;

@property(nonatomic, strong) NSString *renderTargetKey;

@property(nonatomic, strong) NSString *imagePath;

/**
 * Comments extracted from cpp files:
 *
 * 使用光照强度，区间在lightIntensityMax和lightIntensityMin
 * 当useLightIntensity 作用
 */
@property(nonatomic, assign) BOOL enableLightIntensity;

/**
 * Comments extracted from cpp files:
 *
 * 光照强度最大最小区间，支持用户编辑
 */
@property(nonatomic, assign) float lightIntensityMax;

@property(nonatomic, assign) float lightIntensityMin;

/**
 * Comments extracted from cpp files:
 *
 * 使用光照颜色
 */
@property(nonatomic, assign) BOOL enableLightColor;

/**
 * Comments extracted from cpp files:
 *
 * 使用光照方向
 */
@property(nonatomic, assign) BOOL enableLightDirection;

/**
 * Comments extracted from cpp files:
 *
 * 是否只采用脚本结果设置，当为ture时，light_estimate_system不会处理LightLumenEstimateAgent的result
 */
@property(nonatomic, assign) BOOL useScriptSet;

@end

NS_ASSUME_NONNULL_END

