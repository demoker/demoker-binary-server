/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKShadowConfig.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKSerializable.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKShadowConfig : LAKSerializable

/**
 * Comments extracted from cpp files:
 *
 * 阴影参数，是否投掷阴影, [DIRECTIONAL, SUN, SPOT, FOCUSED_SPOT]
 */
@property(nonatomic, assign) BOOL castShadows;

/**
 * Comments extracted from cpp files:
 *
 * 阴影参数，是否投掷阴影, [DIRECTIONAL, SUN, SPOT, FOCUSED_SPOT]
 */
@property(nonatomic, assign) NSInteger shadowMapSize;

@property(nonatomic, assign) BOOL stable;

/**
 * Comments extracted from cpp files:
 *
 * 阴影参数，控制偏移
 */
@property(nonatomic, assign) float constantBias;

/**
 * Comments extracted from cpp files:
 *
 * 阴影参数，控制偏移
 */
@property(nonatomic, assign) float normalBias;

/**
 * Comments extracted from cpp files:
 *
 * 阴影参数，控制偏移
 */
@property(nonatomic, assign) float polygonOffsetConstant;

/**
 * Comments extracted from cpp files:
 *
 * 阴影参数，控制偏移
 */
@property(nonatomic, assign) float polygonOffsetSlope;

@property(nonatomic, assign) NSInteger shadowCascades;

@end

NS_ASSUME_NONNULL_END

