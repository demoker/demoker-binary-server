/*
 * Copyright 2021 Tencent Inc. All Rights Reserved.
 *
 * LAKFur3DComponent.h
 * LightAssetKit自动生成的文件，不要直接修改
 *
 * Author: gallenshao
 */

#import "LAKComponent.h"

NS_ASSUME_NONNULL_BEGIN

@interface LAKFur3DComponent : LAKComponent

/**
 * Comments extracted from cpp files:
 *
 * 绒毛纹理的相对路径
 */
@property(nonatomic, strong) NSString *furFile;

@property(nonatomic, assign) BOOL furAutoScaling;

@end

NS_ASSUME_NONNULL_END

