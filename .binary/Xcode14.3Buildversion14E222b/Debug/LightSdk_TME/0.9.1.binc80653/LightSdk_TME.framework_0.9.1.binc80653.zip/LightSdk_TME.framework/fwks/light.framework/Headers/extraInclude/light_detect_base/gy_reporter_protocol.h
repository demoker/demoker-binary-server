﻿//
//  gy_reporter_protocol.h
//  用于LightCV的数据上报
//
//  Created by atilazhang on 2021/12/29.
//  Copyright © 2021 Tencent. All rights reserved.
//

#pragma once

#include <light_ai_base/GYAIBase.h>
#include <light_detect_base/GYDetectHandlerConfig.h>
// clang-format off
#include <light_detect_base/gy_reporter_def.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <ctime>
#include <functional>
#include <map>
#include <string>
#include <thread>
#include <vector>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
// clang-format on

#define CheckAndReportSetup(ret, time)                 \
  GYAIReturnIfFalse(ret == GYAIErrorCodeSuccess, ret); \
  ReportSetupModelCost(time)
#define CheckAndReportForward(ret, time, key)          \
  GYAIReturnIfFalse(ret == GYAIErrorCodeSuccess, ret); \
  AppendPerformance(key, time)

GYAILIB_NAMESPACE_START

typedef enum {
  kGYReporterTypeNA = -1,
  kGYReporterTypeFrameLatest = 0,
  kGYReporterTypeFrameAverage = 1,
  kGYReporterTypeTimeLatest = 2,
  kGYReporterTypeTimeAverage = 3
} GYReporterType;

class GYAI_PUBLIC GYReporterBase {
 public:
  GYReporterBase();

  virtual ~GYReporterBase() = default;

  void AppendPerformance(const std::string &key, float value);

  void ReportSetupModelCost(float cost);

  void ReportSetupModelCost(const std::string &key, float cost);

 private:
  void ReportPerformanceIfNeeded();

  void ReportPerformanceIfNeededByFrame();

  void ReportPerformanceIfNeededByTime();

  void ReportLatestPerformance();

  void ReportAveragePerformance();

 public:
  std::string event;
  GYReporterType reporter_type;  // 上报时机的类型
  int frame_interval;            // 帧间隔，即每隔多少帧上报一次
  int time_interval;             // 时间间隔，即每隔几秒上报一次

 private:
  int frame_counter;  // 帧数计数器
  time_t last_time;   // 上次上报的时间戳
  std::map<std::string, float> avg_performance_map;
  std::map<std::string, int> avg_performance_count_map;
  std::map<std::string, float> latest_performance_map;
};

GYAILIB_NAMESPACE_END
