//
//  light_ai_base_version.h
//
//  Copyright 2021 Tencent. All rights reserved.
//

#pragma once

static char *branch_name = "master";
static char *commit_date = "2021-12-24 09:55:30";
static char *commit_hash = "7340cb5";
