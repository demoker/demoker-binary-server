//
//  LightRenderer.h
//  Ishtar-Playground
//
//  Created by DCTang on 2021/7/12.
//  Copyright © 2021 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <OpenGLES/ES3/gl.h>
#import <light/light-umbrella.h>
#import <GPUImage/GPUImageOutput.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSInteger TmeLightRendererState NS_TYPED_ENUM;
/// `TmeLightRenderer` 未就绪
static TmeLightRendererState const TmeLightRendererStateIdle = 0;
/// `TmeLightRenderer` 播放中
static TmeLightRendererState const TmeLightRendererStatePlaying = 1;
/// `TmeLightRenderer` 暂停
static TmeLightRendererState const TmeLightRendererStatePause = 2;

@class TmeLightEffect, TmeLightDependencyBundle, TmeLightFilterSetting, TmeLightFaceRetouch, TmeLightFaceRetouchDowngrade;

@interface TmeLightRenderer : NSObject

@property (atomic, readonly) TmeLightRendererState state;

@property (nonatomic, readonly) TmeLightFaceRetouch *faceRetouch;

@property (nonatomic, readonly) TmeLightFaceRetouchDowngrade *faceRetouchDowngrade;

@property (nonatomic, readonly) LightEngine *lightEngine;
@property (nonatomic, readonly) LightCameraConfig *lightConfig;
@property (nonatomic, readonly) LightSurface *lightSurface;
@property (nonatomic, readonly) LightCameraController* lightCameraController;
@property(nonatomic, readonly) LightVideoOutput *lightVideoOutput;

+ (nullable instancetype)lightRenderWithSetting:(TmeLightFilterSetting *)setting
                                          error:(NSError **)error;

+ (nullable instancetype)lightRendererWithCrucialBundlePath:(NSString *)bundlePath
                                                    setting:(TmeLightFilterSetting *)setting
                                                      error:(NSError **)error __attribute__((deprecated("lightRenderWithSetting:error:")));

- (BOOL)applyEffect:(TmeLightEffect *)effect error:(NSError **)error;

- (BOOL)applyFaceRetouch:(TmeLightFaceRetouch *)faceRetouch error:(NSError **)error;

- (BOOL)applyFaceRetouchDowngrade:(TmeLightFaceRetouchDowngrade *)faceRetouchDowngrade error:(NSError **)error;

- (BOOL)applyDependencyBundles:(NSArray<TmeLightDependencyBundle *> *)bundles error:(NSError **)error;

- (void)sendEventWithName:(NSString *)name info:(NSDictionary *)info;

- (void)sendEventWithName:(NSString *)name detail:(NSString *)detail;

- (BOOL)applyLutWithFilePath:(nullable NSString *)lutFilePath identifier:(NSString *)identifier error:(NSError **)error;

- (void)modifyLutIntensity:(CGFloat)lutIntensity;

- (GLuint)processInputTexture:(GLuint)inputTexture;

- (void)preview;

- (void)pause;

- (void)reset;

@end

NS_ASSUME_NONNULL_END
