//
//  AnuYPVEBaseModel.h
//  OneBeat
//
//  Created by shawnyu on 2018/6/6.
//  Copyright © 2018年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TmeLightModel : NSObject <NSCoding>

- (void)encodeWithCoder:(NSCoder *)encoder;
- (id)initWithCoder:(NSCoder *)decoder;

@end
