//  --documented
//
//  TmeLightFilterSetting.h
//  Ishtar-Playground
//
//  Created by DCTang on 2021/7/15.
//  Copyright © 2021 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

NS_ASSUME_NONNULL_BEGIN

/// Light 滤镜配置
@interface TmeLightFilterSetting : NSObject

/// 分辨率，默认是 9:16 比例的 720p
@property (nonatomic, assign) CGSize resolution;
/// 预期帧率，默认是 30
@property (nonatomic, assign) float fps;
/// 是不是竖直旋转，默认是 NO
@property (nonatomic, assign) BOOL flipY;
/// 是否使用阉割降级版美颜，默认是 NO
@property (nonatomic, assign) BOOL useHighPerformanceFaceRetouch;
/// 异步调用接口延迟时间，默认是 200ms
@property (nonatomic, assign) float asyncEffectCompletionDalay;

/// lightSdk 证书路径
@property (nonatomic, readonly) NSString *licensePath;
/// lightSdk 关键资源路径
@property (nonatomic, readonly) NSString *crucialResourcePath;
/// lightSdk 接入唯一标识
@property (nonatomic, readonly) NSString *identifier;
/// lightSdk 接入上报唯一标识
@property (nonatomic, readonly) NSString *reportIdentifier;


/// 通过证书和关键资源路径初始化 `TmeLightFilterSetting`
/// @param licensePath lightSdk 证书路径
/// @param crucialResourcePath lightSdk 重要资源路径, 一个 bundle 文件
/// @param identifier 接入的唯一标识，这个请跟 light 团队申请
/// @param reportIdentifier 接入的上报唯一标识，这个请跟 light 团队申请
+ (nullable instancetype)makeWithLicensePath:(NSString *)licensePath
                         crucialResourcePath:(NSString *)crucialResourcePath
                                  identifier:(NSString *)identifier
                            reportIdentifier:(NSString *)reportIdentifier;

/// 生成一份默认配置
/// @note 该接口已废弃，请使用另一个 `makeWithLicensePath:crucialResourcePath:identifier:reportIdentifier:`
+ (instancetype)defaults __attribute((deprecated("Use the makeWithLicensePath:crucialResourcePath:identifier:reportIdentifier: instead.")));

@end

NS_ASSUME_NONNULL_END
