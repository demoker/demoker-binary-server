//
//  TmeLight.h
//
//  Created by DCTang on 2019/9/30.
//  Copyright © 2019 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TmeLight.
FOUNDATION_EXPORT double TmeLightVersionNumber;

//! Project version string for TmeLight.
FOUNDATION_EXPORT const unsigned char TmeLightVersionString[];

#ifndef _TMELIGHT_
#define _TMELIGHT_

#if TARGET_OS_IOS
    
#import <LightSdk-TME/TmeLightFilter.h>
#import <LightSdk-TME/TmeLightDependencyBundle.h>
#import <LightSdk-TME/TmeLightEffect.h>
#import <LightSdk-TME/TmeLightDefines.h>
#import <LightSdk-TME/TmeLightFaceRetouch.h>
#import <LightSdk-TME/TmeLightFaceRetouchDowngrade.h>
#import <LightSdk-TME/TmeLightFilterSetting.h>
#import <LightSdk-TME/TmeLightModel.h>
#import <LightSdk-TME/TmeLightRenderer.h>

#endif /* TARGET_OS_IOS */

#endif /* _TMELIGHT_ */
