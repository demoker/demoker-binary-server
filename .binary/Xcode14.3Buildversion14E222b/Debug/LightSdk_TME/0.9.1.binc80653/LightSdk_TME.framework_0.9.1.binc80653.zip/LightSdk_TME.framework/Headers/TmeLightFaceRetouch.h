//  --documented
//
//  TmeLightFaceRetouch.h
//  Anunnaki iOS
//
//  Created by DCTang on 2021/8/13.
//  Copyright © 2021 tencent. All rights reserved.
//
//  light 团队提供的映射表：https://docs.qq.com/sheet/DVFhsbkRjR2t1TVZ6?tab=l7nap5
//

#import <LightSdk-TME/TmeLightModel.h>
#import <QuartzCore/QuartzCore.h>

NS_ASSUME_NONNULL_BEGIN

@class TmeLightEffect;

/// LightSdk 美颜参数抽象
@interface TmeLightFaceRetouch : TmeLightModel
<
    NSCopying
>

// MARK: 磨皮

/// 磨皮，默认 0.6
@property (nonatomic, assign) CGFloat smooth;
/// 锐化，默认 0.05
@property (nonatomic, assign) CGFloat sharpness;
/// 曝光度，默认 0.5
@property (nonatomic, assign) CGFloat exposure;
/// 肤色美白，默认 0
@property (nonatomic, assign) CGFloat smoothWhiten;
/// 亮眼，默认为 0.5
@property (nonatomic, assign) CGFloat eyeBrighten;

// MARK: 美颜

/// 清晰，默认 0.2
@property (nonatomic, assign) CGFloat clearAlpha;
/// 对比度，默认 0
@property (nonatomic, assign) CGFloat contrast;
/// 美白，默认 0.3
@property (nonatomic, assign) CGFloat whiten;
/// 白牙，默认 0.2
@property (nonatomic, assign) CGFloat toothWhiten;
/// 法令纹，默认 0.3
@property (nonatomic, assign) CGFloat lawlineFade;
/// 黑眼圈，默认 0.5
@property (nonatomic, assign) CGFloat eyebagRemove;
/// 去皱，默认 0
@property (nonatomic, assign) CGFloat wrinkleRemove;
/// 肤色，默认 0
/// @note 范围 -1~1
@property (nonatomic, assign) CGFloat skinTone;
/// 去噪，默认 0
@property (nonatomic, assign) CGFloat denoise;

// MARK: 美型

/// 短脸，默认0
@property (nonatomic, assign) CGFloat shortFace;
/// 小脸，默认 0
@property (nonatomic, assign) CGFloat smallFace;
/// 大眼，默认 0.3
/// @note 范围 0~5
@property (nonatomic, assign) CGFloat eyeEnlarge;
/// 眼角，默认 0
/// @note 范围 -1~1
@property (nonatomic, assign) CGFloat eyeAngle;
/// 眼距，默认 0
/// @note 范围 -1~1
@property (nonatomic, assign) CGFloat eyeDistance;
/// 窄脸，默认 0
@property (nonatomic, assign) CGFloat thinFace;
/// v脸，默认 0
@property (nonatomic, assign) CGFloat vFace;
/// 下巴，默认 0
@property (nonatomic, assign) CGFloat chin;
/// 瘦颚骨，默认 0.2
@property (nonatomic, assign) CGFloat cheekboneThin;
/// 瘦鼻，默认 0.3
@property (nonatomic, assign) CGFloat noseNarrow;
/// 瘦翼，默认 0
/// @note 范围 -1~1
@property (nonatomic, assign) CGFloat noseWing;
/// 鼻子位置，默认 0
/// @note 范围 -1~1
@property (nonatomic, assign) CGFloat nosePosition;
/// 嘴形大小，默认 0
/// @note 范围 -1~1
@property (nonatomic, assign) CGFloat mouthSize;
/// 嘴唇厚度，默认 0
/// @note 范围 -1~1
@property (nonatomic, assign) CGFloat mouthThick;
/// 发际线，默认 0
/// @note 范围 -1~1
@property (nonatomic, assign) CGFloat foreHeadline;
/// 嘴唇宽度，默认 0
/// @note 范围 -1~1
@property (nonatomic, assign) CGFloat mouthWidth;
/// 嘴唇位置，默认 0
/// @note 范围 -1~1
@property (nonatomic, assign) CGFloat mouthPosition;
/// 收下颌，默认 0
@property (nonatomic, assign) CGFloat faceJaw;
/// 瘦脸，默认0
@property (nonatomic, assign) CGFloat basicFace;

// MARK: 美体

/// 瘦身，默认 0
@property (nonatomic, assign) CGFloat bodyThin;
/// 瘦肩，默认 0
@property (nonatomic, assign) CGFloat shoulderThin;
/// 瘦腰，默认 0
@property (nonatomic, assign) CGFloat waistThin;
/// 长腿，默认 0
@property (nonatomic, assign) CGFloat legLength;
/// 小头，默认 0
@property (nonatomic, assign) CGFloat headSmall;
/// 瘦腿，默认 0
@property (nonatomic, assign) CGFloat legSlim;

// MARK: 化妆

/// 口红，默认无效果
@property (nonatomic, assign) CGFloat lips;
/// 腮红，默认无效果
@property (nonatomic, assign) CGFloat redCheek;
/// 五官立体，默认无效果
@property (nonatomic, assign) CGFloat faceLight;

/// 降级美颜
/// @note 低端机器可以考虑这个
@property (nonatomic, assign) BOOL highPerformanceBeauty;

// MARK: 非业务关注

/// 映射使用的原始数据
@property (nonatomic, readonly) NSDictionary *rawInfos;

/// Lut 文件路径
@property (nonatomic, copy) NSString *lutPath;
/// Lut 强度
@property (nonatomic, assign) CGFloat lutIntensity;

/// 是否使用TME自研美型算法
@property (nonatomic, assign) BOOL useTMEUniform;

/// TME肤色美白，默认 0
@property (nonatomic, assign) CGFloat tme_smoothWhiten;

/// TME小脸，默认 0
@property (nonatomic, assign) CGFloat tme_smallFace;

/// 瘦脸类型
@property (nonatomic, strong) NSString *faceSubType;

/// TME锐化
@property (nonatomic, assign) CGFloat tme_sharpness;

/// 生成一份默认美颜
+ (instancetype)defaults;

/// 美颜开最大
/// @note 这是一般为了给 debug 用
+ (instancetype)maximum;

@end

NS_ASSUME_NONNULL_END
