//  --documented
//
//  TmeLightFilter.h
//  Ishtar-Playground
//
//  Created by DCTang on 2021/7/12.
//  Copyright © 2021 Tencent. All rights reserved.
//

#import <GPUImage/GPUImageFilter.h>
#import <light/light-umbrella.h>
#import <LightSdk-TME/TmeLightEffect.h>
#import <LightSdk-TME/TmeLightFilterSetting.h>

NS_ASSUME_NONNULL_BEGIN

@class TmeLightFilterSetting, TmeLightEffect, TmeLightFilter, TmeLightDependencyBundle, TmeLightFaceRetouch, TmeLightFaceRetouchDowngrade;

typedef void(^TmeLightFilterReslultHandler)(BOOL success, NSError *_Nullable error, id _Nullable extra);

/// `TmeLightFilter` 代理
@protocol TmeLightFilterDelegate <NSObject>

/// 告知 `TmeLightFilterDelegate` 发生了致命错误
- (void)tmeLightFilter:(TmeLightFilter *)TmeLightFilter
      didEncounterFatalError:(NSError *)error;

@optional

/// 将要处理新一帧数据
- (void)tmeLightFilter:(TmeLightFilter *)TmeLightFilter willProcessFrameAtTime:(CMTime)frameTime;

/// 已经处理完一帧数据
- (void)tmeLightFilter:(TmeLightFilter *)TmeLightFilter didProcessFrameAtTime:(CMTime)frameTime;

@end

/// LightSDK 能力滤镜封装
@interface TmeLightFilter : GPUImageFilter

/// 代理对象
@property (nonatomic, weak) id<TmeLightFilterDelegate> delegate;
/// 当前美颜配置
/// @note 当 setting.useHighPerformanceFaceRetouch 为 YES 时，该值为空。
@property (nonatomic, nullable, readonly) TmeLightFaceRetouch *faceRetouch;
/// 当前降级美颜配置
/// @note 当 setting.useHighPerformanceFaceRetouch 为 NO 时，该值为空。
@property (nonatomic, nullable, readonly) TmeLightFaceRetouchDowngrade *faceRetouchDowngrade;
/// 当前使用的 light 特效
@property (nonatomic, nullable, readonly) TmeLightEffect *effect;
/// 屏蔽滤镜效果
@property (nonatomic, assign) BOOL disable;
/// 是否暂时释放底层 lightSdk
/// 当为 YES 时此方法会释放底层 lightSdk 相关资源，置为 NO 时会重新创建
@property (nonatomic, assign) BOOL deactiveLightSdk;

/// 底层 LightSDK - LightEngine
@property (nonatomic, readonly) LightEngine *lightEngine;
/// 底层 LightSDK - LightCameraConfig
@property (nonatomic, readonly) LightCameraConfig *lightConfig;
/// 底层 LightSDK - LightSurface
@property (nonatomic, readonly) LightSurface *lightSurface;
/// 底层 LightSDK - LightCameraController
@property (nonatomic, readonly) LightCameraController* lightCameraController;
/// 底层 LightSDK - LightVideoOutput
@property(nonatomic, readonly) LightVideoOutput *lightVideoOutput;

/// 初始化一个涵盖 lightSDK 能力的 filter
/// @param setting 配置信息，不可为空
- (nullable instancetype)initWithSetting:(TmeLightFilterSetting *)setting
                                   error:(NSError **)error;

/// 初始化一个涵盖 lightSDK 能力的 filter
/// @param bundlePath lightSDK 必要加载资源，不可为空
/// @param setting lightSDK 配置对象
- (nullable instancetype)initWithCrucialBundlePath:(NSString *)bundlePath
                                           setting:(TmeLightFilterSetting *)setting
                                             error:(NSError **)error __attribute__((deprecated("initWithSetting:error:")));

/// 应用 Light Studio 素材，如果传空则表示不使用任何特效
/// @param effect 该素材是设计师从 Light Studio 素材直接输出的
- (BOOL)applyEffect:(nullable TmeLightEffect *)effect error:(NSError **)error;

/// 异步应用 Light Studio 素材
- (void)applyEffect:(nullable TmeLightEffect *)effect completion:(void(^)(NSError *_Nullable error))completion;

/// 应用素材依赖资源
/// @param bundles 素材依赖资源对象
/// @note 某些素材特效必须依赖此类资源，否则无法驱动。
- (BOOL)applyDependencyBundles:(NSArray<TmeLightDependencyBundle *> *)bundles error:(NSError **)error;

/// 应用 lut 图
/// @param lutFilePath 文件路径，传空则为不使用
/// @param identifier lut 标识，用于描述 lut 信息
- (BOOL)applyLutWithFilePath:(nullable NSString *)lutFilePath identifier:(NSString *)identifier error:(NSError **)error;

/// 调整 Lut 图浓度
- (void)modifyLutIntensity:(CGFloat)lutIntensity;

/// 应用美颜效果
- (BOOL)commitFaceRetouchChangesWithError:(NSError **)error;

/// 发送字符串事件给素材，触发特殊逻辑
- (void)sendEventWithName:(NSString *)name detail:(NSString *)detail;


/// 触发特效
- (void)preview;

/// 暂停特效
- (void)pause;

/// 重置特效
- (void)reset;

// MARK: 即将遗弃

/// 发送事件给素材，触发特殊逻辑
- (void)sendEventWithName:(NSString *)name info:(NSDictionary *)info __attribute__((deprecated("请使用 sendEventWithName:detail:")));

@end

NS_ASSUME_NONNULL_END
