//  --documented
//
//  TmeLightEffect.h
//  Ishtar-Playground
//
//  Created by DCTang on 2021/7/13.
//  Copyright © 2021 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <LightSdk-TME/TmeLightDefines.h>

NS_ASSUME_NONNULL_BEGIN

/// lightSDk 特效抽象对象
@interface TmeLightEffect : NSObject

/// 特效类型
@property (nonatomic, readonly) TmeLightEffectType type;
/// 模版路径
@property (nonatomic, readonly) NSString *directory;

/// 初始化一个特效对象
+ (nullable instancetype)effectWithDirectory:(NSString *)directory error:(NSError **)error;

/// 通过融合指定的特效对象，生产一个新的特效
- (nullable TmeLightEffect *)mergeTmeLightEffect:(TmeLightEffect *)lightEffect error:(NSError **)error;

@end

NS_ASSUME_NONNULL_END
