//  --documented
//
//  TmeLightBundle.h
//  Ishtar-Playground
//
//  Created by DCTang on 2021/7/15.
//  Copyright © 2021 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// lightSDK 素材资源依赖
@interface TmeLightDependencyBundle : NSObject

/// 每个依赖包的唯一标识
@property (nonatomic, readonly) NSString *identifier;
/// 依赖包路径
@property (nonatomic, readonly) NSString *filePath;

/// 初始化一个素材依赖
+ (nullable instancetype)bundleWithIdentifier:(NSString *)identifier
                                     filePath:(NSString *)filePath;

@end

NS_ASSUME_NONNULL_END
