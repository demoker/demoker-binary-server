//
//  TmeLightEffectDefines.h
//  Ishtar-Playground
//
//  Created by DCTang on 2021/7/13.
//  Copyright © 2021 Tencent. All rights reserved.
//

#ifndef TmeLightEffectDefines_h
#define TmeLightEffectDefines_h

#define TmeLightLog [SquadConsole loggerWithIdentifier:@"TmeLight"]

// MARK: light 特效类型

/// `TmeLightEffect` 模版类型
/// @note 比如是贴纸、还是头套
typedef NSInteger TmeLightEffectType NS_TYPED_ENUM;
/// 未知特效
static TmeLightEffectType const TmeLightEffectTypeUnKnown = 0;
/// 头套特效
static TmeLightEffectType const TmeLightEffectTypeAvatar = 1;
/// 美妆特效
static TmeLightEffectType const TmeLightEffectTypeMakeUp = 2;
/// 动态场景
static TmeLightEffectType const TmeLightEffectTypeScene = 3;
/// 融合素材
static TmeLightEffectType const TmeLightEffectTypeMerged = 4;


/// Anunnaki 错误域
static NSErrorDomain const TmeLightErrorDomain = @"TmeLightErrorDomain";

NS_ERROR_ENUM(TmeLightErrorDomain)
{
    TmeLightErrorUnknown = 0,
    TmeLightErrorAuthorization,
    TmeLightErrorDependency,
    TmeLightErrorFaceRetouch,
    TmeLightErrorAsset,

};

#define return_TmeLight_ThrowRawError(_outError, _code, _description, _reason, _returnValue) \
if (_outError != NULL) {\
\
NSDictionary *userInfo = @{ \
    NSLocalizedDescriptionKey: _description? : @"Not defines",\
    NSLocalizedFailureReasonErrorKey: _reason? : @"Not defines"\
};\
\
*_outError = [NSError errorWithDomain:TmeLightErrorDomain code:_code userInfo:userInfo];\
\
}\
return _returnValue;\

#define return_TmeLight_ThrowError(_outError, _error, _returnValue) \
if (_outError != NULL) {\
    *_outError = _error;\
}\
return _returnValue;\

#endif /* TmeLightEffectDefines_h */
