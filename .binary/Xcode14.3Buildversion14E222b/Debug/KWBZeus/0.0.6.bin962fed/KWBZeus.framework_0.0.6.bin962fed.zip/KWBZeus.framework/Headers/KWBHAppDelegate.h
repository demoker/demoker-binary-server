//
//  KWBHAppDelegate.h
//  KWUtility
//
//  Created by cuixuerui on 2020/6/29.
//  Copyright © 2020 Kuwo Beijing Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <UserNotifications/UserNotifications.h>
NS_ASSUME_NONNULL_BEGIN

@interface KWBHAppDelegate : UIResponder <UIApplicationDelegate>

@end

typedef void (^KWBHNotificationResultHandler)(UIBackgroundFetchResult);
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 100000
API_AVAILABLE(ios(10.0))
typedef void (^KWBHNotificationPresentationOptionsHandler)(UNNotificationPresentationOptions options);
typedef void (^KWBHNotificationCompletionHandler)(void);
#endif

API_AVAILABLE(ios(10.0))
@interface KWBHNotificationsItem : NSObject

@property (nonatomic, strong) NSError *notificationsError;
@property (nonatomic, strong) NSData *deviceToken;
@property (nonatomic, strong) NSDictionary *userInfo;
@property (nonatomic, copy) KWBHNotificationResultHandler notificationResultHander;

#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 100000
@property (nonatomic, strong) UNNotification *notification;
@property (nonatomic, strong) UNNotificationResponse *notificationResponse;
@property (nonatomic, copy) KWBHNotificationPresentationOptionsHandler notificationPresentationOptionsHandler;
@property (nonatomic, copy) KWBHNotificationCompletionHandler notificationCompletionHandler;
@property (nonatomic, strong) UNUserNotificationCenter *center;
#endif

@end

@interface KWBHOpenURLItem : NSObject

@property (nonatomic, strong) NSURL *openURL;
@property (nonatomic, copy) NSString *sourceApplication;
@property (nonatomic, strong) id annotation;
@property (nonatomic, strong) NSDictionary *options;

@end

typedef void (^KWBHShortcutCompletionHandler)(BOOL);

API_AVAILABLE(ios(9.0))
@interface KWBHShortcutItem : NSObject

#if __IPHONE_OS_VERSION_MAX_ALLOWED > 80400
@property(nonatomic, strong) UIApplicationShortcutItem *shortcutItem;
@property(nonatomic, copy) KWBHShortcutCompletionHandler scompletionHandler;
#endif

@end


typedef void (^KWBHUserActivityRestorationHandler)(NSArray *);

@interface KWBHUserActivityItem : NSObject

@property (nonatomic, copy) NSString *userActivityType;
@property (nonatomic, strong) NSUserActivity *userActivity;
@property (nonatomic, strong) NSError *userActivityError;
@property (nonatomic, copy) KWBHUserActivityRestorationHandler restorationHandler;

@end

typedef void (^KWBHWatchReplyHandler)(NSDictionary *replyInfo);

@interface KWBHWatchItem : NSObject

@property (nonatomic, strong) NSDictionary *userInfo;
@property (nonatomic, copy) KWBHWatchReplyHandler replyHandler;

@end



NS_ASSUME_NONNULL_END
