//
//  KWBHAnnotation.h
//  KWBZeus
//
//  Created by cuixuerui on 2021/2/2.
//

#import <Foundation/Foundation.h>

#import "KWBZeus.h"

#ifndef KWBZeusModSectName

#define KWBZeusModSectName "KWBZeusMods"

#endif

#ifndef KWBZeusServiceSectName

#define KWBZeusServiceSectName "BZeusServices"

#endif


#define KWBZeusDATA(sectname) __attribute((used, section("__DATA,"#sectname" ")))


#define KWBZeusMod(name) \
class KWBZeus; const char * k##name##_mod KWBZeusDATA(KWBZeusMods) = ""#name"";

#define KWBZeusService(servicename,impl) \
class KWBZeus; const char * k##servicename##_service KWBZeusDATA(BZeusServices) = "{ \""#servicename"\" : \""#impl"\"}";


@interface KWBHAnnotation : NSObject

@end

