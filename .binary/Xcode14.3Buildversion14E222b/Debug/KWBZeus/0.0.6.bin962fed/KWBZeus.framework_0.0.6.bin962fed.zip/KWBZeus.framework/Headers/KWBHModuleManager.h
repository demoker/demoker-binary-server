//
//  KWBHModuleManager.h
//  KWUtility
//
//  Created by cuixuerui on 2020/6/29.
//  Copyright © 2020 Kuwo Beijing Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, KWBHModuleType) {
    KWBHModuleBasic,
    KWBHModuleNormal,
};

typedef NS_ENUM(NSUInteger, KWBHModuleEventType) {
    KWBHMSetupEvent = 0,
    KWBHMInitEvent,
    KWBHMTearDownEvent,
    KWBHMSplashEvent,
    KWBHMQuickActionEvent,
    KWBHMWillResignActiveEvent,
    KWBHMDidEnterBackgroundEvent,
    KWBHMWillEnterForegroundEvent,
    KWBHMDidBecomeActiveEvent,
    KWBHMWillTerminateEvent,
    KWBHMUnmountEvent,
    KWBHMOpenURLEvent,
    KWBHMDidReceiveMemoryWarningEvent,
    KWBHMDidFailToRegisterForRemoteNotificationsEvent,
    KWBHMDidRegisterForRemoteNotificationsEvent,
    KWBHMDidReceiveRemoteNotificationEvent,
    KWBHMDidReceiveLocalNotificationEvent,
    KWBHMWillPresentNotificationEvent,
    KWBHMDidReceiveNotificationResponseEvent,
    KWBHMWillContinueUserActivityEvent,
    KWBHMContinueUserActivityEvent,
    KWBHMDidFailToContinueUserActivityEvent,
    KWBHMDidUpdateUserActivityEvent,
    KWBHMHandleWatchKitExtensionRequestEvent,
    KWBHMDidCustomEvent = 1000
};

@interface KWBHModuleManager : NSObject

+ (instancetype)sharedManager;

// If you do not comply with set Level protocol, the default Normal
- (void)registerDynamicModule:(Class)moduleClass;

- (void)registerDynamicModule:(Class)moduleClass
       shouldTriggerInitEvent:(BOOL)shouldTriggerInitEvent;

- (void)unRegisterDynamicModule:(Class)moduleClass;

- (void)loadLocalModules;

- (void)registedAllModules;

- (void)registerCustomEvent:(NSInteger)eventType
         withModuleInstance:(id)moduleInstance
             andSelectorStr:(NSString *)selectorStr;

- (void)triggerEvent:(NSInteger)eventType;

- (void)triggerEvent:(NSInteger)eventType
     withCustomParam:(NSDictionary * _Nonnull)customParam;

@end

NS_ASSUME_NONNULL_END
