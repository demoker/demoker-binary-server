//
//  KWBHContext.h
//  KWUtility
//
//  Created by cuixuerui on 2020/4/21.
//  Copyright © 2020 Kuwo Beijing Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KWBHAppDelegate.h"
#import "KWBHConfig.h"
#import "KWBHServiceProtocol.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, KWBHEnvironmentType) {
    KWBHEnvironmentDev,     // 测试环境
    KWBHEnvironmentProd,    // 生产环境
    KWBHEnvironmentPreProd,    // 预发布环境
};

@interface KWBHContext : NSObject <NSCopying>

@property (nonatomic, assign) KWBHEnvironmentType env;

//global config
@property(nonatomic, strong) KWBHConfig *config;

//application appkey
@property(nonatomic, strong) NSString *appkey;

//customEvent>=1000
@property(nonatomic, assign) NSInteger customEvent;

@property(nonatomic, strong) UIApplication *application;

@property(nonatomic, strong) NSDictionary *launchOptions;

@property(nonatomic, strong) NSString *moduleConfigName;

@property(nonatomic, strong) NSString *serviceConfigName;

//3D-Touch model
#if __IPHONE_OS_VERSION_MAX_ALLOWED > 80400
@property (nonatomic, strong) KWBHShortcutItem *touchShortcutItem;
#endif

//OpenURL model
@property (nonatomic, strong) KWBHOpenURLItem *openURLItem;

//Notifications Remote or Local
@property (nonatomic, strong) KWBHNotificationsItem *notificationsItem;

//user Activity Model
@property (nonatomic, strong) KWBHUserActivityItem *userActivityItem;

//watch Model
@property (nonatomic, strong) KWBHWatchItem *watchItem;

@property (nonatomic, copy) NSString *productName;

@property (nonatomic, copy) NSDictionary *customParam;

+ (instancetype)shareInstance;

- (void)addServiceWithImplInstance:(id)implInstance serviceName:(NSString *)serviceName;

- (void)removeServiceWithServiceName:(NSString *)serviceName;

- (id)getServiceInstanceFromServiceName:(NSString *)serviceName;


@end

NS_ASSUME_NONNULL_END
