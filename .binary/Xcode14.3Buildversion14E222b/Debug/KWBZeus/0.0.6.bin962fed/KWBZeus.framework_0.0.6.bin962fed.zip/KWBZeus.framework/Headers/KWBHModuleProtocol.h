//
//  KWBHModuleProtocol.h
//  KWUtility
//
//  Created by cuixuerui on 2020/4/21.
//  Copyright © 2020 Kuwo Beijing Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KWBHAnnotation.h"

NS_ASSUME_NONNULL_BEGIN
@class KWBHContext;
@protocol KWBHModuleProtocol <NSObject>

@optional

//如果不去设置Level默认是Normal
//basicModuleLevel不去实现默认Normal
- (void)basicModuleLevel;
//越大越优先
- (NSInteger)modulePriority;

- (BOOL)async;

- (void)modSetUp:(KWBHContext *)context;

- (void)modInit:(KWBHContext *)context;

- (void)modSplash:(KWBHContext *)context;

- (void)modQuickAction:(KWBHContext *)context;

- (void)modTearDown:(KWBHContext *)context;

- (void)modWillResignActive:(KWBHContext *)context;

- (void)modDidEnterBackground:(KWBHContext *)context;

- (void)modWillEnterForeground:(KWBHContext *)context;

- (void)modDidBecomeActive:(KWBHContext *)context;

- (void)modWillTerminate:(KWBHContext *)context;

- (void)modUnmount:(KWBHContext *)context;

- (void)modOpenURL:(KWBHContext *)context;

- (void)modDidReceiveMemoryWaring:(KWBHContext *)context;

- (void)modDidFailToRegisterForRemoteNotifications:(KWBHContext *)context;

- (void)modDidRegisterForRemoteNotifications:(KWBHContext *)context;

- (void)modDidReceiveRemoteNotification:(KWBHContext *)context;

- (void)modDidReceiveLocalNotification:(KWBHContext *)context;

- (void)modWillPresentNotification:(KWBHContext *)context;

- (void)modDidReceiveNotificationResponse:(KWBHContext *)context;

- (void)modWillContinueUserActivity:(KWBHContext *)context;

- (void)modContinueUserActivity:(KWBHContext *)context;

- (void)modDidFailToContinueUserActivity:(KWBHContext *)context;

- (void)modDidUpdateContinueUserActivity:(KWBHContext *)context;

- (void)modHandleWatchKitExtensionRequest:(KWBHContext *)context;

- (void)modDidCustomEvent:(KWBHContext *)context;
@end

NS_ASSUME_NONNULL_END
