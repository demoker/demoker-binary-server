//
//  KWBHServiceProtocol.h
//  KWUtility
//
//  Created by cuixuerui on 2020/7/1.
//  Copyright © 2020 Kuwo Beijing Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KWBHAnnotation.h"

@protocol KWBHServiceProtocol <NSObject>

@optional

+ (BOOL)singleton;

+ (id)shareInstance;

@end
