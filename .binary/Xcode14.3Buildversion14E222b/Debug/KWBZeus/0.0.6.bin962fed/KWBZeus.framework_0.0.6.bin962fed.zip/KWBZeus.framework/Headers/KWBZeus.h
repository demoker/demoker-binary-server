//
//  KWBZeus.h
//  KWUtility
//
//  Created by cuixuerui on 2020/4/21.
//  Copyright © 2020 Kuwo Beijing Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KWBHContext.h"
#import "KWBHAppDelegate.h"
#import "KWBHModuleProtocol.h"
#import "KWBHModuleManager.h"
#import "KWBHServiceManager.h"

NS_ASSUME_NONNULL_BEGIN

/// 注册willFinishLaunch阶段的任务
#define KWBHMCLifeCycle_WillFinishLaunch        1001
/// 注册didFinishLaunch阶段的任务
#define KWBHMCLifeCycle_DidFinishLaunch         1002
/// 注册DidEnterBackground阶段的任务
#define KWBHMCLifeCycle_WillResignActive        1003
/// 注册WillEnterForeground阶段的任务
#define KWBHMCLifeCycle_DidEnterBackground      1004
/// 注册WillEnterForeground阶段的任务
#define KWBHMCLifeCycle_WillEnterForeground     1005
/// 注册DidBecomeActive阶段的任务
#define KWBHMCLifeCycle_DidBecomeActive         1006
/// 注册WillTerminate阶段的任务
#define KWBHMCLifeCycle_WillTerminate           1007

#define KWBHMCLifeCycle_OpenURL                 1008

/// 注册启动图展示
#define KWBHMCSplashFirstPageDidAppearEvent     2001
/// 注册启动图展示消失
#define KWBHMCSplashFirstPageDidDisappearEvent  2002
/// 注册广告图即将展示
#define KWBHMCSplashWillDisappearEvent          2003
/// 注册广告图消失
#define KWBHMCSplashDidDisappearEvent           2004

#define kSegmentIdentifier "__KW_Player"

#pragma mark - 实现存储方法Function，推荐使用

/// key参数，在同一个.m文件中调用此宏需要key唯一
/// DEBUG模式下，会记录方法声明所在文件，方便记录

/// 注册为并发执行，并发数为3
#define KWBZeus_Registe_Function_Concurrent(key) KW_Registe_Function(key, false)
/// 注册到主线程执行
#define KWBZeus_Registe_Function_MainThread(key) KW_Registe_Function(key, true)

#if DEBUG
typedef void (*_KWFunction)(void);
struct KW_Function {
    char *key;
    _KWFunction function;
    bool bInMainThread;
    char *file;
};
#define KW_Registe_Function(key, bInMainThread) \
static void checkF##key(void);  __attribute__((unused))\
static void checkF##key(void) { if(key==1){}} \
_KW_Registe_Function(key, bInMainThread)

#define _KW_Registe_Function(key, bInMainThread) \
static void _KW##key(void); \
__attribute__((used, section(kSegmentIdentifier "," "__"#key ".func"))) \
static const struct KW_Function __F##key = (struct KW_Function){(char *)(&#key), (&_KW##key), (bool)bInMainThread, (char *)(&(__FILE_NAME__))}; \
static void _KW##key(void) \

#else
typedef void (*_KWFunction)(void);
struct KW_Function {
    char *key;
    _KWFunction function;
    bool bInMainThread;
};
#define KW_Registe_Function(key, bInMainThread)    _KW_Registe_Function(key, bInMainThread)

#define _KW_Registe_Function(key, bInMainThread) \
static void _KW##key(void); \
__attribute__((used, section(kSegmentIdentifier "," "__"#key ".func"))) \
static const struct KW_Function __F##key = (struct KW_Function){(char *)(&#key), (&_KW##key), (bool)bInMainThread}; \
static void _KW##key(void) \

#endif



#pragma mark - 实现存储block
struct KW_Block {
    char *key;
    __unsafe_unretained void (^block)(void);
};

/// key 参数，在同一个.m文件中调用此宏需要key唯一
#if DEBUG
#define KW_Registe_Block(key, block) \
static void checkB##key();  __attribute__((unused))\
static void checkB##key() { if(key==1){}} \
_KW_Registe_Block(key, block)

#else
#define KW_Registe_Block(key, block)    _KW_Registe_Block(key, block)

#endif

#define _KW_Registe_Block(key, block) __attribute__((used, section(kSegmentIdentifier "," "__"#key ".block"))) \
static const struct KW_Block __B##key = (struct KW_Block){((char *)&#key), block};


#pragma mark - 实现存储字符串
struct KW_String {
    __unsafe_unretained NSString *key;
    __unsafe_unretained NSObject *value;
};

/// id 参数，在同一个.m文件中调用此宏需要id唯一
#define KW_Registe_String(key, value, id) _KW_Registe_String(key, value, id)
#define _KW_Registe_String(key, value, id) __attribute__((used, section(kSegmentIdentifier "," kSegmentIdentifier ".data"))) \
static const struct KW_String __S##id= (struct KW_String){key, value};


#pragma mark - 收集实现了该宏的类

#define KW_FunctionName_Registe __attribute__((used, section(kSegmentIdentifier ", __funcName"))) \
static const char *__KW_funcName__ = __func__;

@interface KWBZeus : NSObject

@property (nonatomic, strong, readonly) NSOperationQueue *concurrentOperationQueue;

@property (nonatomic, strong) KWBHContext *context;

@property (nonatomic, assign) BOOL enableException;

+ (instancetype)sharedInstance;

+ (void)registerDynamicModule:(Class) moduleClass;

- (id)createService:(Protocol *)proto;

//Registration is recommended to use a static way
- (void)registerService:(Protocol *)proto service:(Class) serviceClass;

+ (void)triggerCustomEvent:(NSInteger)eventType;

#pragma mark - Kylin

/// 执行注册为key的function
- (void)executeFunctionForKeyNum:(NSInteger)keyNum;

/// 并发执行，注册为key的block
- (void)concurrentInvokeBlockForKeyNum:(NSInteger)keyNum;
/// 在主线程执行，注册为key的block
- (void)invokeBlockInMainQueueForKeyNum:(NSInteger)keyNum;

/// key value获取存储的字符串
- (id)valueForKey:(NSString*)key;

- (BOOL)hasPlacedAtSection:(NSString *)section;


@end

NS_ASSUME_NONNULL_END
