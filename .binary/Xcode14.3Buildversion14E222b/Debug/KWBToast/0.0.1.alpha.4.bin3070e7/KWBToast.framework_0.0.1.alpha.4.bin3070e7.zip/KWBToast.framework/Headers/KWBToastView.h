//
//  KWBToastView.h
//  KWSpeed
//
//  Created by liujixin on 2021/6/4.
//  Copyright © 2021 Kuwo Beijing Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, KWBToastType) {
    KWBToastTypeSuccess = 0,
    KWBToastTypeError,
    KWBToastTypeWords,
    KWBToastTypeImage,
};

@interface KWBToastView : UIView

+ (instancetype _Nullable)toastWithMessage:(NSString * _Nullable)message
                            type:(KWBToastType)type
                         originY:(CGFloat)originY
                        tipImage:(UIImage * _Nullable)image;

@end

NS_ASSUME_NONNULL_END
