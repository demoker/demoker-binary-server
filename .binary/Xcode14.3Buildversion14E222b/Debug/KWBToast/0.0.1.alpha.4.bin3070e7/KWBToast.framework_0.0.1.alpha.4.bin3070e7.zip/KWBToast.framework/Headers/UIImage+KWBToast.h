//
//  UIImage+KWBToast.h
//  KWSpeed
//
//  Created by liujixin on 2021/6/4.
//  Copyright © 2021 Kuwo Beijing Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (KWBToast)

- (UIImage *)KWBToast_cornerRadius:(CGFloat)radius size:(CGSize)size;

@end

NS_ASSUME_NONNULL_END
