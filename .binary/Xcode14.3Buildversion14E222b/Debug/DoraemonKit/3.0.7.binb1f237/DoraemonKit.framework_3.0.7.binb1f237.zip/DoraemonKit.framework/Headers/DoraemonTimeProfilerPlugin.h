//
//  DoraemonTimeProfilerPlugin.h
//  AFNetworking
//
//  Created by didi on 2019/10/15.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonTimeProfilerPlugin : NSObject<DoraemonPluginProtocol>

@end

NS_ASSUME_NONNULL_END
