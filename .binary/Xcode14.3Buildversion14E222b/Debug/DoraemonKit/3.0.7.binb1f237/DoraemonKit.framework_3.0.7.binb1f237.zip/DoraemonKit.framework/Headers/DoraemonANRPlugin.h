//
//  DoraemonANRPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/6/13.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonANRPlugin : NSObject<DoraemonPluginProtocol>

@end
