//
//  DoraemonH5ViewController.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/5/4.
//

#import "DoraemonBaseViewController.h"

@interface DoraemonH5ViewController : DoraemonBaseViewController

@end
