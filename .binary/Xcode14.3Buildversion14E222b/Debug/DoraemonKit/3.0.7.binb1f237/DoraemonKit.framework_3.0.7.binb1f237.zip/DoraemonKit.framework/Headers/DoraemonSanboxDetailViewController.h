//
//  DoraemonSanboxDetailViewController.h
//  AFNetworking
//
//  Created by yixiang on 2018/6/20.
//

#import "DoraemonBaseViewController.h"

@interface DoraemonSanboxDetailViewController : DoraemonBaseViewController

@property (nonatomic, copy) NSString *filePath;

@end
