//
//  DoraemonCPUViewController.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/1/12.
//

#import "DoraemonBaseViewController.h"

@interface DoraemonCPUViewController : DoraemonBaseViewController

@end
