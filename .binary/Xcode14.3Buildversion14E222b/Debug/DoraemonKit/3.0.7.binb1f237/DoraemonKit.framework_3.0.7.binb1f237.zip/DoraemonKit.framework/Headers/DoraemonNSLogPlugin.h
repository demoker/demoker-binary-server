//
//  DoraemonNSLogPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/11/25.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonNSLogPlugin : NSObject<DoraemonPluginProtocol>

@end

NS_ASSUME_NONNULL_END
