//
//  DoraemonFPSViewController.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/1/3.
//

#import "DoraemonBaseViewController.h"

@interface DoraemonFPSViewController : DoraemonBaseViewController

@end
