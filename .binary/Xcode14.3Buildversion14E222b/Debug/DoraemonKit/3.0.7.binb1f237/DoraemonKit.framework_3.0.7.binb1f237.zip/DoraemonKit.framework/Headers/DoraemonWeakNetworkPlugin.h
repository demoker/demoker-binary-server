//
//  DoraemonWeakNetworkPlugin.h
//  AFNetworking
//
//  Created by didi on 2019/11/21.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonWeakNetworkPlugin : NSObject<DoraemonPluginProtocol>

@end
