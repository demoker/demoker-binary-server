//
//  DoraemonMethodUseTimeViewController.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2019/1/18.
//

#import "DoraemonBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonMethodUseTimeViewController : DoraemonBaseViewController

@end

NS_ASSUME_NONNULL_END
