//
//  DoraemonStartTimeProfilerViewController.h
//  DoraemonKit-DoraemonKit
//
//  Created by didi on 2020/4/13.
//

#import "DoraemonBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonStartTimeProfilerViewController : DoraemonBaseViewController

@end

NS_ASSUME_NONNULL_END
