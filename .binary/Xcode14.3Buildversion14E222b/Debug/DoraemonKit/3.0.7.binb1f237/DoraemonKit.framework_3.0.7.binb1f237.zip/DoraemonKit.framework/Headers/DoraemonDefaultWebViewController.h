//
//  DoraemonDefaultWebViewController.h
//  AFNetworking
//
//  Created by yixiang on 2018/12/27.
//

#import "DoraemonBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonDefaultWebViewController : DoraemonBaseViewController

@property (nonatomic, copy) NSString *h5Url;

@end

NS_ASSUME_NONNULL_END
