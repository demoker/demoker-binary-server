//
//  DoraemonFPSOscillogramViewController.h
//  CocoaLumberjack
//
//  Created by yixiang on 2018/1/12.
//

#import "DoraemonOscillogramViewController.h"

@interface DoraemonFPSOscillogramViewController : DoraemonOscillogramViewController

@end
