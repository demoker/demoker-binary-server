//
//  DoraemonStartPluginProtocol.h
//  CocoaLumberjack
//
//  Created by yixiang on 2017/12/17.
//

#import <Foundation/Foundation.h>

@protocol DoraemonStartPluginProtocol <NSObject>

@optional
- (void)startPluginDidLoad;

@end
