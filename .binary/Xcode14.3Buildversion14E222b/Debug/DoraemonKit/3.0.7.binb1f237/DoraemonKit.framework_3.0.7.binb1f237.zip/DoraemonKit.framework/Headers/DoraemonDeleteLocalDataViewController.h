//
//  DoraemonDeleteLocalDataViewController.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/11/22.
//

#import "DoraemonBaseViewController.h"

@interface DoraemonDeleteLocalDataViewController : DoraemonBaseViewController

@end
