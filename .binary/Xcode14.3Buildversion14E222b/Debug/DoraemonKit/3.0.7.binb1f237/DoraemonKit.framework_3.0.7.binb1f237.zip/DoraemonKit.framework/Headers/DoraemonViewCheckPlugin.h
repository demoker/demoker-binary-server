//
//  DoraemonViewCheckPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/3/28.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonViewCheckPlugin : NSObject<DoraemonPluginProtocol>

@end
