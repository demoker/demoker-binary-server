//
//  DoraemonHomeFootCell.h
//  DoraemonKit
//
//  Created by dengyouhua on 2019/9/4.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonHomeFootCell : UICollectionReusableView

@property (nonatomic, strong) UILabel *title;

@end

NS_ASSUME_NONNULL_END
