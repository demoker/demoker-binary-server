//
//  DoraemonViewAlignView.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/6/16.
//

#import <UIKit/UIKit.h>

@interface DoraemonViewAlignView : UIView

- (void)show;

- (void)hide;

@end
