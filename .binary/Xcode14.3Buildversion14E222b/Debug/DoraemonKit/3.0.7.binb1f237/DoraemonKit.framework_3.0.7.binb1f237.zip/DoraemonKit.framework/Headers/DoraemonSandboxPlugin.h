//
//  DoraemonSandboxPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2017/12/11.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonSandboxPlugin : NSObject<DoraemonPluginProtocol>

@end
