//
//  DoraemonViewAlignPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/6/16.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonViewAlignPlugin : NSObject<DoraemonPluginProtocol>

@end
