//
//  DoraemonH5Plugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/5/4.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonH5Plugin : NSObject<DoraemonPluginProtocol>

@end
