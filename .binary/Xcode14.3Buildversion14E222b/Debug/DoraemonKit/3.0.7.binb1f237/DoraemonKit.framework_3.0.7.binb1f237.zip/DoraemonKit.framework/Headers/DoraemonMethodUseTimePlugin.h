//
//  DoraemonMethodUseTimePlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2019/1/18.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonMethodUseTimePlugin : NSObject<DoraemonPluginProtocol>

@end

NS_ASSUME_NONNULL_END
