//
//  DoraemonMockCellSwitch.h
//  AFNetworking
//
//  Created by didi on 2019/10/23.
//

#import "DoraemonCellSwitch.h"

@interface DoraemonMockDetailSwitch : DoraemonCellSwitch

- (void)needArrow;

- (void)setArrowDown:(BOOL)isDown;

- (void)setSwitchFrame;

@end

