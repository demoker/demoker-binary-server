//
//  DoraemonNSURLProtocol.h
//  Aspects
//
//  Created by yixiang on 2018/4/11.
//

#import <Foundation/Foundation.h>

@interface DoraemonNSURLProtocol : NSURLProtocol

@end
