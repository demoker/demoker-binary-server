//
//  DoraemonCrashViewController.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/6/19.
//

#import "DoraemonBaseViewController.h"

@interface DoraemonCrashViewController : DoraemonBaseViewController

@end
