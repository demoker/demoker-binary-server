//
//  DoraemonDBShowView.h
//  AFNetworking
//
//  Created by yixiang on 2019/4/1.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonDBShowView : UIView

- (void)showText:(NSString *)text;

@end

NS_ASSUME_NONNULL_END
