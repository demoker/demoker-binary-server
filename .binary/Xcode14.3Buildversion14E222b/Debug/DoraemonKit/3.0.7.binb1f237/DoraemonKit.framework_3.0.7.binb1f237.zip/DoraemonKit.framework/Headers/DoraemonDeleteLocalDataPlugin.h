//
//  DoraemonDeleteLocalDataPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/11/22.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"


@interface DoraemonDeleteLocalDataPlugin : NSObject<DoraemonPluginProtocol>

@end
