//
//  DoraemonNSUserDefaultsPlugin.h
//  DoraemonKit
//
//  Created by 0xd-cc on 2019/11/26.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonNSUserDefaultsPlugin : NSObject<DoraemonPluginProtocol>

@end

NS_ASSUME_NONNULL_END
