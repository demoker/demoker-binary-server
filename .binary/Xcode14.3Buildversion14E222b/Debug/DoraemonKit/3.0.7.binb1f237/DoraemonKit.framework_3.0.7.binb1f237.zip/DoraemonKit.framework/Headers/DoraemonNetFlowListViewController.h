//
//  DoraemonNetFlowListViewController.h
//  Aspects
//
//  Created by yixiang on 2018/4/11.
//

#import "DoraemonBaseViewController.h"

@interface DoraemonNetFlowListViewController : DoraemonBaseViewController

@end
