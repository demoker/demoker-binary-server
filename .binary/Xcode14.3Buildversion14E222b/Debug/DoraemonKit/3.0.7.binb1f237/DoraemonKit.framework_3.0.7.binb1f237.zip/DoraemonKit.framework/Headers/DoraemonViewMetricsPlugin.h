//
//  DoraemonViewMetricsPlugin.h
//  DoraemonKit
//
//  Created by xgb on 2018/12/11.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonViewMetricsPlugin : NSObject <DoraemonPluginProtocol>

@end

