//
//  DoraemonHealthPlugin.h
//  AFNetworking
//
//  Created by didi on 2019/12/30.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonHealthPlugin : NSObject<DoraemonPluginProtocol>

@end

NS_ASSUME_NONNULL_END
