//
//  DoraemonMockApiCell.h
//  AFNetworking
//
//  Created by didi on 2019/11/15.
//

#import "DoraemonMockBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonMockApiCell : DoraemonMockBaseCell

@end

NS_ASSUME_NONNULL_END
