//
//  DoraemonHierarchyWindow.h
//  DoraemonKit-DoraemonKit
//
//  Created by lijiahuan on 2019/11/2.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonHierarchyWindow : UIWindow

- (void)show;
- (void)hide;

@end

NS_ASSUME_NONNULL_END
