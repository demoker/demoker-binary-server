//
//  DoraemonMockUploadDataViewController.h
//  AFNetworking
//
//  Created by didi on 2019/11/7.
//

#import "DoraemonMockBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonMockUploadViewController : DoraemonMockBaseViewController

@end

NS_ASSUME_NONNULL_END
