//
//  DoraemonANRViewController.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/6/13.
//

#import "DoraemonBaseViewController.h"

@interface DoraemonANRViewController : DoraemonBaseViewController

@end
