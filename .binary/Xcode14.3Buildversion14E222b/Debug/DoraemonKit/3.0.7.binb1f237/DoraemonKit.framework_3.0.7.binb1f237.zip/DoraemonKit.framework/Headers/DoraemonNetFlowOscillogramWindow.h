//
//  DoraemonNetFlowOscillogramWindow.h
//  AFNetworking
//
//  Created by yixiang on 2018/5/2.
//

#import "DoraemonOscillogramWindow.h"

@interface DoraemonNetFlowOscillogramWindow : DoraemonOscillogramWindow

+ (DoraemonNetFlowOscillogramWindow *)shareInstance;

@end
