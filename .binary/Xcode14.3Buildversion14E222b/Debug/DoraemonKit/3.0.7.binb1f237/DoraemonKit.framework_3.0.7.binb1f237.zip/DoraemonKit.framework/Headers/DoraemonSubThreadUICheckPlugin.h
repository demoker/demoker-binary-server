//
//  DoraemonSubThreadUICheckPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/9/12.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonSubThreadUICheckPlugin : NSObject<DoraemonPluginProtocol>

@end
