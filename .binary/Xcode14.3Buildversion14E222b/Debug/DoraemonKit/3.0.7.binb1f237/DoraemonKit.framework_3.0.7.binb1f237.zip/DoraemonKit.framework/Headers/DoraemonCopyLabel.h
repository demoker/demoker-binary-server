//
//  DoraemonCopyLabel.h
//  DoraemonKit-DoraemonKit
//
//  Created by didi on 2020/2/26.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonCopyLabel : UILabel

@end

NS_ASSUME_NONNULL_END
