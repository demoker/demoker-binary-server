//
//  DoraemonHealthBgView.h
//  AFNetworking
//
//  Created by didi on 2019/12/31.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonHealthBgView : UIView

- (CGRect)getButtonCGRect;
- (CGRect)getStartingTitleCGRect;

@end

NS_ASSUME_NONNULL_END
