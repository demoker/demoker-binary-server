//
//  XAxis.h
//  oxCharts
//
//  Created by 0xd on 2019/9/9.
//  Copyright © 2019 000. All rights reserved.
//

#import "DoraemonChartAxis.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonXAxis : DoraemonChartAxis
@end

NS_ASSUME_NONNULL_END
