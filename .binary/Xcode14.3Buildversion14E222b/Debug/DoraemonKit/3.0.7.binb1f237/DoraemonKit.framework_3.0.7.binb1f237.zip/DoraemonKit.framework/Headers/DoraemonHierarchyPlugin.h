//
//  DoraemonHierarchyPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by lijiahuan on 2019/11/2.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonHierarchyPlugin : NSObject<DoraemonPluginProtocol>

@end

NS_ASSUME_NONNULL_END
