//
//  DoraemonCPUUtil.h
//  CocoaLumberjack
//
//  Created by yixiang on 2018/1/15.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface DoraemonCPUUtil : NSObject

//获取CPU使用率
+ (CGFloat)cpuUsageForApp;

@end
