//
//  DoraemonMetricsViewController.h
//  DoraemonKit
//
//  Created by xgb on 2019/1/10.
//

#import <DoraemonKit/DoraemonKit.h>
#import "DoraemonBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonMetricsViewController : DoraemonBaseViewController

@end

NS_ASSUME_NONNULL_END
