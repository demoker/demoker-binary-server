//
//  DoraemonMockUploadCell.h
//  AFNetworking
//
//  Created by didi on 2019/11/15.
//

#import "DoraemonMockBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonMockUploadCell : DoraemonMockBaseCell

@end

NS_ASSUME_NONNULL_END
