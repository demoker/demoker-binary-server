//
//  DoraemonAppSettingPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by didi on 2020/2/28.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonAppSettingPlugin : NSObject<DoraemonPluginProtocol>

@end

NS_ASSUME_NONNULL_END
