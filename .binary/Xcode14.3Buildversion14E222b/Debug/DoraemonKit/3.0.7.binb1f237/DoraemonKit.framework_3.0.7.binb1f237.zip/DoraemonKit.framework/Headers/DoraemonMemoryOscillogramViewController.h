//
//  DoraemonMemoryOscillogramViewController.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/1/25.
//

#import "DoraemonOscillogramViewController.h"

@interface DoraemonMemoryOscillogramViewController : DoraemonOscillogramViewController

@end
