//
//  DoraemonANRDetailViewController.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/6/16.
//

#import "DoraemonBaseViewController.h"

@interface DoraemonANRDetailViewController : DoraemonBaseViewController

@property (nonatomic, strong) NSString *filePath;

@end
