//
//  DoraemonHomeCloseCell.h
//  DoraemonKit
//
//  Created by dengyouhua on 2019/9/4.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonHomeCloseCell : UICollectionViewCell

@end

NS_ASSUME_NONNULL_END
