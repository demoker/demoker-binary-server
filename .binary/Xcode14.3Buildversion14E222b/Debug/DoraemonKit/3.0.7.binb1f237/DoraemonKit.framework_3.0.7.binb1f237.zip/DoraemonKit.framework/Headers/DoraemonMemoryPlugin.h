//
//  DoraemonMemoryPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/1/25.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonMemoryPlugin : NSObject<DoraemonPluginProtocol>

@end
