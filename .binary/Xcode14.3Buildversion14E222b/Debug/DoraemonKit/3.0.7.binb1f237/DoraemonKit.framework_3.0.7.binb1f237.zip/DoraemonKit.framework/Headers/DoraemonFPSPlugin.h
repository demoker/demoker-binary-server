//
//  DoraemonFPSPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/1/3.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonFPSPlugin : NSObject<DoraemonPluginProtocol>

@end
