//
//  DoraemonCrashPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/6/19.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonCrashPlugin : NSObject<DoraemonPluginProtocol>

@end
