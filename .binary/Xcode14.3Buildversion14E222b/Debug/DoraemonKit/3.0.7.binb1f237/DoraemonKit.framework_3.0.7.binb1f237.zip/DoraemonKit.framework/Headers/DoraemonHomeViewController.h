//
//  DoraemonHomeViewController.h
//  DoraemonKit
//
//  Created by dengyouhua on 2019/9/4.
//

#import "DoraemonBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

/**
 * DoraemonHomeEntry | 新主界面入口
 */
@interface DoraemonHomeViewController : DoraemonBaseViewController

@end

NS_ASSUME_NONNULL_END
