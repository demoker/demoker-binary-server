//
//  DoraemonHealthViewController.h
//  AFNetworking
//
//  Created by didi on 2019/12/30.
//

#import "DoraemonBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonHealthViewController : DoraemonBaseViewController

@end

NS_ASSUME_NONNULL_END
