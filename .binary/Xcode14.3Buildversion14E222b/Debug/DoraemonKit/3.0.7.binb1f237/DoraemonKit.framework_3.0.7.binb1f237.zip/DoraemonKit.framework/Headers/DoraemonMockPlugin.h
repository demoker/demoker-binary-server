//
//  DoraemonMockPlugin.h
//  AFNetworking
//
//  Created by didi on 2019/10/23.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonMockPlugin : NSObject<DoraemonPluginProtocol>

@end

