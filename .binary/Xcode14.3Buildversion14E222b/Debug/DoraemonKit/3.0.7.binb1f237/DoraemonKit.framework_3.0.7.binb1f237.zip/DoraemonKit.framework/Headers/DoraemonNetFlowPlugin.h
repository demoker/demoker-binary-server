//
//  DoraemonNetFlowPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/4/9.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonNetFlowPlugin : NSObject<DoraemonPluginProtocol>

@end
