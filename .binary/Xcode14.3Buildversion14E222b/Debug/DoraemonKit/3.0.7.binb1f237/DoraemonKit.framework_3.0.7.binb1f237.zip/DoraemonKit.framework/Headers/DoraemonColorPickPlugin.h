//
//  DoraemonColorPickPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/3/5.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonColorPickPlugin : NSObject<DoraemonPluginProtocol>

@end
