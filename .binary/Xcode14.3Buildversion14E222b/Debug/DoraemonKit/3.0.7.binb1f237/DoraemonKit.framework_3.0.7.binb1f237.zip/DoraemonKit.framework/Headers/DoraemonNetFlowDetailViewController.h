//
//  DoraemonNetFlowDetailViewController.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/4/13.
//

#import "DoraemonBaseViewController.h"
#import "DoraemonNetFlowHttpModel.h"

@interface DoraemonNetFlowDetailViewController : DoraemonBaseViewController

@property (nonatomic, strong) DoraemonNetFlowHttpModel *httpModel;

@end
