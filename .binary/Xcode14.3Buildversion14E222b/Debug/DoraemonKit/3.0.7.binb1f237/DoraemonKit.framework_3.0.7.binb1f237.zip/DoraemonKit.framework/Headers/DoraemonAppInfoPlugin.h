//
//  DoraemonAppInfoPlugin.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/4/13.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

@interface DoraemonAppInfoPlugin : NSObject<DoraemonPluginProtocol>

@end
