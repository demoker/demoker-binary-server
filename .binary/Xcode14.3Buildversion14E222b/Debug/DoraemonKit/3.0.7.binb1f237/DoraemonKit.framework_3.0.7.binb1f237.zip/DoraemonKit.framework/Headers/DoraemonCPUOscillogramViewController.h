//
//  DoraemonCPUOscillogramViewController.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/1/12.
//

#import "DoraemonOscillogramViewController.h"

@interface DoraemonCPUOscillogramViewController : DoraemonOscillogramViewController

@end
