//
//  DoraemonWeakNetworkDetailView.h
//  AFNetworking
//
//  Created by didi on 2019/12/16.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonWeakNetworkDetailView : UIView

- (void)renderInputView:(NSInteger)select;

@end

NS_ASSUME_NONNULL_END
