//
//  DoraemonUIProfileViewController.h
//  DoraemonKit
//
//  Created by xgb on 2019/8/1.
//

#import <DoraemonKit/DoraemonKit.h>
#import "DoraemonBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonUIProfileViewController : DoraemonBaseViewController

@end

NS_ASSUME_NONNULL_END
