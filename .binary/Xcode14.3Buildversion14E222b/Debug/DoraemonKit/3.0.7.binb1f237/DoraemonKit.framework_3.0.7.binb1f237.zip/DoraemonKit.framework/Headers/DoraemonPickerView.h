//
//  DoraemonPickerView.h
//  DoraemonKit-DoraemonKit
//
//  Created by lijiahuan on 2019/11/2.
//

#import "DoraemonMoveView.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonPickerView : DoraemonMoveView

@end

NS_ASSUME_NONNULL_END
