//
//  DoraemonHierarchySwitchCell.h
//  DoraemonKit-DoraemonKit
//
//  Created by lijiahuan on 2019/11/2.
//

#import "DoraemonHierarchyDetailTitleCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonHierarchySwitchCell : DoraemonHierarchyDetailTitleCell

@end

NS_ASSUME_NONNULL_END
