//
//  UIView+DoraemonViewMetrics.h
//  DoraemonKit
//
//  Created by xgb on 2018/12/11.
//

#import <UIKit/UIKit.h>

@interface UIView (DoraemonViewMetrics)

- (void)doraemonMetricsRecursiveEnable:(BOOL)enable;

@end


