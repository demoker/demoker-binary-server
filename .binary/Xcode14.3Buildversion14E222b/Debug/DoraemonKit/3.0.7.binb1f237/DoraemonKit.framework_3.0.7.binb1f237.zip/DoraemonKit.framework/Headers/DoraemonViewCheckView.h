//
//  DoraemonViewCheckView.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/3/28.
//

#import <UIKit/UIKit.h>

@interface DoraemonViewCheckView : UIView

- (void)hide;

- (void)show;

@end
