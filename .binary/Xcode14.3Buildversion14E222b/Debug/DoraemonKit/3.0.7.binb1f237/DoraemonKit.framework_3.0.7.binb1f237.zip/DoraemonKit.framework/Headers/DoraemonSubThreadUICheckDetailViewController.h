//
//  DoraemonSubThreadUICheckDetailViewController.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/9/13.
//

#import "DoraemonBaseViewController.h"

@interface DoraemonSubThreadUICheckDetailViewController : DoraemonBaseViewController

@property (nonatomic, strong) NSDictionary *checkInfo;

@end
