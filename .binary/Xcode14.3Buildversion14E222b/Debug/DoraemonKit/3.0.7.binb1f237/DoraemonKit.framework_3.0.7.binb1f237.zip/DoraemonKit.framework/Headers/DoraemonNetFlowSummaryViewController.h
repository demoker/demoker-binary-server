//
//  DoraemonNetFlowSummaryViewController.h
//  Aspects
//
//  Created by yixiang on 2018/4/12.
//

#import "DoraemonBaseViewController.h"

@interface DoraemonNetFlowSummaryViewController : DoraemonBaseViewController

@end
