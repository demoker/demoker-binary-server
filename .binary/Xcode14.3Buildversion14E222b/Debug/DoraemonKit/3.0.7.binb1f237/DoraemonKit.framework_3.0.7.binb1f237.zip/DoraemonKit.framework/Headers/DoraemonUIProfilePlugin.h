//
//  DoraemonUIProfilePlugin.h
//  DoraemonKit
//
//  Created by xgb on 2019/8/1.
//

#import <Foundation/Foundation.h>
#import "DoraemonPluginProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface DoraemonUIProfilePlugin : NSObject <DoraemonPluginProtocol>

@end

NS_ASSUME_NONNULL_END
