//
//  DoraemonFPSOscillogramWindow.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/1/12.
//

#import "DoraemonOscillogramWindow.h"

@interface DoraemonFPSOscillogramWindow : DoraemonOscillogramWindow

+ (DoraemonFPSOscillogramWindow *)shareInstance;

@end
