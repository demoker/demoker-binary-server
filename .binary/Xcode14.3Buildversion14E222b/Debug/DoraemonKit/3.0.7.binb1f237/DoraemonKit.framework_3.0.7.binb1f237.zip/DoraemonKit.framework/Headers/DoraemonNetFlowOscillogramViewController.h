//
//  DoraemonNetFlowOscillogramViewController.h
//  DoraemonKit-DoraemonKit
//
//  Created by yixiang on 2018/5/2.
//

#import "DoraemonOscillogramViewController.h"

@interface DoraemonNetFlowOscillogramViewController : DoraemonOscillogramViewController

@end
